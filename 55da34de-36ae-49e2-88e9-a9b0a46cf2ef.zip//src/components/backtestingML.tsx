// Backtest.tsx (Part 1/3)
import React, { useEffect, useMemo, useRef, useState } from "react";
// Render the equity curve using a custom SVG implementation
import {
  format,
  startOfMonth,
  addDays,
  startOfWeek,
  isSameMonth,
} from "date-fns";

// Import charting primitives from recharts to render the trade equity curve.
import {
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";

/* ----------------- Global Styles (dark, minimal, professional) ----------------- */
const GlobalDark: React.FC = () => {
  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');

      html, body, #root { height:100%; background:#000; margin:0; padding:0; }
      body {
        font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        color:#e5e7eb;
        font-size:13px;
      }
      * { box-sizing:border-box; }

      .wrap { max-width:1140px; margin:24px auto; padding:16px; }
      .grid { display:grid; gap:12px; }
      .row { display:flex; gap:12px; align-items:center; flex-wrap:wrap; }

      .card { border:1px solid #111827; background:#0b0b0b; border-radius:14px; padding:14px; }
      .card + .card { margin-top:18px; }
      .muted { color:#94a3b8; }
      .title { font-weight:800; font-size:22px; margin:0 0 8px; letter-spacing:.2px; }

      .btn {
        border:1.5px solid #1f2937; padding:10px 14px; border-radius:999px; font-size:14px;
        background:linear-gradient(180deg,#0b0b0b,#0a0a0a); color:#e5e7eb; cursor:pointer;
        transition:transform .12s ease, box-shadow .25s ease, border .2s ease, background .2s ease;
      }
      .btn:hover { transform: translateY(-1px); box-shadow:0 8px 24px rgba(0,0,0,.35); }
      .btn:active { transform: translateY(0); }
      .btn[disabled] { opacity:.55; cursor:not-allowed; }

      .btn-primary { border-color:#22c55e; color:#22c55e; }
      .btn-primary:hover { box-shadow:0 0 18px rgba(34,197,94,.28), inset 0 0 0 1px rgba(34,197,94,.35); background:#071b10; }

      .btn-rect { border-radius:10px; padding:14px 18px; font-weight:700; }
      .btn-rect-sm {
        position:relative;
        border-radius:10px; padding:12px 14px; font-weight:700; width:100%; text-align:center;
        min-height:46px;
      }
      .btn-rect-sm.selected {
        border-color:#22c55e !important;
        box-shadow:0 0 0 1px rgba(34,197,94,.35) inset, 0 0 18px rgba(34,197,94,.12);
      }
      .badge-priority {
        position:absolute; top:6px; right:8px; width:18px; height:18px; border-radius:50%;
        display:flex; align-items:center; justify-content:center;
        font-size:11px; font-weight:800; background:#0b0b0b; border:1px solid #14532d; color:#22c55e;
      }

      .section-title { font-weight:800; font-size:13px; color:#e5e7eb; margin:4px 0 8px 0; }

      .input, .select {
        border:1.5px solid #1f2937; border-radius:12px; padding:10px 12px; background:#0b0b0b; color:#e5e7eb; width:100%;
      }
      .input:focus, .select:focus { outline:none; border-color:#9ca3af; }

      .input-compact {
        border:1.5px solid #1f2937; border-radius:10px; padding:8px 10px; background:#0b0b0b; color:#e5e7eb; width:120px; font-size:12px;
      }

      .tiny { font-size:11px; color:#9aa3af; line-height:1.2; margin-top:6px; }

      .kpis { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; }
      .kpi { border:1px solid #111827; background:#0c0c0c; border-radius:12px; padding:12px; }
      .kpi .lab { font-size:11px; color:#94a3b8; margin-bottom:6px; font-weight:600; }
      .kpi .val { font-size:18px; font-weight:800; color:#e5e7eb; }
      .kpi.good  .val { color:#22c55e; }
      .kpi.bad   .val { color:#ef4444; }
      .kpi.warn  .val { color:#f59e0b; }
      .kpi.neutral .val { color:#3b82f6; }
      .kpi.span4 { grid-column: 1 / -1; }

      .table { width:100%; border-collapse:collapse; }
      .table th { text-align:left; padding:10px 12px; font-size:12px; background:#0f172a; border-bottom:1px solid #1f2937; color:#e5e7eb; font-weight:700; }
      .table td { padding:10px 12px; font-size:13px; border-top:1px solid #111827; }

      /* Calendar */
      .cal-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; font-weight:700; }
      .cal-grid { display:grid; grid-template-columns:repeat(7,1fr); gap:6px; }
      .cal-cell {
        height:64px; border-radius:10px; border:1px solid #111827;
        display:flex; flex-direction:column; justify-content:space-between; padding:6px; cursor:pointer;
      }
      .cal-dow { font-size:12px; color:#94a3b8; text-align:center; font-weight:700; }
      .num { font-size:12px; color:#cbd5e1; font-weight:700; }
      .pnl { font-size:11px; font-weight:800; }
      .count { font-size:11px; color:#9aa3af; }

      /* Advanced / Automation */
      .adv-head, .auto-head { display:flex; justify-content:space-between; align-items:center; cursor:pointer; padding:8px 0; font-weight:800; }
      .adv-grid, .auto-grid { display:grid; gap:12px; }
      .auto-top { display:flex; gap:12px; align-items:center; justify-content:center; margin-bottom:10px; flex-wrap:wrap; }

      /* Automation grid: 5 x 2, equal button sizes */
      .auto-grid { grid-template-columns: repeat(5, minmax(160px, 1fr)); }
      .auto-grid > .btn-rect-sm { width:100%; }

      /* Loading bars */
      .progress-shell { width:100%; height:6px; background:#0f172a; border-radius:999px; overflow:hidden; border:1px solid #111827; }
      .progress-bar { height:100%; width:0%; background:#22c55e; transition: width .2s linear; }
      .progress-shell-lg { height:14px; }
      .progress-shell-xl { height:12px; }

      /* Status chips */
      .chip { font-size:11px; border:1px solid #1f2937; background:#0b0b0b; padding:6px 10px; border-radius:999px; font-weight:700; }
      .chip.ok { border-color:#14532d; color:#22c55e; }
      .chip.miss { border-color:#3f1d1d; color:#ef4444; }

      .label { display:flex; align-items:center; gap:6px; font-size:12px; color:#cbd5e1; font-weight:700; }

      /* Spinner */
      @keyframes spin { to { transform: rotate(360deg); } }
      .spinner {
        width:14px; height:14px; border:2px solid #334155; border-top-color:#22c55e; border-radius:50%;
        animation: spin .8s linear infinite;
      }

      /* ===== Dual Range ===== */
      .range2 { position: relative; height: 44px; }
      .range2-track { position:absolute; left:8px; right:8px; top:18px; height:8px; background:#0e1726; border:1px solid #111827; border-radius:999px; }
      .range2-fill { position:absolute; top:18px; height:8px; background:#22c55e; border-radius:999px; }
      .range2-handle {
        position:absolute; top:12px; width:20px; height:20px; background:#0b0b0b; border:2px solid #22c55e;
        border-radius:50%; cursor:pointer; box-shadow:0 0 0 4px rgba(34,197,94,.12);
        transform: translateX(-50%); transition: box-shadow .12s ease; touch-action:none;
      }
      .range2-handle:active { box-shadow:0 0 0 6px rgba(34,197,94,.2); }

      /* Tooltips */
      .tt { position: relative; display:inline-flex; align-items:center; justify-content:center; width:16px; height:16px; border-radius:50%; background:#0b0b0b; border:1px solid #334155; color:#94a3b8; font-weight:800; font-size:11px; line-height:1; user-select:none; }
      .tt::after {
        content: attr(data-tip);
        position:absolute; top:-38px; left:50%; transform:translateX(-50%);
        background:#0f172a; color:#e5e7eb; border:1px solid #1f2937; border-radius:8px;
        padding:6px 8px; white-space:nowrap; font-size:12px; pointer-events:none; opacity:0;
      }
      .tt:hover::after { opacity:1; }

      /* Themed dropdown — darker bg + brighter text + styled options */
      .select-wrap { position:relative; display:inline-flex; align-items:center; border-radius:10px; }
      .select-themed {
        appearance:none; -webkit-appearance:none; -moz-appearance:none;
        background:
          linear-gradient(180deg,#08101c,#050a14) padding-box,
          linear-gradient(180deg,#1f2937,#0f172a) border-box;
        border:1.5px solid transparent;
        color:#f3f4f6; border-radius:10px; padding:10px 36px 10px 12px; font-weight:800; letter-spacing:.2px;
      }
      .select-themed:focus { outline:none; border-color:#9ca3af; box-shadow:0 0 0 3px rgba(156,163,175,.25); }
      .select-themed option { background:#0b0b0b; color:#f3f4f6; }
      .select-caret { position:absolute; right:10px; pointer-events:none; font-weight:800; color:#cbd5e1; font-size:12px; }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);
  return null;
};

/* ----------------- Types ----------------- */
type Row = {
  time: string | number;
  open: number;
  high: number;
  low: number;
  close: number;
  ts: number;
};
type ExitReason =
  | "TP"
  | "SL"
  | "End"
  | "MaxBars"
  | "TargetLen"
  | "TurnedSideways"
  | "LostConfidence";
type Trade = {
  entryIdx: number;
  exitIdx: number;
  side: "LONG" | "SHORT";
  entryPrice: number;
  exitPrice: number;
  pnl: number;
  entryTs: number;
  exitTs: number;
  exitReason: ExitReason;
};
type Stats = {
  trades: number;
  winRate: number;
  avgTrade: number;
  profitFactor: number;
  totalPnL: number;
  sharpe: number;
  sortino: number;
  maxDD: number;
  peakBal: number;
  lowBal: number;
  avgLen: number;
  avgWinLen: number;
  avgLossLen: number;
  medianLen: number;
  p90Len: number;
  avgWinUsd: number;
  avgLossUsd: number;
  maxWinUsd: number;
  maxLossUsd: number;
  longTrades: number;
  shortTrades: number;
  avgMAE: number;
  maxMAE: number;
  avgMFE: number;
  maxMFE: number;
  expectedValue: number;

  // --- Extended statistics ---
  /**
   * The typical (mean) number of consecutive winning trades. Calculated by
   * grouping winning trades into streaks and averaging their lengths. A value
   * of 0 indicates there were no winning trades.
   */
  typicalWinStreak: number;
  /**
   * The typical (mean) number of consecutive losing trades. Calculated by
   * grouping losing trades into streaks and averaging their lengths. A value
   * of 0 indicates there were no losing trades.
   */
  typicalLossStreak: number;
  /**
   * Average number of bars required to recover from a drawdown. This is
   * measured from the bar when a new equity peak is reached to the bar when
   * that peak is exceeded after a drawdown. If no drawdown occurred the value
   * will be 0.
   */
  meanRecoveryBars: number;
  /**
   * Average time to recover from a drawdown in milliseconds. Converted to
   * human‑readable format when displayed.
   */
  meanRecoveryMs: number;
  /**
   * Skewness of the per‑trade PnL distribution. A positive value indicates a
   * longer right tail (more extreme wins) and a negative value indicates a
   * longer left tail (more extreme losses). Values near zero indicate a
   * symmetric distribution.
   */
  skewness: number;
  /**
   * Excess kurtosis of the per‑trade PnL distribution. Positive values
   * indicate heavy tails (more outliers), negative values indicate light tails.
   */
  kurtosis: number;
  /**
   * Beta (correlation) of the strategy PnL to the underlying market. This
   * measures how much the strategy’s returns move with the market. A value
   * close to zero means the strategy is largely uncorrelated with the
   * underlying. A negative value means the strategy tends to move opposite the
   * market.
   */
  beta: number;
};

type ClassLabel = "BULL" | "BEAR" | "SIDE";

type IntuitionModel = {
  type: "OvR-perceptron";
  heads: { BULL: number[]; BEAR: number[]; SIDE: number[] };
  meta?: { feature?: string; windowLen?: number; savedAt?: number };
  savedAt?: number;
};

/* ----------------- Constants / Keys ----------------- */
const TARGET_BARS = 20000;
const BATCH_SIZE = 4999;
const MAX_BATCHES = 4;
const API_KEYS = [
  "139626f1aaa3426a942e411734ecb8c2",
  "161b08145b264df9bcbf13aed829da19",
  "41e91a08c67c4c2c8a8570f17bb2d917",
  "c7987057e54e4c528a3a05feb9cff435",
];

const FALLBACK_MODEL_KEY = "intuition_model_latest";
const BACKTEST_SNAPSHOT_KEY = "backtest_snapshot_v1";
const BAR_INDEX_KEY = "bars_index_map_v1";
const CACHE_PREFIX = "bars_cache_v1";

/*
 * Deterministic pseudo‑random number generator (LCG).  The backtest and
 * live simulators share this generator to ensure that sampling operations
 * (such as target length selection and probabilistic exits) produce
 * identical sequences given the same seed.  See ML_Live.tsx for the
 * companion implementation.
 */
function makeSeededRand(seed: number): () => number {
  let state = seed >>> 0;
  return function () {
    state = Math.imul(48271, state) % 0x7fffffff;
    return (state & 0x7fffffff) / 0x7fffffff;
  };
}

// Default seed for deterministic simulations.  Modify this value to
// produce a different deterministic sequence.  This constant must be
// identical across the backtest and live simulators for aligned results.
const DEFAULT_RNG_SEED = 123456789;

/* ----------------- Formatters & utils ----------------- */
const nf0 = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
const nf2 = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});
const nf1 = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
});
const fmtUSD = (x: number) =>
  `${x >= 0 ? "+" : "-"}$${nf2.format(Math.abs(x))}`;
const fmtNum = (x: number, d: 0 | 1 | 2 = 0) =>
  d === 0 ? nf0.format(x) : d === 1 ? nf1.format(x) : nf2.format(x);
const fmtPct = (x: number, d: 0 | 1 = 1) =>
  d === 0 ? `${nf0.format(Math.round(x))}%` : `${nf1.format(x)}%`;
const fmtPrice = (x: number) => `$${nf2.format(x)}`;
const toMs = (t: any) => {
  const n = +t;
  return !isNaN(n) ? (n > 1e12 ? n : n * 1000) : Date.parse(t);
};
function calcMaxDrawdown(eq: number[]) {
  let peak = -Infinity,
    worst = 0;
  for (const v of eq) {
    peak = Math.max(peak, v);
    worst = Math.min(worst, v - peak);
  }
  return Math.abs(worst);
}
function stdev(a: number[]) {
  if (a.length < 2) return 0;
  const m = a.reduce((s, x) => s + x, 0) / a.length;
  return Math.sqrt(a.reduce((s, x) => (x - m) ** 2, 0) / (a.length - 1));
}
function downsideStdev(a: number[]) {
  if (!a.length) return 0;
  const d = a.filter((x) => x < 0);
  if (!d.length) return 0;
  return Math.sqrt(d.reduce((s, x) => s + x * x, 0) / d.length);
}
const median = (a: number[]) => {
  if (!a.length) return 0;
  const b = [...a].sort((x, y) => x - y);
  const m = Math.floor(b.length / 2);
  return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2;
};
function quantile(a: number[], q: number) {
  if (!a.length) return 0;
  const b = [...a].sort((x, y) => x - y);
  const idx = Math.min(
    b.length - 1,
    Math.max(0, Math.floor(q * (b.length - 1)))
  );
  return b[idx];
}
function fmtDuration(ms: number) {
  // Convert a duration in milliseconds into a human‑readable string that always
  // includes seconds. Days, hours and minutes are only shown if non‑zero to
  // keep the output concise. For example: 1d 2h 3m 45s, 3m 5s, 0s, etc.
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const d = Math.floor(totalSec / (24 * 3600));
  const h = Math.floor((totalSec % (24 * 3600)) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  // Always include seconds so that the tooltip explicitly shows the smallest unit.
  parts.push(`${s}s`);
  return parts.join(" ");
}

/* ----------------- Features & scoring ----------------- */
function makeF(r: Row[], i: number) {
  const c = r[i].close,
    p = i > 0 ? r[i - 1].close : c;
  const ret = (c - p) / (p || 1);
  const rg = (r[i].high - r[i].low) / Math.max(r[i].high, 1e-9);
  let avg = 0,
    n = 0;
  for (let k = Math.max(0, i - 9); k <= i; k++) {
    avg += r[k].close;
    n++;
  }
  avg /= n || 1;
  const dev = (c - avg) / (avg || 1);
  return [ret, rg, dev];
}
const scoreHeadVector = (f: number[], head: number[]) => {
  const bias = head?.[0] ?? 0;
  const K = Math.min(f.length, Math.max(0, (head?.length ?? 1) - 1));
  let s = bias;
  for (let i = 0; i < K; i++) s += f[i] * (head[i + 1] ?? 0);
  return s;
};
const scoreHeadsFlexible = (
  f: number[],
  h: { BULL: number[]; BEAR: number[]; SIDE: number[] }
) => ({
  BULL: scoreHeadVector(f, h.BULL),
  BEAR: scoreHeadVector(f, h.BEAR),
  SIDE: scoreHeadVector(f, h.SIDE),
});
function softmax3(s: { BULL: number; BEAR: number; SIDE: number }) {
  const m = Math.max(s.BULL, s.BEAR, s.SIDE);
  const eB = Math.exp(s.BULL - m),
    eR = Math.exp(s.BEAR - m),
    eS = Math.exp(s.SIDE - m);
  const Z = eB + eR + eS || 1;
  return { BULL: eB / Z, BEAR: eR / Z, SIDE: eS / Z };
}
const argmax3p = (p: {
  BULL: number;
  BEAR: number;
  SIDE: number;
}): ClassLabel =>
  p.BULL >= p.BEAR && p.BULL >= p.SIDE
    ? "BULL"
    : p.BEAR >= p.SIDE
    ? "BEAR"
    : "SIDE";
/* ----------------- Storage helpers ----------------- */
function readIndex(): Record<string, Record<string, string>> {
  try {
    return JSON.parse(localStorage.getItem(BAR_INDEX_KEY) || "{}");
  } catch {
    return {};
  }
}
function writeIndex(x: Record<string, Record<string, string>>) {
  try {
    localStorage.setItem(BAR_INDEX_KEY, JSON.stringify(x));
  } catch {}
}
const makeKey = (s: string, i: string) => `${CACHE_PREFIX}:${s}:${i}`;
function loadAllRows(symbol: string, interval: string): Row[] {
  try {
    const idx = readIndex();
    const key = idx?.[symbol]?.[interval] ?? makeKey(symbol, interval);
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const obj = JSON.parse(raw);
    if (!Array.isArray(obj?.bars)) return [];
    const rows: Row[] = obj.bars.map((b: any) => ({
      time: b.time,
      open: +b.open,
      high: +b.high,
      low: +b.low,
      close: +b.close,
      ts: toMs(b.time),
    }));
    return rows.filter((x) => isFinite(x.ts)).sort((a, b) => a.ts - b.ts);
  } catch {
    return [];
  }
}
function saveRows(symbol: string, interval: string, rows: Row[]) {
  const key = makeKey(symbol, interval);
  const payload = { symbol, interval, bars: rows };
  const idx = readIndex();
  if (!idx[symbol]) idx[symbol] = {};
  idx[symbol][interval] = key;
  try {
    localStorage.setItem(key, JSON.stringify(payload));
  } catch {
    clearAllCachesExceptModel();
    try {
      localStorage.setItem(key, JSON.stringify(payload));
    } catch {
      const trimmed = rows.slice(-15000);
      try {
        localStorage.setItem(
          key,
          JSON.stringify({ symbol, interval, bars: trimmed })
        );
      } catch {
        const t2 = rows.slice(-10000);
        localStorage.setItem(
          key,
          JSON.stringify({ symbol, interval, bars: t2 })
        );
      }
    }
  }
  writeIndex(idx);
}
function clearAllCachesExceptModel() {
  const keep = new Set<string>([FALLBACK_MODEL_KEY, BACKTEST_SNAPSHOT_KEY]);
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    try {
      const v = localStorage.getItem(k);
      if (!v) continue;
      const j = JSON.parse(v);
      if (coerceToIntuitionModel(j)) keep.add(k);
    } catch {}
  }
  const keys: string[] = [];
  for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i)!);
  for (const k of keys) {
    if (!keep.has(k)) {
      try {
        localStorage.removeItem(k);
      } catch {}
    }
  }
}

/* ----------- Model coercion & validation ----------- */
function coerceToIntuitionModel(raw: any): IntuitionModel | null {
  if (!raw || typeof raw !== "object") return null;
  const toArrHeads = (h: any) => {
    try {
      const BULL = (h.BULL ?? []).map((z: any) => +z || 0);
      const BEAR = (h.BEAR ?? []).map((z: any) => +z || 0);
      const SIDE = (h.SIDE ?? []).map((z: any) => +z || 0);
      if (
        [BULL, BEAR, SIDE].every(
          (arr) =>
            Array.isArray(arr) && arr.length >= 1 && arr.every(Number.isFinite)
        )
      )
        return { BULL, BEAR, SIDE };
      return null;
    } catch {
      return null;
    }
  };
  if (raw.type === "OvR-perceptron" && raw.heads) {
    let H = toArrHeads(raw.heads);
    if (!H && raw.heads.BULL?.w) {
      try {
        const B = [
          +(raw.heads.BULL.bias ?? 0),
          ...raw.heads.BULL.w.map((z: any) => +z || 0),
        ];
        const R = [
          +(raw.heads.BEAR.bias ?? 0),
          ...raw.heads.BEAR.w.map((z: any) => +z || 0),
        ];
        const S = [
          +(raw.heads.SIDE.bias ?? 0),
          ...raw.heads.SIDE.w.map((z: any) => +z || 0),
        ];
        H = { BULL: B, BEAR: R, SIDE: S };
      } catch {
        H = null;
      }
    }
    if (H)
      return {
        type: "OvR-perceptron",
        heads: H,
        meta: raw.meta,
        savedAt: raw.savedAt ?? raw.meta?.savedAt ?? Date.now(),
      };
  }
  if (raw.BULL && raw.BEAR && raw.SIDE) {
    const H = toArrHeads(raw);
    if (H)
      return {
        type: "OvR-perceptron",
        heads: H,
        meta: raw.meta,
        savedAt: raw.savedAt ?? raw.meta?.savedAt ?? Date.now(),
      };
  }
  return null;
}
function validateModel(m: any): string | null {
  const mm = coerceToIntuitionModel(m);
  if (!mm) return "no valid perceptron model found";
  for (const k of ["BULL", "BEAR", "SIDE"] as const) {
    const arr = (mm.heads as any)[k];
    if (!Array.isArray(arr) || arr.length < 1)
      return `heads.${k} must have at least [bias]`;
    if (!arr.every((x: any) => typeof x === "number" && isFinite(x)))
      return `heads.${k} must be all finite numbers`;
  }
  return null;
}
function tryLoadModelFromStorage(): IntuitionModel | null {
  try {
    const rawSnap = localStorage.getItem(BACKTEST_SNAPSHOT_KEY);
    if (rawSnap) {
      const snap = JSON.parse(rawSnap);
      const mm = coerceToIntuitionModel(snap?.model);
      if (mm) return mm;
    }
  } catch {}
  try {
    const raw = localStorage.getItem(FALLBACK_MODEL_KEY);
    if (raw) {
      const j = JSON.parse(raw);
      const mm = coerceToIntuitionModel(j);
      if (mm) return mm;
    }
  } catch {}
  let best: { m: IntuitionModel; t: number } | null = null;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    try {
      const v = localStorage.getItem(k);
      if (!v || v.length < 10) continue;
      const j = JSON.parse(v);
      const mm = coerceToIntuitionModel(j);
      if (mm) {
        const t = mm.savedAt ?? mm.meta?.savedAt ?? Date.now();
        if (!best || t > best.t) best = { m: mm, t };
      }
    } catch {}
  }
  return best?.m ?? null;
}

// Enumerate all available models in localStorage along with their keys. This
// helper scans localStorage and returns an array of objects containing
// the key and the parsed IntuitionModel. Invalid entries are ignored.
function listAvailableModels(): { key: string; model: IntuitionModel }[] {
  const list: { key: string; model: IntuitionModel }[] = [];
  // Include snapshot and fallback if valid
  try {
    const rawSnap = localStorage.getItem(BACKTEST_SNAPSHOT_KEY);
    if (rawSnap) {
      const snap = JSON.parse(rawSnap);
      const mm = coerceToIntuitionModel(snap?.model);
      if (mm) list.push({ key: BACKTEST_SNAPSHOT_KEY, model: mm });
    }
  } catch {}
  try {
    const raw = localStorage.getItem(FALLBACK_MODEL_KEY);
    if (raw) {
      const j = JSON.parse(raw);
      const mm = coerceToIntuitionModel(j);
      if (mm) list.push({ key: FALLBACK_MODEL_KEY, model: mm });
    }
  } catch {}
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    try {
      const v = localStorage.getItem(k);
      if (!v || v.length < 10) continue;
      const j = JSON.parse(v);
      const mm = coerceToIntuitionModel(j);
      if (mm) {
        // Avoid duplicates of snapshot/fallback keys already added
        if (!list.some((x) => x.key === k)) list.push({ key: k, model: mm });
      }
    } catch {}
  }
  return list;
}

/* ----------------- TwelveData fetching (4×4,999) ----------------- */
const tdIntervalFromUI = (iv: string) => iv;
const sleep = (ms: number) => new Promise((res) => setTimeout(res, ms));
let apiKeyRot = 0;
const nextKey = () => API_KEYS[apiKeyRot++ % API_KEYS.length];

async function fetchBatch(
  symbol: string,
  interval: string,
  endISO?: string
): Promise<Row[]> {
  const key = nextKey();
  const params = new URLSearchParams({
    symbol,
    interval,
    outputsize: String(BATCH_SIZE),
    order: "ASC",
    apikey: key,
  });
  if (endISO) params.set("end_date", endISO);
  const url = `https://api.twelvedata.com/time_series?${params.toString()}`;
  const r = await fetch(url);
  const j = await r.json();
  if (!j || !j.values || !Array.isArray(j.values)) return [];
  const rows: Row[] = j.values
    .map((v: any) => ({
      time: v.datetime,
      open: +v.open,
      high: +v.high,
      low: +v.low,
      close: +v.close,
      ts: toMs(v.datetime),
    }))
    .filter((x: Row) => isFinite(x.ts))
    .sort((a: Row, b: Row) => a.ts - b.ts);
  return rows;
}
const dedupeSort = (a: Row[]) => {
  const m = new Map<number, Row>();
  for (const r of a) m.set(r.ts, r);
  return Array.from(m.values()).sort((x, y) => x.ts - y.ts);
};

async function ensureBars(
  symbol: string,
  interval: string,
  setLoadingMsg: (s: string) => void,
  setFetchProgress: (p: number) => void,
  forceRefresh: boolean = false
): Promise<Row[]> {
  // Attempt to load any cached bars for the given symbol and interval.  If
  // there are already at least TARGET_BARS rows cached and the caller did
  // not explicitly request a refresh, use the cache and avoid any
  // network calls.  Otherwise, fetch additional bars from the TwelveData
  // API in batches until either TARGET_BARS rows have been gathered or
  // MAX_BATCHES requests have been made.  Newly fetched bars are
  // persisted back into localStorage via saveRows.
  const cached = loadAllRows(symbol, interval);
  const need = TARGET_BARS;
  // If we have enough cached data and no refresh is forced, return it.
  if (!forceRefresh && cached.length >= need) {
    try {
      setLoadingMsg("");
    } catch {
      /* ignore */
    }
    setFetchProgress(100);
    return cached.slice(-need);
  }
  // Begin a progressive fetch of bar data.  Start with whatever is
  // already cached to minimise network usage.  We'll append newer data
  // and prepend older data as necessary.
  let collected: Row[] = cached.slice();
  // Determine the end cursor for pagination.  When collecting older
  // bars, we set endISO to just before the oldest collected bar.  A
  // value of undefined instructs the API to return the most recent
  // batch.
  let endISO: string | undefined = undefined;
  if (collected.length) {
    const oldest = collected[0].time;
    const t = new Date(oldest);
    // back off one minute to avoid overlapping the oldest record
    t.setMinutes(t.getMinutes() - 1);
    endISO = t.toISOString();
  }
  // Reset progress
  setFetchProgress(0);
  setLoadingMsg("Fetching bars…");
  let batches = 0;
  while (collected.length < need && batches < MAX_BATCHES) {
    try {
      // Fetch the next batch of bars.  Passing endISO will request bars
      // that end at endISO; omitting it will fetch the most recent batch.
      const batch: Row[] = await fetchBatch(symbol, interval, endISO);
      // If no data returned, break to avoid infinite loops
      if (!batch || !batch.length) {
        break;
      }
      // Merge the batch into our collected set.  Since fetchBatch
      // returns bars sorted ascending, we can simply concatenate and
      // deduplicate by timestamp.  We dedupe after concat to avoid
      // duplicate timestamps when refetching overlapping ranges.
      collected = dedupeSort(collected.concat(batch));
      // Advance the end cursor to fetch older bars on next iteration.
      const oldest = collected[0]?.time;
      if (oldest) {
        const t2 = new Date(oldest);
        t2.setMinutes(t2.getMinutes() - 1);
        endISO = t2.toISOString();
      }
      batches++;
      // Update progress based on number of bars collected.  Clamp to 99% so
      // that the final setFetchProgress(100) occurs only once fetching
      // completes.
      const pct = Math.min(99, Math.floor((collected.length / need) * 100));
      setFetchProgress(pct);
    } catch (e) {
      // Ignore individual batch failures and proceed to next batch
      batches++;
    }
  }
  // Persist the collected bars to storage so future runs can reuse them.
  if (collected.length) {
    // Only keep the last 'need' bars in storage to limit size.  We
    // store all collected bars to maintain continuity but can trim if
    // necessary.
    saveRows(symbol, interval, collected);
  }
  // Clear loading message and set progress to complete
  try {
    setLoadingMsg("");
  } catch {
    /* ignore */
  }
  setFetchProgress(100);
  // Return the most recent slice of bars up to the requested amount
  return collected.slice(-need);
}

// Backtest.tsx (Part 2/3)
export default function Backtest() {
  /* Data & model */
  const [rows, setRows] = useState<Row[]>([]);
  const [model, setModel] = useState<IntuitionModel | null>(null);

  /* Instrument & timeframe selectors */
  const [symbol, setSymbol] = useState<string>("XAU/USD");
  const [interval, setIntervalStr] = useState<string>("15min");

  /* Basic params */
  const [unitValue, setUnitValue] = useState<number>(100);
  const [stopPts, setStopPts] = useState(0);
  const [tpPts, setTpPts] = useState(0);
  const [barOrder, setBarOrder] = useState<"stop-first" | "tp-first">(
    "stop-first"
  );

  /**
   * The key of the model used when the most recent statistics were computed.
   * When backtest results are available this value is appended to the page
   * title so that users know which model produced the current stats.  It is
   * updated after each call to simulateBacktest or simulateBacktestProgressive.
   * If no specific model has been selected the fallback key is used.
   */
  const [statsModelName, setStatsModelName] = useState<string | null>(null);

  /* Advanced panel */
  const [advOpen, setAdvOpen] = useState<boolean>(false);

  // Exit: Target range (sampled per trade)
  const [lenMin, setLenMin] = useState<number>(10);
  const [lenMax, setLenMax] = useState<number>(60);
  const [pullPct, setPullPct] = useState<number>(50);
  const [pushPct, setPushPct] = useState<number>(0);

  // NEW: Enforced trade duration
  const [minTradeBars, setMinTradeBars] = useState<number>(1);
  const [maxTradeBars, setMaxTradeBars] = useState<number>(120);

  // Confidence / Hysteresis
  const [hysteresis, setHysteresis] = useState<number>(1);
  const [enterMargin, setEnterMargin] = useState<number>(0.0);
  const [holdMargin, setHoldMargin] = useState<number>(-0.05);

  // Trailing
  const [useTrailing, setUseTrailing] = useState<boolean>(false);
  const [trailPts, setTrailPts] = useState<number>(20);

  // Class frequency biases
  const [biasBull, setBiasBull] = useState<number>(50);
  const [biasBear, setBiasBear] = useState<number>(50);
  const [biasSide, setBiasSide] = useState<number>(50);

  /* Automation Options */
  const [autoOpen, setAutoOpen] = useState<boolean>(false);
  const [minTradesGuard, setMinTradesGuard] = useState<number>(50);

  // --- Utility: compute approximate bar duration in milliseconds based on the
  // selected interval. This is used for tooltips to convert bar counts into
  // human‑readable durations.
  const barDurationMs = useMemo(() => {
    switch (interval) {
      case "1min":
        return 60 * 1000;
      case "5min":
        return 5 * 60 * 1000;
      case "15min":
        return 15 * 60 * 1000;
      case "30min":
        return 30 * 60 * 1000;
      case "1h":
        return 60 * 60 * 1000;
      case "4h":
        return 4 * 60 * 60 * 1000;
      case "1day":
        return 24 * 60 * 60 * 1000;
      default:
        return 60 * 1000;
    }
  }, [interval]);

  // The tooltip definitions have been moved below, after overallStats is
  // declared, to avoid temporal dead zone issues.

  type AutoSpace = "BB" | "SH" | "HOLD" | "BS" | "BR" | "PP" | "TPSL";
  const [autoSpace, setAutoSpace] = useState<AutoSpace>("BB");
  // Multi-method selection for how objectives are weighted in automation.  Three
  // modes are supported:
  //  - "Even": All selected objectives receive equal weight regardless of order.
  //  - "RankedExp": Objectives are weighted exponentially by order (0.6^i).
  //  - "RankedLin": Objectives are weighted linearly by order (n-i), where n is
  //    the total number of objectives.  This allows users to choose between
  //    exponential decay and linear decay for ranked objectives.
  type MultiMethod = "Even" | "RankedExp" | "RankedLin";
  const [autoMultiMethod, setAutoMultiMethod] =
    useState<MultiMethod>("RankedExp");

  // HOLD search ranges
  const HOLD_ENTER_MIN = 0.0,
    HOLD_ENTER_MAX = 0.5;
  // NOTE: HOLD_ENTER_STEP and HOLD_HOLD_STEP are no longer static values.  The
  // automation search space for the HOLD strategy is now computed dynamically
  // inside runCompositeObjective to yield roughly 10 000 combinations.  These
  // constants remain as range boundaries, while the actual step sizes are
  // derived from the desired total combination count.  Keeping the
  // definitions here avoids breaking existing references elsewhere in the
  // component, but they are not used for stepping through the search space.
  const HOLD_ENTER_STEP = 0.01;
  const HOLD_HOLD_MIN = -0.2,
    HOLD_HOLD_MAX = 0.4;
  const HOLD_HOLD_STEP = 0.02;

  // === Objectives (Long/Short balance remains selectable) ===
  type ObjKey =
    | "winrate"
    | "pf"
    | "netpnl"
    | "avgwin"
    | "avgloss"
    | "sharpe"
    | "sortino"
    | "peak_per_trade"
    | "min_avg_dd"
    | "ls_balance"
    | "max_rr"
    | "max_win_streak"
    | "min_loss_streak"
    | "min_recovery_time"
    | "min_beta";

  const objectiveDefs: { key: ObjKey; label: string; preferHigher: boolean }[] =
    [
      { key: "winrate", label: "Maximize Win Rate", preferHigher: true },
      { key: "pf", label: "Maximize Profit Factor", preferHigher: true },
      { key: "netpnl", label: "Maximize Net PnL", preferHigher: true },
      { key: "avgwin", label: "Maximize Average Win", preferHigher: true },
      { key: "avgloss", label: "Minimize Average Loss", preferHigher: false },
      { key: "sharpe", label: "Sharpe Ratio", preferHigher: true },
      { key: "sortino", label: "Sortino Ratio", preferHigher: true },
      { key: "peak_per_trade", label: "Maximize Peak", preferHigher: true },
      { key: "min_avg_dd", label: "Minimize Drawdown", preferHigher: false },
      { key: "ls_balance", label: "Balance Long vs Short", preferHigher: true },

      // New automation objectives
      {
        key: "max_rr",
        label: "Maximize Risk to Reward",
        preferHigher: true,
      },
      {
        key: "max_win_streak",
        label: "Maximize Win Streak",
        preferHigher: true,
      },
      {
        key: "min_loss_streak",
        label: "Minimize Loss Streak",
        preferHigher: false,
      },
      {
        key: "min_recovery_time",
        label: "Time to Recovery",
        preferHigher: false,
      },
      {
        key: "min_beta",
        label: "Minimize Market Beta",
        preferHigher: false,
      },
    ];

  const [selectedObjectives, setSelectedObjectives] = useState<ObjKey[]>([]);
  const [autoRunning, setAutoRunning] = useState<boolean>(false);
  const [autoMsg, setAutoMsg] = useState<string>("");
  const [autoProgress, setAutoProgress] = useState<number>(0);
  const [lastAutoMsg, setLastAutoMsg] = useState<string>("");

  // Download the current backtest statistics and trades as a JSON file. This
  // includes the aggregated statistics (overallStats) as well as the array of
  // executed trades. The file is named "backtest_results.json" and is
  // generated on the fly when the user clicks the download button.
  const handleDownloadJson = () => {
    // When downloading the model, export the exact file from localStorage without
    // altering its name or contents. If a specific model key has been
    // loaded (modelName), use that key to retrieve and download the raw
    // string. Otherwise fall back to the predefined snapshot or fallback
    // keys, if available. If none exist, do nothing.
    let key: string | null = null;
    if (modelName) {
      key = modelName;
    } else {
      // Try the snapshot key first, then the fallback key
      if (localStorage.getItem(BACKTEST_SNAPSHOT_KEY)) {
        key = BACKTEST_SNAPSHOT_KEY;
      } else if (localStorage.getItem(FALLBACK_MODEL_KEY)) {
        key = FALLBACK_MODEL_KEY;
      }
    }
    if (!key) return;
    const raw = localStorage.getItem(key);
    if (!raw) return;
    // Create a blob using the raw string without reformatting.
    const blob = new Blob([raw], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    // Use the key as the filename exactly, without adding extensions.
    a.download = key;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 100);
  };

  /* Output */
  const [trades, setTrades] = useState<Trade[]>([]);
  const [overallStats, setOverallStats] = useState<Stats | null>(null);

  // Derived equity time series for the backtest.  Computes the cumulative PnL
  // per trade and separates positive and negative segments into distinct keys.
  const equityData = useMemo(() => {
    if (!trades || trades.length === 0) return [];
    // accumulate PnL across trades
    let cum = 0;
    const vals: number[] = trades.map((tr) => {
      cum += tr.pnl;
      return cum;
    });
    // classification helper for sign
    const sign = (x: number): number => (x > 0 ? 1 : x < 0 ? -1 : 0);
    const pos: Array<number | null> = Array(vals.length).fill(null);
    const neg: Array<number | null> = Array(vals.length).fill(null);
    // fill pos/neg arrays with contiguous segments
    for (let i = 0; i < vals.length - 1; i++) {
      const sNext = sign(vals[i + 1]);
      if (sNext > 0) {
        pos[i] = vals[i];
        pos[i + 1] = vals[i + 1];
      } else if (sNext < 0) {
        neg[i] = vals[i];
        neg[i + 1] = vals[i + 1];
      }
    }
    if (vals.length === 1) {
      const s = sign(vals[0]);
      if (s > 0) pos[0] = vals[0];
      else if (s < 0) neg[0] = vals[0];
    }
    return vals.map((v, idx) => ({
      trade: idx + 1,
      cumPnL: v,
      pos: pos[idx],
      neg: neg[idx],
    }));
  }, [trades]);

  // Track the key (name) of the model loaded from localStorage. When a model
  // is loaded from storage we record the key under which it was found so we
  // can display this value in the UI instead of a generic “OK”. If no model
  // is loaded the name remains null.
  const [modelName, setModelName] = useState<string | null>(null);

  // Whether the model selection dropdown is open. When true a list of
  // available models is rendered below the model chip. Selecting a model
  // updates the loaded model and closes the dropdown.
  const [modelDropdownOpen, setModelDropdownOpen] = useState<boolean>(false);

  // List of available models (key + parsed object). Populated on demand when
  // the user toggles the dropdown.
  const [availableModels, setAvailableModels] = useState<
    { key: string; model: IntuitionModel }[]
  >([]);

  // File input ref used for uploading a new model.  When the user clicks
  // the "Upload Model" button this ref is triggered to open the native
  // file picker.  Uploaded files must contain either an OvR perceptron
  // (heads with weights) or a predictions array; only perceptron uploads
  // are currently supported here.
  const uploadRef = useRef<HTMLInputElement | null>(null);

  // Handle the upload of a model JSON file.  Reads the file content, parses
  // it, and, if it contains a valid IntuitionModel, saves it into
  // localStorage under a unique key.  The model is then loaded into state
  // and the backtest is re‑run.  If the file does not contain a valid
  // model an alert is shown and no state is updated.
  function handleModelUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        const parsed = JSON.parse(text);
        // Attempt to coerce the parsed object into an IntuitionModel
        const maybeModel = coerceToIntuitionModel(parsed?.model ?? parsed);
        if (maybeModel) {
          // Inject a savedAt timestamp if none exists so that the model
          // sorts correctly in the listAvailableModels helper.
          if (
            !maybeModel.savedAt &&
            !(maybeModel.meta && maybeModel.meta.savedAt)
          ) {
            maybeModel.savedAt = Date.now();
          }
          // Use the file name as the key; if a key already exists under this
          // name it will be overwritten.  If no file name is provided use a
          // timestamp‑based fallback key.
          const key = file.name || `intuition_model_${Date.now()}`;
          try {
            localStorage.setItem(key, JSON.stringify(maybeModel));
          } catch {}
          // Update state and load the newly saved model
          setModel(maybeModel);
          setModelName(key);
          setModelDropdownOpen(false);
          // Immediately run the backtest using the new model.  Avoid
          // refreshing bars unnecessarily; the existing bars will be
          // re-used for consistency.
          onRun();
          return;
        }
        alert("Invalid model file. Expected an OvR perceptron (heads).");
      } catch {
        alert("Failed to parse model file.");
      }
    };
    reader.readAsText(file);
  }

  // Populate the available models list. This scans localStorage for
  // IntuitionModels and stores them in state sorted by their saved timestamp
  // descending (latest first). It is invoked when opening the dropdown.
  function refreshAvailableModels() {
    const list = listAvailableModels();
    // Sort by savedAt descending
    list.sort((a, b) => {
      const ta = a.model.savedAt ?? a.model.meta?.savedAt ?? 0;
      const tb = b.model.savedAt ?? b.model.meta?.savedAt ?? 0;
      return tb - ta;
    });
    setAvailableModels(list);
  }

  // Toggle the model dropdown. When opening, refresh the list of models.
  function handleModelChipClick() {
    if (!modelDropdownOpen) refreshAvailableModels();
    setModelDropdownOpen((v) => !v);
  }

  // Select a model by its localStorage key. Loads the model and updates
  // state accordingly, then closes the dropdown.
  function selectModelKey(k: string) {
    try {
      const raw = localStorage.getItem(k);
      if (raw) {
        const j = JSON.parse(raw);
        const mm = coerceToIntuitionModel(j?.model ?? j);
        if (mm) {
          // update model and key
          setModel(mm);
          setModelName(k);
          setModelDropdownOpen(false);
          // immediately run backtest with the newly selected model
          onRun();
          return;
        }
      }
    } catch {}
    // If failed to load, simply close dropdown
    setModelDropdownOpen(false);
  }

  // Delete a model by its key.  This removes the item from
  // localStorage and refreshes the available models list.  If the
  // deleted model is currently selected the local state is cleared and
  // the backtest is re-run with the next best model.  Errors are
  // silently ignored.
  function deleteModelKey(k: string) {
    try {
      localStorage.removeItem(k);
    } catch {}
    if (modelName === k) {
      setModel(null);
      setModelName(null);
      // run backtest without the removed model so that stats/trades refresh
      onRun();
    }
    // update dropdown list
    refreshAvailableModels();
  }

  // Refresh bars and rerun the backtest when clicking the Bars chip.
  function handleBarsChipClick() {
    if (isLoading || autoRunning) return;
    // When the Bars chip is clicked, fetch the latest TARGET_BARS bars if
    // none are loaded or if the current cache is insufficient.  After
    // fetching, update the rows state and rerun the backtest.  If there
    // are already enough bars and a run isn’t in progress, simply re-run
    // the simulation.
    const needRefresh = rows.length < TARGET_BARS;
    const run = async () => {
      if (needRefresh) {
        // Perform a forced refresh to retrieve bars from the API
        setIsLoading(true);
        setTrades([]);
        setOverallStats(null);
        setSelectedDay(null);
        setProgress(0);
        try {
          const newRows = await ensureBars(
            symbol,
            interval,
            (msg: string) => setLoadingMsg(msg),
            (p: number) => setProgress(p),
            true
          );
          setRows(newRows);
        } catch {
          // ignore errors
        }
        setIsLoading(false);
      }
      // In both cases (fresh fetch or using existing data), run the backtest
      onRun();
    };
    run();
  }

  // Derive tooltips for bar‑based statistics (win/loss streaks, recovery,
  // average win/loss lengths and average trade length) based on the current
  // statistics and bar duration. This hook is defined after overallStats is
  // initialized to prevent temporal dead zone errors.
  const statTooltips = useMemo(() => {
    if (!overallStats)
      return {
        win: "",
        loss: "",
        recovery: "",
        avgWin: "",
        avgLoss: "",
        avgLen: "",
      };
    const winMs = overallStats.typicalWinStreak * barDurationMs;
    const lossMs = overallStats.typicalLossStreak * barDurationMs;
    const recMs = overallStats.meanRecoveryBars * barDurationMs;
    const avgWinMs = overallStats.avgWinLen * barDurationMs;
    const avgLossMs = overallStats.avgLossLen * barDurationMs;
    const avgLenMs = overallStats.avgLen * barDurationMs;
    return {
      win: fmtDuration(winMs),
      loss: fmtDuration(lossMs),
      recovery: fmtDuration(recMs),
      avgWin: fmtDuration(avgWinMs),
      avgLoss: fmtDuration(avgLossMs),
      avgLen: fmtDuration(avgLenMs),
    };
  }, [overallStats, barDurationMs]);

  /* Calendar selection */
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  // Compute the total PnL for the currently displayed month. This sums the PnL
  // of all trades whose exit timestamp falls within the same year and month
  // as the selected calendar month. It updates automatically when trades or
  // month changes.
  const monthPnL = useMemo(() => {
    return trades.reduce((sum, tr) => {
      const d = new Date(tr.exitTs);
      return d.getFullYear() === month.getFullYear() &&
        d.getMonth() === month.getMonth()
        ? sum + tr.pnl
        : sum;
    }, 0);
  }, [trades, month]);

  // Deprecated: previously used to derive a simple equity curve for
  // charting.  The new SVG-based equity chart derives cumulative
  // PnL directly within eqMetrics and no longer needs this array.

  // Hover state for the equity chart.  When the user moves the mouse over
  // the chart, we determine the nearest trade index and store its
  // coordinates and cumulative equity.  This state drives the tooltip and
  // highlight dot on the graph.
  const [hoverPt, setHoverPt] = useState<{
    idx: number;
    x: number;
    y: number;
    equity: number;
  } | null>(null);

  // Compute chart metrics for the equity curve including the line path,
  // filled area, baseline, axis ticks and colours.  The y‑axis is scaled
  // to the min/max of cumulative PnL and the x‑axis is the trade count.
  const eqMetrics = useMemo(() => {
    // The custom SVG equity curve has been replaced by a Recharts implementation.
    // Return a minimal placeholder object immediately to bypass expensive computations.
    return {
      path: "",
      areaPath: "",
      baselineY: 0,
      baselineRatio: 0,
      xTicks: [] as { x: number; label: string }[],
      yTicks: [] as { y: number; label: string }[],
      colorLine: "",
      lineStops: [] as { offset: number; color: string }[],
      pts: [] as { x: number; y: number; v: number }[],
    };
    // accumulate PnL per trade
    let cum = 0;
    const vals: number[] = trades.map((tr) => {
      cum += tr.pnl;
      return cum;
    });
    let min = Math.min(...vals);
    let max = Math.max(...vals);
    if (min === max) {
      min = min - 1;
      max = max + 1;
    }
    const range = max - min;
    const n = vals.length;
    const pts = vals.map((v, idx) => {
      const x = n === 1 ? 0 : (idx / (n - 1)) * 100;
      const y = 100 - ((v - min) / range) * 100;
      return { x, y, v };
    });
    const path = pts
      .map((p, idx) => (idx === 0 ? `M ${p.x},${p.y}` : `L ${p.x},${p.y}`))
      .join(" ");
    // baseline at zero PnL
    const baselineRatio = (0 - min) / range;
    const baselineY = 100 - baselineRatio * 100;
    const areaPath =
      pts.length > 0
        ? `M ${pts[0].x},${baselineY} L ${pts[0].x},${pts[0].y} ` +
          pts
            .slice(1)
            .map((p) => `L ${p.x},${p.y}`)
            .join(" ") +
          ` L ${pts[pts.length - 1].x},${baselineY} Z`
        : "";
    const finalEq = vals[vals.length - 1];
    // Determine number of x‑axis ticks based on trade count.  Larger
    // datasets produce more labels but no more than 15 to avoid clutter.
    const tickCount = Math.min(15, Math.max(4, Math.floor(n / 25)));
    const xTicks: { x: number; label: string }[] = [];
    for (let i = 0; i <= tickCount; i++) {
      const ratio = i / tickCount;
      const x = ratio * 100;
      const tradeIndex = n > 1 ? Math.round(ratio * (n - 1)) + 1 : 1;
      xTicks.push({ x, label: String(tradeIndex) });
    }
    // Y‑axis ticks evenly spaced across min→max.  Use nf0 to format
    // numbers without a currency symbol (e.g., 240,000 instead of +$240,000).
    const yTicks: { y: number; label: string }[] = [];
    const yLabelsCount = 4;
    for (let i = 0; i <= yLabelsCount; i++) {
      const ratio = i / yLabelsCount;
      const v = min + ratio * range;
      const y = 100 - ratio * 100;
      yTicks.push({ y, label: nf0.format(v) });
    }
    // Compute gradient stops for the line.  To emulate the screenshot
    // aesthetic the line switches colour when the cumulative PnL crosses
    // zero.  We define a horizontal linearGradient along the x‑axis and
    // insert stops at every zero crossing.  Each stop pair shares the
    // same offset to ensure a crisp transition between colours.  The
    // colours themselves are bright neon hues (green for positive, red
    // for negative).
    const posColor = "#5ef3c7";
    const negColor = "#f87171";
    const lineStops: { offset: number; color: string }[] = [];
    if (pts.length > 0) {
      let prevSign = vals[0] >= 0;
      // Start at 0% with the initial sign
      lineStops.push({ offset: 0, color: prevSign ? posColor : negColor });
      for (let i = 1; i < vals.length; i++) {
        const sign = vals[i] >= 0;
        if (sign !== prevSign) {
          // Find the x‑coordinate where the equity crosses zero between
          // points i-1 and i.  Interpolate both the equity and x
          // positions to determine this offset precisely.
          const v1 = vals[i - 1];
          const v2 = vals[i];
          const x1 = pts[i - 1].x;
          const x2 = pts[i].x;
          const c = v2 !== v1 ? (0 - v1) / (v2 - v1) : 0;
          const crossX = x1 + c * (x2 - x1);
          const crossOffset = Math.max(0, Math.min(1, crossX / 100));
          const prevColor = prevSign ? posColor : negColor;
          const nextColor = sign ? posColor : negColor;
          // Insert two stops at the same offset: one with the previous
          // colour and one with the new colour.  This creates a hard
          // transition in the gradient stroke.
          lineStops.push({ offset: crossOffset, color: prevColor });
          lineStops.push({ offset: crossOffset, color: nextColor });
          prevSign = sign;
        }
      }
      // End at 100% with the sign of the last point
      lineStops.push({ offset: 1, color: prevSign ? posColor : negColor });
    }

    return {
      path,
      areaPath,
      baselineY,
      baselineRatio,
      xTicks,
      yTicks,
      colorLine: finalEq >= 0 ? posColor : negColor,
      lineStops,
      pts,
    };
  }, [trades]);

  /* Loading */
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [progress, setProgress] = useState(0);

  /* ==== Load model/bars on mount ==== */
  useEffect(() => {
    // Custom loader that returns both the best model and the key (name) it
    // was loaded from. We scan all localStorage entries and select the
    // IntuitionModel with the latest savedAt timestamp, recording its key.
    function loadModelWithName(): {
      model: IntuitionModel | null;
      name: string | null;
    } {
      let best: { m: IntuitionModel; k: string; t: number } | null = null;
      // Prefer the snapshot or fallback if they contain a valid model
      try {
        const rawSnap = localStorage.getItem(BACKTEST_SNAPSHOT_KEY);
        if (rawSnap) {
          const snap = JSON.parse(rawSnap);
          const mm = coerceToIntuitionModel(snap?.model);
          if (mm) {
            const t = mm.savedAt ?? mm.meta?.savedAt ?? Date.now();
            best = { m: mm, k: BACKTEST_SNAPSHOT_KEY, t };
          }
        }
      } catch {}
      try {
        const raw = localStorage.getItem(FALLBACK_MODEL_KEY);
        if (raw) {
          const j = JSON.parse(raw);
          const mm = coerceToIntuitionModel(j);
          if (mm) {
            const t = mm.savedAt ?? mm.meta?.savedAt ?? Date.now();
            if (!best || t > best.t) best = { m: mm, k: FALLBACK_MODEL_KEY, t };
          }
        }
      } catch {}
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i)!;
        try {
          const v = localStorage.getItem(k);
          if (!v || v.length < 10) continue;
          const j = JSON.parse(v);
          const mm = coerceToIntuitionModel(j);
          if (mm) {
            const t = mm.savedAt ?? mm.meta?.savedAt ?? Date.now();
            if (!best || t > best.t) best = { m: mm, k: k, t };
          }
        } catch {}
      }
      return best
        ? { model: best.m, name: best.k }
        : { model: null, name: null };
    }
    const { model: mdl, name: mName } = loadModelWithName();
    if (mdl && !validateModel(mdl)) setModel(mdl);
    setModelName(mName);
    const cached = loadAllRows(symbol, interval);
    if (cached.length) setRows(cached.slice(-TARGET_BARS));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---- Bias helpers ---- */
  function normalizedPriors(
    bBull = biasBull,
    bBear = biasBear,
    bSide = biasSide
  ) {
    const s = Math.max(1e-9, bBull + bBear + bSide);
    return { BULL: bBull / s, BEAR: bBear / s, SIDE: bSide / s };
  }
  function blendStrength(bBull = biasBull, bBear = biasBear, bSide = biasSide) {
    const d =
      Math.abs(bBull - 50) + Math.abs(bBear - 50) + Math.abs(bSide - 50);
    return Math.max(0, Math.min(1, d / 150));
  }

  const readyModel = !!(model && (model as any).heads);
  const readyBars = rows.length > 0;

  /* ------------ Core simulator with enforced Min/Max duration + guaranteed stop cap ------------ */
  function simulateBacktest(
    data: Row[],
    opts: {
      bull?: number;
      bear?: number;
      side?: number;
      hyst?: number;
      enterM?: number;
      holdM?: number;
      pullPct?: number;
      pushPct?: number;
      stopPts?: number;
      tpPts?: number;
    } = {}
  ) {
    return _simulateInternal(data, opts, undefined);
  }

  async function simulateBacktestProgressive(
    data: Row[],
    opts: {
      bull?: number;
      bear?: number;
      side?: number;
      hyst?: number;
      enterM?: number;
      holdM?: number;
      pullPct?: number;
      pushPct?: number;
      stopPts?: number;
      tpPts?: number;
    } = {},
    onProg?: (p01: number) => void
  ) {
    return _simulateInternal(data, opts, onProg);
  }

  function _simulateInternal(
    r: Row[],
    opts: {
      bull?: number;
      bear?: number;
      side?: number;
      hyst?: number;
      enterM?: number;
      holdM?: number;
      pullPct?: number;
      pushPct?: number;
      stopPts?: number;
      tpPts?: number;
    } = {},
    onProg?: (p01: number) => void
  ) {
    const bBull = opts.bull ?? biasBull;
    const bBear = opts.bear ?? biasBear;
    const bSide = opts.side ?? biasSide;
    const hyst = Math.max(1, opts.hyst ?? hysteresis);
    const enterM = opts.enterM ?? enterMargin;
    const holdM = opts.holdM ?? holdMargin;

    // Initialise deterministic random number generator.  Using the same
    // seed as the live simulator ensures that all sampling operations
    // (target lengths and probabilistic exits) are reproducible and
    // identical across backtest and live when settings match.
    const rand = makeSeededRand(DEFAULT_RNG_SEED);

    // Pull/Push overrides: if provided in opts, override the component-level
    // percentages for this simulation only. Otherwise fall back to the current
    // state values. Note: pushPct is currently not used in the internal
    // logic, but it is exposed here for future extension and automation.
    const localPullPct = opts.pullPct ?? pullPct;
    const localPushPct = opts.pushPct ?? pushPct;

    const U = unitValue;
    // Resolve stop and take profit amounts for this simulation. When running
    // automation scans the caller can supply stopPts/tpPts in opts to override
    // the component-level state. These values represent the PnL in dollars.
    const stopAmount = opts.stopPts !== undefined ? opts.stopPts : stopPts;
    const tpAmount = opts.tpPts !== undefined ? opts.tpPts : tpPts;
    // Cap the maximum allowed loss and profit per trade in USD. When the
    // configured amount is <= 0 the cap is effectively disabled (Infinity).
    const maxLossUsd = stopAmount > 0 ? stopAmount : Infinity;
    const maxWinUsd = tpAmount > 0 ? tpAmount : Infinity;
    // Convert the stop and take profit amounts into price deltas. This is
    // required for computing price levels where stops and targets will trigger.
    // If the amount is <= 0 the delta is zero which effectively disables the
    // corresponding exit condition.
    const stopDist = stopAmount > 0 ? stopAmount / U : 0;
    const tpDist = tpAmount > 0 ? tpAmount / U : 0;
    const t: Trade[] = [];

    const priors = normalizedPriors(bBull, bBear, bSide);
    const lambda = blendStrength(bBull, bBear, bSide);

    let pos: null | {
      side: "LONG" | "SHORT";
      i: number;
      p: number;
      targetLen: number;
      disagreeStreak: number;
      trailBase?: number;
    } = null;

    const predictWithMargins = (idx: number) => {
      const f = makeF(r, idx);
      const s = scoreHeadsFlexible(f, model!.heads);
      const p = softmax3(s);
      const pb = {
        BULL: (1 - lambda) * p.BULL + lambda * priors.BULL,
        BEAR: (1 - lambda) * p.BEAR + lambda * priors.BEAR,
        SIDE: (1 - lambda) * p.SIDE + lambda * priors.SIDE,
      };
      const arr = [pb.BULL, pb.BEAR, pb.SIDE].sort((a, b) => b - a);
      const margin = arr[0] - arr[1] || 0;
      return { label: argmax3p(pb), margin };
    };
    const sampleTargetLen = () =>
      Math.max(1, Math.floor(lenMin + rand() * Math.max(0, lenMax - lenMin)));
    const canEnter = (m: number) => m >= enterM;
    const canHold = (m: number) => m >= holdM;

    function capToGuaranteedStop(pnl: number, side: "LONG" | "SHORT") {
      // Only apply the guaranteed stop if a stop amount is configured
      if (stopAmount <= 0) return { pnl, pxOut: null as number | null };
      // If the PnL does not exceed the capped loss no adjustment is needed
      if (pnl >= -maxLossUsd) return { pnl, pxOut: null as number | null };
      // Otherwise compute the exit price at the stop distance from entry
      const pxOut = side === "LONG" ? pos!.p - stopDist : pos!.p + stopDist;
      return { pnl: -maxLossUsd, pxOut };
    }

    const N = r.length;

    for (let i = 1; i < N; i++) {
      const { label: c, margin } = predictWithMargins(i);
      const row = r[i];
      const px = row.close;

      if (pos) {
        // Trailing
        if (useTrailing) {
          if (pos.side === "LONG") {
            pos.trailBase =
              pos.trailBase == null ? px : Math.max(pos.trailBase, px);
            const trail = (pos.trailBase || px) - trailPts;
            if (row.open <= trail || (row.low <= trail && trail <= row.high)) {
              let outPrice = row.open <= trail ? row.open : trail;
              let pnl = (outPrice - pos.p) * +1 * U;
              // Apply upside cap if configured
              if (pnl > 0 && pnl > maxWinUsd) {
                pnl = maxWinUsd;
                outPrice = pos.p + maxWinUsd / U;
              }
              t.push({
                entryIdx: pos.i,
                exitIdx: i,
                side: pos.side,
                entryPrice: pos.p,
                exitPrice: outPrice,
                pnl,
                entryTs: r[pos.i].ts,
                exitTs: row.ts,
                exitReason: "TP",
              });
              pos = null;
              continue;
            }
          } else {
            pos.trailBase =
              pos.trailBase == null ? px : Math.min(pos.trailBase, px);
            const trail = (pos.trailBase || px) + trailPts;
            if (row.open >= trail || (row.low <= trail && trail <= row.high)) {
              let outPrice = row.open >= trail ? row.open : trail;
              let pnl = (outPrice - pos.p) * -1 * U;
              // Apply upside cap if configured
              if (pnl > 0 && pnl > maxWinUsd) {
                pnl = maxWinUsd;
                outPrice = pos.p - maxWinUsd / U;
              }
              t.push({
                entryIdx: pos.i,
                exitIdx: i,
                side: pos.side,
                entryPrice: pos.p,
                exitPrice: outPrice,
                pnl,
                entryTs: r[pos.i].ts,
                exitTs: row.ts,
                exitReason: "TP",
              });
              pos = null;
              continue;
            }
          }
        }

        // ====== SL/TP with guaranteed stop cap (always allowed) ======
        if (i > pos.i && (stopAmount || tpAmount)) {
          const sl = pos.side === "LONG" ? pos.p - stopDist : pos.p + stopDist;
          const tp = pos.side === "LONG" ? pos.p + tpDist : pos.p - tpDist;

          // 1) OPEN gap checks
          const slAtOpen =
            stopAmount > 0 &&
            ((pos.side === "LONG" && row.open <= sl) ||
              (pos.side === "SHORT" && row.open >= sl));
          const tpAtOpen =
            tpAmount > 0 &&
            ((pos.side === "LONG" && row.open >= tp) ||
              (pos.side === "SHORT" && row.open <= tp));

          if (slAtOpen || tpAtOpen) {
            let pxOut = row.open;
            let reason: ExitReason =
              slAtOpen && (!tpAtOpen || barOrder === "stop-first")
                ? "SL"
                : tpAtOpen
                ? "TP"
                : "SL";
            let pnl = (pxOut - pos.p) * (pos.side === "LONG" ? +1 : -1) * U;
            // Cap negative moves to the stop if exiting on SL
            if (reason === "SL") {
              const capped = capToGuaranteedStop(pnl, pos.side);
              pnl = capped.pnl;
              if (capped.pxOut !== null) pxOut = capped.pxOut;
            }
            // Apply upside cap for winning trades
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              pxOut = pos.p + (pos.side === "LONG" ? +1 : -1) * (maxWinUsd / U);
            }
            t.push({
              entryIdx: pos.i,
              exitIdx: i,
              side: pos.side,
              entryPrice: pos.p,
              exitPrice: pxOut,
              pnl,
              entryTs: r[pos.i].ts,
              exitTs: row.ts,
              exitReason: reason,
            });
            pos = null;
            continue;
          }

          // 2) INTRABAR checks
          const slHit = stopAmount > 0 && row.low <= sl && sl <= row.high;
          const tpHit = tpAmount > 0 && row.low <= tp && tp <= row.high;

          if (slHit || tpHit) {
            let pxOut =
              slHit && tpHit
                ? barOrder === "stop-first"
                  ? sl
                  : tp
                : slHit
                ? sl
                : tp;
            let reason: ExitReason =
              slHit && tpHit
                ? barOrder === "stop-first"
                  ? "SL"
                  : "TP"
                : slHit
                ? "SL"
                : "TP";
            let pnl = (pxOut - pos.p) * (pos.side === "LONG" ? +1 : -1) * U;
            // Cap negative moves if exiting on SL
            if (reason === "SL") {
              const capped = capToGuaranteedStop(pnl, pos.side);
              pnl = capped.pnl;
              if (capped.pxOut !== null) pxOut = capped.pxOut;
            }
            // Apply upside cap for winning trades
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              pxOut = pos.p + (pos.side === "LONG" ? +1 : -1) * (maxWinUsd / U);
            }
            t.push({
              entryIdx: pos.i,
              exitIdx: i,
              side: pos.side,
              entryPrice: pos.p,
              exitPrice: pxOut,
              pnl,
              entryTs: r[pos.i].ts,
              exitTs: row.ts,
              exitReason: reason,
            });
            pos = null;
            continue;
          }
        }

        // ===== Enforced Max Duration (auto close) =====
        const held = i - pos.i;
        if (held >= maxTradeBars) {
          const dir = pos.side === "LONG" ? +1 : -1;
          let exitPrice = r[i].close;
          let pnl = (r[i].close - pos.p) * dir * U;
          // Apply upside cap for positive PnL
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            exitPrice = pos.p + dir * (maxWinUsd / U);
          }
          t.push({
            entryIdx: pos.i,
            exitIdx: i,
            side: pos.side,
            entryPrice: pos.p,
            exitPrice,
            pnl,
            entryTs: r[pos.i].ts,
            exitTs: r[i].ts,
            exitReason: "MaxBars",
          });
          pos = null;
          continue;
        }

        // ===== Enforced Min Duration: prevent “soft exits” before minTradeBars =====
        const canSoftExit = held >= minTradeBars;

        // Exit on SIDE (only if soft exits allowed)
        if (canSoftExit && c === "SIDE") {
          const dir = pos.side === "LONG" ? +1 : -1;
          let exitPrice = px;
          let pnl = (px - pos.p) * dir * U;
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            exitPrice = pos.p + dir * (maxWinUsd / U);
          }
          t.push({
            entryIdx: pos.i,
            exitIdx: i,
            side: pos.side,
            entryPrice: pos.p,
            exitPrice,
            pnl,
            entryTs: r[pos.i].ts,
            exitTs: r[i].ts,
            exitReason: "TurnedSideways",
          });
          pos = null;
          continue;
        }

        // Hold margin / hysteresis (only if soft exits allowed)
        if (canSoftExit && !canHold(margin)) {
          pos.disagreeStreak += 1;
          if (pos.disagreeStreak >= hyst) {
            const dir = pos.side === "LONG" ? +1 : -1;
            let exitPrice = px;
            let pnl = (px - pos.p) * dir * U;
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              exitPrice = pos.p + dir * (maxWinUsd / U);
            }
            t.push({
              entryIdx: pos.i,
              exitIdx: i,
              side: pos.side,
              entryPrice: pos.p,
              exitPrice,
              pnl,
              entryTs: r[pos.i].ts,
              exitTs: r[i].ts,
              exitReason: "LostConfidence",
            });
            pos = null;
            continue;
          }
        } else if (canHold(margin)) {
          pos.disagreeStreak = 0;
        }

        // Exit at Target (pull behavior), only if soft exits allowed
        if (canSoftExit && held >= pos.targetLen) {
          if (
            localPullPct >= 100 ||
            (localPullPct > 0 && rand() < localPullPct / 100)
          ) {
            const dir = pos.side === "LONG" ? +1 : -1;
            let exitPrice = px;
            let pnl = (px - pos.p) * dir * U;
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              exitPrice = pos.p + dir * (maxWinUsd / U);
            }
            t.push({
              entryIdx: pos.i,
              exitIdx: i,
              side: pos.side,
              entryPrice: pos.p,
              exitPrice,
              pnl,
              entryTs: r[pos.i].ts,
              exitTs: r[i].ts,
              exitReason: "TargetLen",
            });
            pos = null;
            continue;
          }
        }
      } else {
        // Entry
        if (canEnter(margin)) {
          if (c === "BULL") {
            pos = {
              side: "LONG",
              i,
              p: px,
              targetLen: sampleTargetLen(),
              disagreeStreak: 0,
            };
            if (useTrailing) pos.trailBase = px;
          } else if (c === "BEAR") {
            pos = {
              side: "SHORT",
              i,
              p: px,
              targetLen: sampleTargetLen(),
              disagreeStreak: 0,
            };
            if (useTrailing) pos.trailBase = px;
          }
        }
      }

      if (onProg && i % 1500 === 0) onProg(i / (N - 1));
    }

    // Close leftover
    if (pos) {
      const i = r.length - 1;
      const px = r[i].close;
      const dir = pos.side === "LONG" ? +1 : -1;
      let exitPrice = px;
      let pnl = (px - pos.p) * dir * U;
      if (pnl > 0 && pnl > maxWinUsd) {
        pnl = maxWinUsd;
        exitPrice = pos.p + dir * (maxWinUsd / U);
      }
      t.push({
        entryIdx: pos.i,
        exitIdx: i,
        side: pos.side,
        entryPrice: pos.p,
        exitPrice,
        pnl,
        entryTs: r[pos.i].ts,
        exitTs: r[i].ts,
        exitReason: "End",
      });
    }

    const stats = computeStats(t, r, unitValue);
    return { trades: t, stats };
  }

  /* ---------- Stats helpers ---------- */
  function computeStats(tr: Trade[], data: Row[], U: number): Stats {
    const pnlArr = tr.map((x) => x.pnl);
    const tot = pnlArr.reduce((a, b) => a + b, 0);
    const wins = tr.filter((x) => x.pnl > 0);
    const loss = tr.filter((x) => x.pnl < 0);
    const pf =
      (wins.reduce((a, b) => a + b.pnl, 0) || 0) /
      Math.abs(loss.reduce((a, b) => a + b.pnl, 0) || 1);

    const lens = tr.map((x) => x.exitIdx - x.entryIdx);
    const winLens = wins.map((x) => x.exitIdx - x.entryIdx);
    const lossLens = loss.map((x) => x.exitIdx - x.entryIdx);

    let run = 0;
    const eq: number[] = [];
    for (const x of pnlArr) {
      run += x;
      eq.push(run);
    }
    const peakBal = Math.max(0, ...eq);
    const lowBal = Math.min(0, ...eq);
    const maxDD = calcMaxDrawdown(eq);

    const longTrades = tr.filter((x) => x.side === "LONG").length;
    const shortTrades = tr.filter((x) => x.side === "SHORT").length;

    // per-trade MFE/MAE
    const perMAE: number[] = [],
      perMFE: number[] = [];
    let biggestWin = 0,
      biggestLoss = 0;
    for (const t of tr) {
      biggestWin = Math.max(biggestWin, t.pnl);
      biggestLoss = Math.min(biggestLoss, t.pnl);
      let maxF = 0,
        maxA = 0;
      for (let k = t.entryIdx; k <= t.exitIdx; k++) {
        const hi = data[k].high,
          lo = data[k].low;
        if (t.side === "LONG") {
          maxF = Math.max(maxF, (hi - t.entryPrice) * U);
          maxA = Math.max(maxA, Math.max(0, (t.entryPrice - lo) * U));
        } else {
          maxF = Math.max(maxF, (t.entryPrice - lo) * U);
          maxA = Math.max(maxA, Math.max(0, (hi - t.entryPrice) * U));
        }
      }
      perMFE.push(maxF);
      perMAE.push(maxA);
    }
    const avgMAE = perMAE.length
      ? perMAE.reduce((a, b) => a + b, 0) / perMAE.length
      : 0;
    const maxMAE = perMAE.length ? Math.max(...perMAE) : 0;
    const avgMFE = perMFE.length
      ? perMFE.reduce((a, b) => a + b, 0) / perMFE.length
      : 0;
    const maxMFE = perMFE.length ? Math.max(...perMFE) : 0;

    const mean = pnlArr.length ? tot / pnlArr.length : 0;
    const sdev = stdev(pnlArr);
    const ddev = downsideStdev(pnlArr);

    const avgWinUsd = wins.length
      ? wins.reduce((a, b) => a + b.pnl, 0) / wins.length
      : 0;
    const avgLossUsd = loss.length
      ? loss.reduce((a, b) => a + b.pnl, 0) / loss.length
      : 0;

    const expectedValue =
      wins.length + loss.length > 0
        ? (wins.length / tr.length) * avgWinUsd +
          (loss.length / tr.length) * avgLossUsd
        : 0;

    // === Extended statistics ===
    // Typical win/loss streak lengths
    const winStreaks: number[] = [];
    const lossStreaks: number[] = [];
    let currentStreak = 0;
    let inWin: boolean | null = null;
    pnlArr.forEach((p) => {
      if (p > 0) {
        if (inWin === true) {
          currentStreak++;
        } else {
          if (inWin === false && currentStreak > 0)
            lossStreaks.push(currentStreak);
          currentStreak = 1;
          inWin = true;
        }
      } else if (p < 0) {
        if (inWin === false) {
          currentStreak++;
        } else {
          if (inWin === true && currentStreak > 0)
            winStreaks.push(currentStreak);
          currentStreak = 1;
          inWin = false;
        }
      } else {
        // zero pnl ends any streak
        if (inWin === true && currentStreak > 0) winStreaks.push(currentStreak);
        if (inWin === false && currentStreak > 0)
          lossStreaks.push(currentStreak);
        currentStreak = 0;
        inWin = null;
      }
    });
    // push last streak
    if (currentStreak > 0) {
      if (inWin === true) winStreaks.push(currentStreak);
      else if (inWin === false) lossStreaks.push(currentStreak);
    }
    const typicalWinStreak = winStreaks.length
      ? winStreaks.reduce((a, b) => a + b, 0) / winStreaks.length
      : 0;
    const typicalLossStreak = lossStreaks.length
      ? lossStreaks.reduce((a, b) => a + b, 0) / lossStreaks.length
      : 0;

    // Drawdown recovery times (bars and ms)
    const eqTimes: number[] = tr.map((t) => t.exitTs);
    let lastPeakVal = -Infinity;
    let lastPeakIdx = -1;
    let drawdown = false;
    const recBars: number[] = [];
    const recMs: number[] = [];
    for (let i = 0; i < eq.length; i++) {
      const v = eq[i];
      if (v > lastPeakVal + 1e-9) {
        if (lastPeakIdx >= 0 && drawdown) {
          recBars.push(i - lastPeakIdx);
          const ms = eqTimes[i] - eqTimes[lastPeakIdx];
          recMs.push(ms);
        }
        lastPeakVal = v;
        lastPeakIdx = i;
        drawdown = false;
      } else if (v < lastPeakVal - 1e-9) {
        drawdown = true;
      }
    }
    const meanRecoveryBars = recBars.length
      ? recBars.reduce((a, b) => a + b, 0) / recBars.length
      : 0;
    const meanRecoveryMs = recMs.length
      ? recMs.reduce((a, b) => a + b, 0) / recMs.length
      : 0;

    // Skewness and kurtosis of pnlArr
    let skewness = 0;
    let kurtosis = 0;
    if (pnlArr.length >= 2 && sdev > 0) {
      const n = pnlArr.length;
      let sum3 = 0;
      let sum4 = 0;
      for (const x of pnlArr) {
        const z = (x - mean) / (sdev || 1);
        sum3 += z * z * z;
        sum4 += z * z * z * z;
      }
      if (n > 2) {
        skewness = (n / ((n - 1) * (n - 2))) * sum3;
      }
      if (n > 3) {
        const g2 =
          (n * (n + 1) * sum4) / ((n - 1) * (n - 2) * (n - 3)) -
          (3 * (n - 1) * (n - 1)) / ((n - 2) * (n - 3));
        kurtosis = g2;
      }
    }

    // Market beta: relationship of trade PnL to underlying price movement
    let beta = 0;
    if (tr.length > 1) {
      const mReturns: number[] = [];
      for (const t of tr) {
        const m = data[t.exitIdx].close - data[t.entryIdx].close;
        mReturns.push(m);
      }
      const mAvg = mReturns.reduce((a, b) => a + b, 0) / mReturns.length;
      const pAvg = pnlArr.reduce((a, b) => a + b, 0) / pnlArr.length;
      let cov = 0;
      let varM = 0;
      for (let i = 0; i < pnlArr.length; i++) {
        cov += (pnlArr[i] - pAvg) * (mReturns[i] - mAvg);
        varM += (mReturns[i] - mAvg) * (mReturns[i] - mAvg);
      }
      cov /= pnlArr.length;
      varM /= pnlArr.length;
      if (varM > 1e-12) beta = cov / varM;
    }

    return {
      trades: tr.length,
      winRate: tr.length ? (wins.length / tr.length) * 100 : 0,
      avgTrade: tr.length ? tot / tr.length : 0,
      profitFactor: pf,
      totalPnL: tot,
      // Sharpe ratio: annualised based on 252 trading periods. We use mean and
      // standard deviation of per‑trade PnL to estimate risk‑adjusted return.  A
      // constant 252 is used in place of the total number of trades so that the
      // Sharpe remains on a comparable scale; multiplying by sqrt(n) can yield
      // unrealistic ratios when trade PnL variance is extremely small.  If the
      // standard deviation is zero, the Sharpe is 0.
      sharpe: sdev > 0 ? (mean / sdev) * Math.sqrt(252) : 0,
      // Sortino ratio: same approach as Sharpe but using downside deviation and
      // annualising over 252 periods. If the downside deviation is zero the
      // Sortino is 0.
      sortino: ddev > 0 ? (mean / ddev) * Math.sqrt(252) : 0,
      maxDD,
      peakBal,
      lowBal,
      avgLen: lens.length ? lens.reduce((a, b) => a + b, 0) / lens.length : 0,
      avgWinLen: winLens.length
        ? winLens.reduce((a, b) => a + b, 0) / winLens.length
        : 0,
      avgLossLen: lossLens.length
        ? lossLens.reduce((a, b) => a + b, 0) / lossLens.length
        : 0,
      medianLen: median(lens),
      p90Len: quantile(lens, 0.9),
      avgWinUsd,
      avgLossUsd,
      maxWinUsd: biggestWin,
      maxLossUsd: biggestLoss,
      longTrades,
      shortTrades,
      avgMAE,
      maxMAE,
      avgMFE,
      maxMFE,
      expectedValue,
      // extended fields
      typicalWinStreak,
      typicalLossStreak,
      meanRecoveryBars,
      meanRecoveryMs,
      skewness,
      kurtosis,
      beta,
    };
  }

  /* ----------------- RUN flow ----------------- */
  /**
   * Execute a backtest run.  The backtest proceeds in two phases:
   *  1. Load or refresh bar data (if necessary).
   *  2. Simulate trades using the currently loaded model.
   *
   * When the Bars chip in the UI is green (rows.length >= TARGET_BARS),
   * fetching is completely disabled and the existing bar data is reused.
   * This ensures there is no network activity when there are already
   * sufficient cached bars.  Only when forceBarsRefresh is true or when
   * there are insufficient bars will ensureBars be invoked.
   */
  const onRun = async () => {
    // Begin loading state and clear previous results
    setIsLoading(true);
    setTrades([]);
    setOverallStats(null);
    setSelectedDay(null);
    setProgress(0);

    // Reload the model if a specific model key is selected.  Falling
    // back to the most recently saved model ensures the simulator
    // always uses a valid IntuitionModel.
    let fresh: IntuitionModel | null = null;
    if (modelName) {
      try {
        const raw = localStorage.getItem(modelName);
        if (raw) {
          const j = JSON.parse(raw);
          const mm = coerceToIntuitionModel(j);
          if (mm) fresh = mm;
        }
      } catch {}
    }
    if (!fresh) {
      fresh = tryLoadModelFromStorage();
    }
    if (fresh && !validateModel(fresh)) setModel(fresh);
    const err = validateModel(fresh ?? model);
    if (err) {
      setIsLoading(false);
      setProgress(0);
      return;
    }

    try {
      // Always run the backtest on whatever bar data is currently loaded.
      // We never call ensureBars here so that no network fetching occurs.
      setLoadingMsg("Running backtest…");
      const data = rows.slice();
      const sim = await simulateBacktestProgressive(data, {}, (p01) =>
        setProgress(Math.round(p01 * 100))
      );
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      // Record which model generated these stats.  Use the explicit
      // modelName if one is selected, otherwise fall back to the default
      // key.  This allows the UI to display the model alongside the
      // backtest title so users know which model the results correspond to.
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setIsLoading(false);
      setProgress(100);
      setLoadingMsg("Done");
    } catch {
      setIsLoading(false);
      setProgress(0);
      setLoadingMsg("Error");
    }
  };
  /* ---------- Automation: priority-weighted multi-objective ---------- */
  async function yieldOften(
    step: number,
    i: number,
    total: number,
    label: string
  ) {
    if (i % step === 0) {
      setAutoProgress(Math.floor((i / total) * 100));
      setAutoMsg(`${label}… ${i}/${total} combos`);
      await Promise.resolve();
      await new Promise((r) => setTimeout(r, 0));
    }
  }

  function getMetricValue(
    key: ObjKey,
    s: Stats,
    longs: number,
    shorts: number
  ): number {
    switch (key) {
      case "winrate":
        return s.winRate;
      case "pf":
        return s.profitFactor;
      case "netpnl":
        return s.totalPnL;
      case "avgwin":
        return s.avgWinUsd;
      case "avgloss":
        return s.avgLossUsd; // minimize (handled in norm)
      case "sharpe":
        return s.sharpe;
      case "sortino":
        return s.sortino;
      case "peak_per_trade":
        return s.avgMFE;
      case "min_avg_dd":
        return s.avgMAE; // minimize (handled in norm)
      case "ls_balance": {
        const tot = longs + shorts;
        if (!tot) return 0;
        const share = longs / tot; // 0..1
        return 1 - Math.min(1, Math.abs(share - 0.5) * 2); // 1 when perfectly 50/50
      }
      case "max_rr": {
        // Risk to reward ratio (absolute). If no losses then return Infinity.
        return s.avgLossUsd !== 0
          ? Math.abs(s.avgWinUsd / Math.abs(s.avgLossUsd))
          : Infinity;
      }
      case "max_win_streak":
        return s.typicalWinStreak;
      case "min_loss_streak":
        return s.typicalLossStreak;
      case "min_recovery_time":
        // Use mean recovery time in bars as primary measure
        return s.meanRecoveryBars;
      case "min_beta":
        // minimize absolute market beta
        return Math.abs(s.beta);
      default:
        return 0;
    }
  }

  const priorityWeights = (n: number) =>
    Array.from({ length: n }, (_, i) => Math.pow(0.6, i));

  async function runCompositeObjective() {
    if (!rows.length || !readyModel || selectedObjectives.length === 0) return;

    setAutoRunning(true);
    setAutoMsg(
      `Searching ${autoSpace} with ${selectedObjectives.length} target(s)…`
    );
    setAutoProgress(0);

    const guard = Math.max(0, Math.floor(minTradesGuard));
    // Determine objective weights based on the selected multi‑method.  When
    // using the "Even" method all objectives share equal weight (1/n).  When
    // "Ranked" is selected the priorityWeights function (0.6^i) is used.
    const weights = (() => {
      const n = selectedObjectives.length;
      if (n === 0) return [];
      // Even weighting: each objective gets equal weight 1/n
      if (autoMultiMethod === "Even") {
        return Array.from({ length: n }, () => 1 / n);
      }
      // Ranked linear: weights decrease linearly from n to 1, normalised to sum to 1
      if (autoMultiMethod === "RankedLin") {
        const total = (n * (n + 1)) / 2;
        return Array.from({ length: n }, (_, i) => (n - i) / total);
      }
      // Ranked exponential (default): 0.6^i
      return priorityWeights(n);
    })();
    const defsMap = Object.fromEntries(objectiveDefs.map((d) => [d.key, d]));
    const combos: Array<{
      bull?: number;
      bear?: number;
      side?: number;
      hyst?: number;
      enterM?: number;
      holdM?: number;
      // New search parameters for pull/push space
      pull?: number;
      push?: number;
      // Additional parameters for TP/SL search space
      stop?: number;
      tp?: number;
      metrics: Record<ObjKey, number>;
      count: number;
      s: Stats;
    }> = [];

    // Count total combos
    let total = 0;
    if (autoSpace === "BB") total = 101 * 101;
    else if (autoSpace === "SH") {
      // Sideways/Hysteresis search space now explores 101×101 combinations
      // instead of 101×51 (~5k) to achieve roughly 10 000 combos.  This
      // increases the resolution of the hysteresis parameter for better
      // automation fidelity.
      total = 101 * 101;
    } else if (autoSpace === "HOLD") {
      // Compute a dynamic grid size for the HOLD automation search.  We
      // approximate the total combinations to around 10 000 by taking the
      // integer square root of that target and using it as the number of
      // steps for both dimensions.  This calculation is mirrored in the
      // simulation loop below.
      const targetCombos = 10000;
      const steps = Math.max(2, Math.floor(Math.sqrt(targetCombos)));
      total = steps * steps;
    } else if (autoSpace === "BS" || autoSpace === "BR" || autoSpace === "PP") {
      // Bull/Sideways, Bear/Sideways and Pull/Push each explore 101×101 combinations
      total = 101 * 101;
    } else if (autoSpace === "TPSL") {
      // Take Profit / Stop Loss space uses a dynamic grid targeting ~10k combos
      const targetCombos = 10000;
      const steps = Math.max(2, Math.floor(Math.sqrt(targetCombos)));
      total = steps * steps;
    }

    let checked = 0;

    if (autoSpace === "BB") {
      for (let bBull = 0; bBull <= 100; bBull++) {
        for (let bBear = 0; bBear <= 100; bBear++) {
          const sim = simulateBacktest(rows, {
            bull: bBull,
            bear: bBear,
            side: biasSide,
          });
          if (sim.trades.length >= guard) {
            const s = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, s, longs, shorts))
            );
            combos.push({
              bull: bBull,
              bear: bBear,
              metrics,
              count: sim.trades.length,
              s,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "SH") {
      for (let sPct = 0; sPct <= 100; sPct++) {
        // Hysteresis now iterates from 0–100 (inclusive) to increase the
        // combination count to ~10k when paired with 101 side percentage
        // values.  Previously this loop used 0–50 (51 values).
        for (let h = 0; h <= 100; h++) {
          const sim = simulateBacktest(rows, { side: sPct, hyst: h });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              side: sPct,
              hyst: h,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "HOLD") {
      // Dynamically derive step sizes for the HOLD search space.  We reuse the
      // same "steps" value calculated when determining the total combinations
      // above.  The step sizes divide the defined ranges evenly so that the
      // nested loops iterate approximately 10 000 combinations in total.  We
      // fix the precision to four decimal places to avoid floating‑point
      // accumulation errors when converting to strings.
      const targetCombos = 10000;
      const steps = Math.max(2, Math.floor(Math.sqrt(targetCombos)));
      const holdEnterRange = HOLD_ENTER_MAX - HOLD_ENTER_MIN;
      const holdHoldRange = HOLD_HOLD_MAX - HOLD_HOLD_MIN;
      const holdEnterStep = holdEnterRange / (steps - 1);
      const holdHoldStep = holdHoldRange / (steps - 1);
      for (let ei = 0; ei < steps; ei++) {
        const em = +(HOLD_ENTER_MIN + holdEnterStep * ei).toFixed(4);
        for (let hi = 0; hi < steps; hi++) {
          const hm = +(HOLD_HOLD_MIN + holdHoldStep * hi).toFixed(4);
          const sim = simulateBacktest(rows, { enterM: em, holdM: hm });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              enterM: em,
              holdM: hm,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "BS") {
      // Explore Bull vs Sideways bias combinations
      for (let bBull = 0; bBull <= 100; bBull++) {
        for (let bSide = 0; bSide <= 100; bSide++) {
          const sim = simulateBacktest(rows, { bull: bBull, side: bSide });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              bull: bBull,
              side: bSide,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "BR") {
      // Explore Bear vs Sideways bias combinations
      for (let bBear = 0; bBear <= 100; bBear++) {
        for (let bSide = 0; bSide <= 100; bSide++) {
          const sim = simulateBacktest(rows, { bear: bBear, side: bSide });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              bear: bBear,
              side: bSide,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "PP") {
      // Explore Pull vs Push percentages. These override global pull/push settings.
      for (let pull = 0; pull <= 100; pull++) {
        for (let push = 0; push <= 100; push++) {
          const sim = simulateBacktest(rows, { pullPct: pull, pushPct: push });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              pull: pull,
              push: push,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    } else if (autoSpace === "TPSL") {
      // Explore combinations of Stop Loss and Take Profit amounts. The search
      // range spans from the current Stop Loss (min) up to the current Take
      // Profit (max). A square grid of ~10,000 total combinations is used.
      const targetCombos = 10000;
      const steps = Math.max(2, Math.floor(Math.sqrt(targetCombos)));
      // Determine the range boundaries in USD. We ensure the min is less than
      // or equal to the max even if the user inverted the values.
      const minVal = Math.min(stopPts, tpPts);
      const maxVal = Math.max(stopPts, tpPts);
      const range = maxVal - minVal;
      for (let si = 0; si < steps; si++) {
        // Interpolate Stop Loss value across [minVal, maxVal]
        const sl = range === 0 ? minVal : minVal + (range * si) / (steps - 1);
        for (let ti = 0; ti < steps; ti++) {
          // Interpolate Take Profit value across [minVal, maxVal]
          const tp = range === 0 ? minVal : minVal + (range * ti) / (steps - 1);
          const sim = simulateBacktest(rows, { stopPts: sl, tpPts: tp });
          if (sim.trades.length >= guard) {
            const st = sim.stats;
            const longs = sim.trades.filter((x) => x.side === "LONG").length;
            const shorts = sim.trades.filter((x) => x.side === "SHORT").length;
            const metrics: any = {};
            selectedObjectives.forEach(
              (k) => (metrics[k] = getMetricValue(k, st, longs, shorts))
            );
            combos.push({
              stop: sl,
              tp: tp,
              metrics,
              count: sim.trades.length,
              s: st,
            });
          }
          checked++;
          await yieldOften(50, checked, total, "Scanning");
        }
      }
    }

    if (!combos.length) {
      setLastAutoMsg("Finished: No combos passed the guard filters.");
      setAutoRunning(false);
      setAutoMsg("");
      setAutoProgress(100);
      return;
    }

    // Normalize metrics to 0..1 respecting preferHigher
    const mins: Record<ObjKey, number> = {} as any;
    const maxs: Record<ObjKey, number> = {} as any;
    for (const k of selectedObjectives) {
      mins[k] = Infinity;
      maxs[k] = -Infinity;
    }
    for (const c of combos) {
      for (const k of selectedObjectives) {
        const v = c.metrics[k];
        if (v < mins[k]) mins[k] = v;
        if (v > maxs[k]) maxs[k] = v;
      }
    }
    const norm = (k: ObjKey, v: number, preferHigher: boolean) => {
      let lo = mins[k],
        hi = maxs[k];
      if (!isFinite(lo) || !isFinite(hi) || hi - lo < 1e-9) return 0.5;
      const x = (v - lo) / (hi - lo);
      return preferHigher ? x : 1 - x;
    };

    let best = combos[0],
      bestScore = -Infinity;
    for (const c of combos) {
      let score = 0;
      selectedObjectives.forEach((k, idx) => {
        const def = defsMap[k];
        const w = weights[idx];
        score += w * norm(k, c.metrics[k], def.preferHigher);
      });
      if (
        score > bestScore ||
        (score === bestScore && c.s.totalPnL > best.s.totalPnL)
      ) {
        bestScore = score;
        best = c;
      }
    }

    // Apply the chosen params and show the enforced-duration sim results
    if (autoSpace === "BB" && best.bull != null && best.bear != null) {
      setBiasBull(best.bull!);
      setBiasBear(best.bear!);
      const sim = simulateBacktest(rows, {
        bull: best.bull!,
        bear: best.bear!,
        side: biasSide,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      // Mark which model produced these auto‑run stats
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Bull ${best.bull}, Bear ${best.bear} (trades=${best.count})`
      );
    } else if (autoSpace === "SH" && best.side != null && best.hyst != null) {
      setBiasSide(best.side!);
      setHysteresis(best.hyst!);
      const sim = simulateBacktest(rows, {
        side: best.side!,
        hyst: best.hyst!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Side ${best.side}, Hyst ${best.hyst} (trades=${best.count})`
      );
    } else if (
      autoSpace === "HOLD" &&
      best.enterM != null &&
      best.holdM != null
    ) {
      setEnterMargin(best.enterM!);
      setHoldMargin(best.holdM!);
      const sim = simulateBacktest(rows, {
        enterM: best.enterM!,
        holdM: best.holdM!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Min Entry ${best.enterM!.toFixed(
          2
        )}, Min Hold ${best.holdM!.toFixed(2)} (trades=${best.count})`
      );
    } else if (autoSpace === "BS" && best.bull != null && best.side != null) {
      // Apply Bull/Sideways biases
      setBiasBull(best.bull!);
      setBiasSide(best.side!);
      const sim = simulateBacktest(rows, {
        bull: best.bull!,
        side: best.side!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Bull ${best.bull}, Side ${best.side} (trades=${best.count})`
      );
    } else if (autoSpace === "BR" && best.bear != null && best.side != null) {
      // Apply Bear/Sideways biases
      setBiasBear(best.bear!);
      setBiasSide(best.side!);
      const sim = simulateBacktest(rows, {
        bear: best.bear!,
        side: best.side!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Bear ${best.bear}, Side ${best.side} (trades=${best.count})`
      );
    } else if (autoSpace === "PP" && best.pull != null && best.push != null) {
      // Apply Pull/Push percentages
      setPullPct(best.pull!);
      setPushPct(best.push!);
      const sim = simulateBacktest(rows, {
        pullPct: best.pull!,
        pushPct: best.push!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Pull ${best.pull}, Push ${best.push} (trades=${best.count})`
      );
    } else if (autoSpace === "TPSL" && best.stop != null && best.tp != null) {
      // Apply the best Stop Loss and Take Profit amounts (USD). These override
      // the component-level stopPts and tpPts settings. After updating the
      // state variables we run a fresh simulation with the chosen parameters.
      setStopPts(best.stop!);
      setTpPts(best.tp!);
      const sim = simulateBacktest(rows, {
        stopPts: best.stop!,
        tpPts: best.tp!,
      });
      setTrades(sim.trades);
      setOverallStats(sim.stats);
      setStatsModelName(modelName || FALLBACK_MODEL_KEY);
      setLastAutoMsg(
        `Finished: Composite → Stop ${best.stop!.toFixed(
          2
        )}, TP ${best.tp!.toFixed(2)} (trades=${best.count})`
      );
    }

    setAutoRunning(false);
    setAutoMsg("");
    setAutoProgress(100);
  }

  /* ---------- UI ---------- */
  return (
    <>
      <GlobalDark />
      <div className="wrap">
        <div
          className="row"
          style={{ justifyContent: "space-between", marginBottom: 10 }}
        >
          <h1 className="title">
            ML Model Backtest
            {overallStats && statsModelName ? ` – ${statsModelName}` : ""}
          </h1>
          <div className="row" style={{ gap: 8, position: "relative" }}>
            <span
              className={`chip ${readyModel ? "ok" : "miss"}`}
              onClick={handleModelChipClick}
              style={{ cursor: "pointer" }}
            >
              Model: {readyModel ? modelName || "OK" : "Missing"}
            </span>
            {/* Dropdown listing available models when the model chip is clicked */}
            {modelDropdownOpen && (
              <div
                style={{
                  position: "absolute",
                  top: "100%",
                  right: 0,
                  marginTop: 4,
                  background: "#0f172a",
                  border: "1px solid #334155",
                  borderRadius: 4,
                  minWidth: "180px",
                  zIndex: 20,
                  maxHeight: "220px",
                  overflowY: "auto",
                  boxShadow: "0 4px 8px rgba(0,0,0,0.4)",
                }}
              >
                {availableModels.map((m) => (
                  <div
                    key={m.key}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      padding: "6px 12px",
                      whiteSpace: "nowrap",
                      cursor: "pointer",
                      color: "#f1f5f9",
                    }}
                    className="dropdown-item"
                  >
                    <span
                      onClick={() => selectModelKey(m.key)}
                      style={{ flexGrow: 1 }}
                    >
                      {m.key}
                    </span>
                    <span
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteModelKey(m.key);
                      }}
                      style={{
                        marginLeft: 8,
                        color: "#ef4444",
                        cursor: "pointer",
                        fontWeight: 700,
                      }}
                      title="Delete model"
                    >
                      ×
                    </span>
                  </div>
                ))}
                {/* If no models are found, show a placeholder */}
                {availableModels.length === 0 && (
                  <div style={{ padding: "6px 12px", color: "#94a3b8" }}>
                    No models found
                  </div>
                )}
                {/* Upload model action within dropdown */}
                <div
                  onClick={() => {
                    if (uploadRef.current) uploadRef.current.click();
                  }}
                  style={{
                    padding: "6px 12px",
                    cursor: "pointer",
                    borderTop: "1px solid #334155",
                    color: "#93c5fd",
                  }}
                >
                  Upload Model...
                </div>
              </div>
            )}
            <span
              className={`chip ${readyBars ? "ok" : "miss"}`}
              onClick={handleBarsChipClick}
              style={{ cursor: "pointer" }}
            >
              Bars: {readyBars ? rows.length.toLocaleString() : "0"}
            </span>
            {/* Hidden input remains for uploading models; triggered from dropdown */}
            <input
              type="file"
              accept=".json,application/json"
              ref={uploadRef}
              onChange={handleModelUpload}
              style={{ display: "none" }}
            />
          </div>
        </div>
        {/* Run row */}
        <div className="card">
          <div
            className="row"
            style={{ alignItems: "stretch", gap: 12, width: "100%" }}
          >
            <button
              className="btn btn-primary btn-rect"
              onClick={onRun}
              disabled={isLoading || autoRunning}
              style={{ width: 260 }}
            >
              Run Backtest
            </button>

            <div style={{ width: 320 }}>
              <div className="label">
                Instrument{" "}
                <span
                  className="tt"
                  data-tip="Symbol or pair, e.g., XAU/USD, EUR/USD, AAPL"
                >
                  ?
                </span>
              </div>
              <input
                className="input"
                placeholder="e.g., XAU/USD or AAPL"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value.trim())}
              />
            </div>
            <div style={{ width: 220 }}>
              <div className="label">
                Timeframe{" "}
                <span
                  className="tt"
                  data-tip="Resolution for bars to fetch/backtest"
                >
                  ?
                </span>
              </div>
              <select
                className="select"
                value={interval}
                onChange={(e) => setIntervalStr(e.target.value)}
              >
                <option value="1min">1 minute</option>
                <option value="5min">5 minutes</option>
                <option value="15min">15 minutes</option>
                <option value="30min">30 minutes</option>
                <option value="1h">1 hour</option>
                <option value="4h">4 hours</option>
                <option value="1day">1 day</option>
              </select>
            </div>
          </div>

          <div style={{ marginTop: 12 }}>
            <div className="progress-shell progress-shell-lg">
              <div className="progress-bar" style={{ width: `${progress}%` }} />
            </div>
            <div className="tiny" style={{ marginTop: 6 }}>
              {loadingMsg}
            </div>
          </div>
        </div>
        {/* Basic parameters */}
        <div className="card">
          <div
            className="grid"
            style={{ gridTemplateColumns: "repeat(4,1fr)" }}
          >
            <div>
              <div className="label">
                Dollar per Point{" "}
                <span
                  className="tt"
                  data-tip="PnL = (Exit − Entry) × this value"
                >
                  ?
                </span>
              </div>
              <input
                className="input"
                type="number"
                value={unitValue}
                onChange={(e) => setUnitValue(+e.target.value || 0)}
              />
            </div>
            <div>
              <div className="label">
                Stop Loss ($){" "}
                <span
                  className="tt"
                  data-tip="Guaranteed: loss capped at the Stop amount (USD) even on gaps"
                >
                  ?
                </span>
              </div>
              <input
                className="input"
                type="number"
                value={stopPts}
                onChange={(e) => setStopPts(+e.target.value || 0)}
              />
            </div>
            <div>
              <div className="label">
                Take Profit ($){" "}
                <span
                  className="tt"
                  data-tip="Bar that touches or gaps beyond this amount (USD) exits the trade"
                >
                  ?
                </span>
              </div>
              <input
                className="input"
                type="number"
                value={tpPts}
                onChange={(e) => setTpPts(+e.target.value || 0)}
              />
            </div>
            <div>
              <div className="label">
                Both Hit in One Bar{" "}
                <span
                  className="tt"
                  data-tip="If SL & TP hit same bar, which wins?"
                >
                  ?
                </span>
              </div>
              <select
                className="select"
                value={barOrder}
                onChange={(e) => setBarOrder(e.target.value as any)}
              >
                <option value="stop-first">Stop First</option>
                <option value="tp-first">Take Profit First</option>
              </select>
            </div>
          </div>
        </div>
        {/* Advanced Options */}
        <div className="card">
          <div className="adv-head" onClick={() => setAdvOpen((v) => !v)}>
            <div style={{ fontWeight: 800 }}>Advanced Options</div>
            <div className="muted">{advOpen ? "Hide ▲" : "Show ▼"}</div>
          </div>

          {advOpen && (
            <>
              {/* ENTRY */}
              <div className="section-title">Entry</div>
              <div
                className="adv-grid"
                style={{ gridTemplateColumns: "repeat(3,1fr)" }}
              >
                <div>
                  <div className="label">
                    Minimum Entry Margin{" "}
                    <span
                      className="tt"
                      data-tip="Higher margin → fewer but stronger entries"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    step="0.01"
                    value={enterMargin}
                    onChange={(e) => setEnterMargin(+e.target.value || 0)}
                  />
                </div>
                <div>
                  <div className="label">
                    Minimum Hold Margin{" "}
                    <span
                      className="tt"
                      data-tip="Below this, bars count toward flipping"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    step="0.01"
                    value={holdMargin}
                    onChange={(e) => setHoldMargin(+e.target.value || 0)}
                  />
                </div>
                <div>
                  <div className="label">
                    Hysteresis (bars){" "}
                    <span
                      className="tt"
                      data-tip="Disagreeing bars required before flip"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={1}
                    value={hysteresis}
                    onChange={(e) =>
                      setHysteresis(Math.max(1, +e.target.value || 1))
                    }
                  />
                </div>
              </div>

              {/* EXIT */}
              <div className="section-title" style={{ marginTop: 12 }}>
                Exit
              </div>
              <div
                className="adv-grid"
                style={{ gridTemplateColumns: "repeat(3,1fr)" }}
              >
                <div>
                  <div className="label">
                    Target Range (bars){" "}
                    <span
                      className="tt"
                      data-tip="Random hold length sampled from this range"
                    >
                      ?
                    </span>
                  </div>
                  <DualRange
                    min={1}
                    max={300}
                    lo={lenMin}
                    hi={lenMax}
                    onChange={(lo, hi) => {
                      setLenMin(lo);
                      setLenMax(hi);
                    }}
                  />
                </div>
                <div>
                  <div className="label">
                    Pull to Target (%){" "}
                    <span
                      className="tt"
                      data-tip="0% ignore, 100% exit right at target"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={0}
                    max={100}
                    value={pullPct}
                    onChange={(e) =>
                      setPullPct(
                        Math.max(0, Math.min(100, +e.target.value || 0))
                      )
                    }
                  />
                </div>
                <div>
                  <div className="label">
                    Push to Target (%){" "}
                    <span
                      className="tt"
                      data-tip="0% normal; 100% don't exit early on SIDE before min target (SL/TP still apply)"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={0}
                    max={100}
                    value={pushPct}
                    onChange={(e) =>
                      setPushPct(
                        Math.max(0, Math.min(100, +e.target.value || 0))
                      )
                    }
                  />
                </div>
              </div>

              {/* NEW: Enforced Duration */}
              <div className="section-title" style={{ marginTop: 12 }}>
                Enforced Trade Duration
              </div>
              <div
                className="adv-grid"
                style={{ gridTemplateColumns: "repeat(3,1fr)" }}
              >
                <div>
                  <div className="label">
                    Min Trade Length (bars){" "}
                    <span
                      className="tt"
                      data-tip="Trades cannot end before this, unless SL/TP"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={1}
                    value={minTradeBars}
                    onChange={(e) =>
                      setMinTradeBars(Math.max(1, +e.target.value || 1))
                    }
                  />
                </div>
                <div>
                  <div className="label">
                    Max Trade Length (bars){" "}
                    <span
                      className="tt"
                      data-tip="Auto-close when this many bars are held"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={1}
                    value={maxTradeBars}
                    onChange={(e) =>
                      setMaxTradeBars(Math.max(1, +e.target.value || 1))
                    }
                  />
                </div>
                <div />
              </div>

              {/* TRAILING */}
              <div className="section-title" style={{ marginTop: 12 }}>
                Trailing
              </div>
              <div
                className="adv-grid"
                style={{ gridTemplateColumns: "repeat(3,1fr)" }}
              >
                <div>
                  <div className="label">
                    Trailing Stop{" "}
                    <span className="tt" data-tip="Simple trailing stop toggle">
                      ?
                    </span>
                  </div>
                  <select
                    className="select"
                    value={useTrailing ? "on" : "off"}
                    onChange={(e) => setUseTrailing(e.target.value === "on")}
                  >
                    <option value="off">Off</option>
                    <option value="on">On</option>
                  </select>
                </div>
                <div>
                  <div className="label">
                    Trail Distance (pts){" "}
                    <span className="tt" data-tip="Smaller = tighter trailing">
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    value={trailPts}
                    onChange={(e) => setTrailPts(+e.target.value || 0)}
                    disabled={!useTrailing}
                  />
                </div>
                <div />
              </div>

              {/* BIAS */}
              <div className="section-title" style={{ marginTop: 12 }}>
                Class Frequency Bias
              </div>
              <div
                className="adv-grid"
                style={{ gridTemplateColumns: "repeat(3,1fr)" }}
              >
                <div>
                  <div className="label">
                    Bull Bias (%){" "}
                    <span className="tt" data-tip="Tug predictions toward Bull">
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={0}
                    max={100}
                    value={biasBull}
                    onChange={(e) =>
                      setBiasBull(
                        Math.max(0, Math.min(100, +e.target.value || 0))
                      )
                    }
                  />
                </div>
                <div>
                  <div className="label">
                    Bear Bias (%){" "}
                    <span className="tt" data-tip="Tug predictions toward Bear">
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={0}
                    max={100}
                    value={biasBear}
                    onChange={(e) =>
                      setBiasBear(
                        Math.max(0, Math.min(100, +e.target.value || 0))
                      )
                    }
                  />
                </div>
                <div>
                  <div className="label">
                    Sideways Bias (%){" "}
                    <span
                      className="tt"
                      data-tip="Tug predictions toward Sideways"
                    >
                      ?
                    </span>
                  </div>
                  <input
                    className="input"
                    type="number"
                    min={0}
                    max={100}
                    value={biasSide}
                    onChange={(e) =>
                      setBiasSide(
                        Math.max(0, Math.min(100, +e.target.value || 0))
                      )
                    }
                  />
                </div>
              </div>
            </>
          )}
        </div>
        {/* Automation Options (Min/Max Trade Duration removed here) */}
        <div className="card" style={{ marginBottom: 18 }}>
          <div className="auto-head" onClick={() => setAutoOpen((v) => !v)}>
            <div style={{ fontWeight: 800 }}>Automation Options</div>
            <div className="muted">{autoOpen ? "Hide ▲" : "Show ▼"}</div>
          </div>

          {autoOpen && (
            <>
              <div className="row auto-top">
                <div className="label">
                  Min Trades{" "}
                  <span
                    className="tt"
                    data-tip="Combos must produce at least this many trades"
                  >
                    ?
                  </span>
                </div>
                <input
                  className="input-compact"
                  type="number"
                  min={0}
                  value={minTradesGuard}
                  onChange={(e) =>
                    setMinTradesGuard(Math.max(0, +e.target.value || 0))
                  }
                />

                <div className="label" style={{ marginLeft: 6 }}>
                  Search Space
                </div>
                <div className="select-wrap">
                  <select
                    className="select-themed"
                    value={autoSpace}
                    onChange={(e) => setAutoSpace(e.target.value as AutoSpace)}
                  >
                    <option value="BB">Bull / Bear</option>
                    <option value="SH">Sideways / Hysteresis</option>
                    <option value="HOLD">Hold (Entry/Hold Margins)</option>
                    <option value="BS">Bull / Sideways</option>
                    <option value="BR">Bear / Sideways</option>
                    <option value="PP">Pull / Push</option>
                    <option value="TPSL">TP / SL</option>
                  </select>
                  <div className="select-caret">▼</div>
                </div>

                {/* Multi‑Method selector: choose between Ranked (priority weights) and Even weighting */}
                <div className="label" style={{ marginLeft: 6 }}>
                  Multi‑Method
                </div>
                <div className="select-wrap">
                  <select
                    className="select-themed"
                    value={autoMultiMethod}
                    onChange={(e) =>
                      setAutoMultiMethod(e.target.value as MultiMethod)
                    }
                  >
                    <option value="RankedExp">Ranked (Exponential)</option>
                    <option value="RankedLin">Ranked (Linear)</option>
                    <option value="Even">Even</option>
                  </select>
                  <div className="select-caret">▼</div>
                </div>
              </div>

              <div
                style={{
                  marginTop: 18,
                  marginBottom: 6,
                  fontWeight: 800,
                  fontSize: 13,
                }}
              >
                Automation Type
              </div>

              <div className="auto-grid" style={{ marginTop: 12 }}>
                {objectiveDefs.map((def) => {
                  const idx = selectedObjectives.indexOf(def.key);
                  const selected = idx >= 0;
                  return (
                    <button
                      key={def.key}
                      className={`btn btn-rect-sm ${
                        selected ? "selected" : ""
                      }`}
                      disabled={!readyBars || !readyModel || autoRunning}
                      onClick={() => {
                        setSelectedObjectives((prev) =>
                          prev.includes(def.key)
                            ? prev.filter((k) => k !== def.key)
                            : [...prev, def.key]
                        );
                      }}
                    >
                      {def.label}
                      {selected && (
                        <span className="badge-priority">{idx + 1}</span>
                      )}
                    </button>
                  );
                })}
              </div>

              <div
                className="row"
                style={{ marginTop: 12, justifyContent: "center" }}
              >
                <button
                  className="btn btn-primary btn-rect"
                  style={{ width: 320 }}
                  onClick={runCompositeObjective}
                  disabled={
                    !readyBars ||
                    !readyModel ||
                    autoRunning ||
                    selectedObjectives.length === 0
                  }
                >
                  Run Selected Objectives
                </button>
              </div>

              <div style={{ marginTop: 12 }}>
                <div className="progress-shell progress-shell-xl">
                  <div
                    className="progress-bar"
                    style={{ width: `${autoProgress}%` }}
                  />
                </div>
                <div className="tiny" style={{ marginTop: 6 }}>
                  {autoRunning
                    ? autoMsg
                    : lastAutoMsg
                    ? `Last finished: ${lastAutoMsg}`
                    : "Select one or more targets above, then click Run."}
                </div>
              </div>
            </>
          )}
        </div>

        {/* KPIs */}
        {overallStats && (
          <>
            <div className="kpis">
              <div className="kpi span4">
                <div className="lab">Total Net PnL</div>
                <div
                  className="val"
                  style={{
                    fontSize: 22,
                    color: overallStats.totalPnL >= 0 ? "#22c55e" : "#ef4444",
                  }}
                >
                  {fmtUSD(overallStats.totalPnL)}
                </div>
              </div>
            </div>

            <div className="kpis" style={{ marginTop: 10 }}>
              <KPI
                lab="Total Trades"
                val={fmtNum(overallStats.trades, 0)}
                tone="neutral"
              />
              <KPI
                lab="Win Rate"
                val={fmtPct(overallStats.winRate, 1)}
                tone={overallStats.winRate >= 50 ? "good" : "bad"}
              />
              <KPI
                lab="Profit Factor"
                val={fmtNum(overallStats.profitFactor, 2)}
                tone={overallStats.profitFactor >= 1 ? "good" : "bad"}
              />
              <KPI
                lab="Risk : Reward"
                val={
                  overallStats.avgLossUsd !== 0
                    ? fmtNum(
                        Math.abs(
                          overallStats.avgWinUsd /
                            Math.abs(overallStats.avgLossUsd)
                        ),
                        2
                      )
                    : "∞"
                }
                tone={
                  overallStats.avgLossUsd < 0
                    ? Math.abs(
                        overallStats.avgWinUsd /
                          Math.abs(overallStats.avgLossUsd)
                      ) >= 1
                      ? "good"
                      : "bad"
                    : "good"
                }
              />
            </div>

            <div className="kpis" style={{ marginTop: 10 }}>
              <KPI
                lab="Peak Balance"
                val={fmtUSD(overallStats.peakBal)}
                tone={overallStats.peakBal >= 0 ? "good" : "bad"}
              />
              <KPI
                lab="Lowest Balance"
                val={fmtUSD(overallStats.lowBal)}
                tone={overallStats.lowBal >= 0 ? "good" : "bad"}
              />
              <KPI
                lab="Average Peak Per Trade"
                val={fmtUSD(overallStats.avgMFE)}
                tone={overallStats.avgMFE >= 0 ? "good" : "bad"}
              />
              <KPI
                lab="Average Drawdown Per Trade"
                val={fmtUSD(-overallStats.avgMAE)}
                tone={overallStats.avgMAE > 0 ? "bad" : undefined}
              />
            </div>

            <div className="kpis" style={{ marginTop: 10, marginBottom: 18 }}>
              <KPI
                lab="Average Win"
                val={fmtUSD(overallStats.avgWinUsd)}
                tone="good"
              />
              <KPI
                lab="Average Loss"
                val={fmtUSD(overallStats.avgLossUsd)}
                tone="bad"
              />
              <KPI
                lab="Biggest Win"
                val={fmtUSD(overallStats.maxWinUsd)}
                tone="good"
              />
              <KPI
                lab="Biggest Loss"
                val={fmtUSD(overallStats.maxLossUsd)}
                tone="bad"
              />
            </div>

            <div className="kpis" style={{ marginTop: 10, marginBottom: 18 }}>
              <KPI
                lab="Total Longs"
                val={fmtNum(overallStats.longTrades, 0)}
                tone="neutral"
              />
              <KPI
                lab="Total Shorts"
                val={fmtNum(overallStats.shortTrades, 0)}
                tone="neutral"
              />
              <KPI
                lab="Average Trade Length"
                val={`${fmtNum(overallStats.avgLen, 1)} bars`}
                tone="neutral"
                tooltip={statTooltips.avgLen}
              />
              <KPI
                lab="Expected Value"
                val={fmtUSD(overallStats.expectedValue)}
                tone={overallStats.expectedValue >= 0 ? "good" : "bad"}
              />
            </div>
            {/* Additional statistics row */}
            <div className="kpis" style={{ marginTop: 10, marginBottom: 18 }}>
              <KPI
                lab="Avg Win Length"
                val={`${fmtNum(overallStats.avgWinLen, 1)} bars`}
                tone="good"
                tooltip={statTooltips.avgWin}
              />
              <KPI
                lab="Avg Loss Length"
                val={`${fmtNum(overallStats.avgLossLen, 1)} bars`}
                tone="bad"
                tooltip={statTooltips.avgLoss}
              />
              <KPI
                lab="Sharpe Ratio"
                val={fmtNum(overallStats.sharpe, 2)}
                tone={overallStats.sharpe >= 0 ? "good" : "bad"}
              />
              <KPI
                lab="Sortino Ratio"
                val={fmtNum(overallStats.sortino, 2)}
                tone={overallStats.sortino >= 0 ? "good" : "bad"}
              />
            </div>

            {/* Additional extended statistics */}
            <div
              className="kpis"
              style={{
                marginTop: 10,
                marginBottom: 18,
                gridTemplateColumns: "repeat(4, 1fr)",
              }}
            >
              <KPI
                lab="Typical Win Streak"
                // Show the typical win streak in number of trades rather than bars.
                val={`${fmtNum(overallStats.typicalWinStreak, 1)} trades`}
                tone="good"
              />
              <KPI
                lab="Typical Loss Streak"
                // Show the typical loss streak in number of trades rather than bars.
                val={`${fmtNum(overallStats.typicalLossStreak, 1)} trades`}
                tone="bad"
              />
              <KPI
                lab="Time to Recovery"
                val={`${fmtNum(overallStats.meanRecoveryBars, 1)} bars`}
                tone="neutral"
                tooltip={statTooltips.recovery}
              />
              <KPI
                lab="Market Beta"
                val={fmtNum(overallStats.beta, 2)}
                tone={overallStats.beta > 0 ? "bad" : "good"}
              />
            </div>
          </>
        )}

        {equityData.length > 0 && (
          <div
            className="card"
            style={{
              marginTop: 16,
              padding: 16,
              background:
                "radial-gradient(circle at top, rgba(16,185,129,0.18), transparent 55%) #020617",
            }}
          >
            <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 10 }}>
              Trade Equity Curve
            </div>
            <div style={{ width: "100%", height: 260 }}>
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={equityData}
                  margin={{ top: 10, right: 8, bottom: 0, left: 0 }}
                >
                  <defs>
                    <linearGradient
                      id="equityFillPos"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="0%" stopColor="rgba(52,211,153,0.35)" />
                      <stop offset="75%" stopColor="rgba(22,163,74,0.02)" />
                      <stop offset="100%" stopColor="rgba(15,23,42,0)" />
                    </linearGradient>
                    <linearGradient
                      id="equityFillNeg"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1"
                    >
                      <stop offset="0%" stopColor="rgba(239,68,68,0.35)" />
                      <stop offset="75%" stopColor="rgba(127,29,29,0.02)" />
                      <stop offset="100%" stopColor="rgba(15,23,42,0)" />
                    </linearGradient>
                    <filter
                      id="equityGlow"
                      x="-50%"
                      y="-50%"
                      width="200%"
                      height="200%"
                    >
                      <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                      <feMerge>
                        <feMergeNode in="coloredBlur" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>
                  <XAxis
                    dataKey="trade"
                    tick={{ fontSize: 12, fill: "#e5e7eb" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tickFormatter={(v) => fmtUSD(v as number).replace("$", "")}
                    tick={{ fontSize: 12, fill: "#e5e7eb" }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <ReferenceLine
                    y={0}
                    stroke="#9ca3af"
                    strokeOpacity={0.35}
                    strokeDasharray="6 6"
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (!active || !payload || !payload.length) return null;
                      const first = payload.find(
                        (p: any) => p && p.value != null
                      );
                      const val =
                        typeof first?.value === "number" ? first.value : null;
                      return (
                        <div
                          style={{
                            background: "#020617",
                            border: "1px solid #1f2937",
                            borderRadius: 12,
                            padding: "8px 10px",
                            color: "#e5e7eb",
                            fontSize: 12,
                            boxShadow: "0 0 12px rgba(15,23,42,0.7)",
                          }}
                        >
                          <div style={{ opacity: 0.8, marginBottom: 4 }}>
                            Trade #{label}
                          </div>
                          <div style={{ fontWeight: 700 }}>
                            PnL: {val == null ? "–" : fmtUSD(val)}
                          </div>
                        </div>
                      );
                    }}
                  />
                  {/* Positive leg */}
                  <Area
                    type="monotone"
                    dataKey="pos"
                    stroke="none"
                    fill="url(#equityFillPos)"
                    isAnimationActive={true}
                    animationDuration={900}
                    animationEasing="ease-out"
                    connectNulls={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="pos"
                    stroke="#5ef3c7"
                    strokeWidth={3}
                    dot={false}
                    activeDot={{ r: 6 }}
                    style={{ filter: "url(#equityGlow)" }}
                    isAnimationActive={false}
                    connectNulls={false}
                  />
                  {/* Negative leg */}
                  <Area
                    type="monotone"
                    dataKey="neg"
                    stroke="none"
                    fill="url(#equityFillNeg)"
                    isAnimationActive={true}
                    animationDuration={900}
                    animationEasing="ease-out"
                    connectNulls={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="neg"
                    stroke="#f87171"
                    strokeWidth={3}
                    dot={false}
                    activeDot={{ r: 6 }}
                    style={{ filter: "url(#equityGlow)" }}
                    isAnimationActive={false}
                    connectNulls={false}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Small spacing before the calendar for consistent rhythm */}
        <div style={{ height: 12 }} />

        <div className="card" style={{ marginTop: 6 }}>
          <div className="cal-head">
            <div className="row" style={{ alignItems: "baseline", gap: 8 }}>
              <button
                className="btn"
                onClick={() =>
                  setMonth(
                    (d) => new Date(d.getFullYear(), d.getMonth() - 1, 1)
                  )
                }
              >
                ◀
              </button>
              <div>{format(month, "MMMM yyyy")}</div>
              <button
                className="btn"
                onClick={() =>
                  setMonth(
                    (d) => new Date(d.getFullYear(), d.getMonth() + 1, 1)
                  )
                }
              >
                ▶
              </button>
            </div>
          </div>

          {/* Display monthly PnL centered below the calendar header. Position it
             slightly higher and increase its font size for better prominence. */}
          <div
            style={{
              textAlign: "center",
              // Raise the monthly PnL display higher above the calendar and make it larger.
              marginTop: "-6px",
              marginBottom: "8px",
            }}
          >
            <span
              style={{
                color:
                  monthPnL > 0
                    ? "#22c55e"
                    : monthPnL < 0
                    ? "#ef4444"
                    : "#94a3b8",
                fontWeight: 700,
                fontSize: "1.4rem",
              }}
            >
              {fmtUSD(monthPnL)}
            </span>
          </div>

          <div className="cal-grid">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((x) => (
              <div key={x} className="cal-dow">
                {x}
              </div>
            ))}
            {(() => {
              const first = startOfMonth(month);
              const grid = startOfWeek(first, { weekStartsOn: 0 });
              return Array.from({ length: 42 }, (_, i) => addDays(grid, i)).map(
                (d) => {
                  const k = format(d, "yyyy-MM-dd");
                  const dayTrades = trades.filter(
                    (tr) => format(new Date(tr.exitTs), "yyyy-MM-dd") === k
                  );
                  const v = dayTrades.reduce((a, b) => a + b.pnl, 0);
                  const cnt = dayTrades.length;
                  const inM = isSameMonth(d, month);
                  const bg =
                    cnt === 0
                      ? "#0b0b0b"
                      : v > 0
                      ? "rgba(34,197,94,.16)"
                      : v < 0
                      ? "rgba(239,68,68,.16)"
                      : "rgba(148,163,184,.12)";
                  const bd =
                    k === selectedDay
                      ? "2px solid #22c55e"
                      : "1px solid #111827";
                  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
                  return (
                    <button
                      key={k}
                      onClick={() => setSelectedDay(k)}
                      className="cal-cell"
                      style={{
                        background: bg,
                        border: bd,
                        opacity: inM ? 1 : 0.4,
                      }}
                    >
                      <div className="num">{format(d, "d")}</div>
                      <div
                        className="pnl"
                        style={{
                          color:
                            cnt > 0
                              ? v > 0
                                ? "#22c55e"
                                : v < 0
                                ? "#ef4444"
                                : "#94a3b8"
                              : "#94a3b8",
                        }}
                      >
                        {cnt > 0 ? `${sign}$${nf0.format(Math.abs(v))}` : ""}
                      </div>
                      <div className="count">
                        {cnt
                          ? `${nf0.format(cnt)} trade${cnt === 1 ? "" : "s"}`
                          : ""}
                      </div>
                    </button>
                  );
                }
              );
            })()}
          </div>
        </div>

        {/* Day detail */}
        {selectedDay && (
          <>
            <div className="kpis" style={{ marginTop: 12 }}>
              <KPI
                lab="Trades"
                val={fmtNum(
                  trades.filter(
                    (tr) =>
                      format(new Date(tr.exitTs), "yyyy-MM-dd") === selectedDay
                  ).length,
                  0
                )}
              />
              <KPI
                lab="Win Rate"
                val={fmtPct(
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const w = d.filter((x) => x.pnl > 0).length;
                    return d.length ? (100 * w) / d.length : 0;
                  })(),
                  1
                )}
                tone={
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const w = d.filter((x) => x.pnl > 0).length;
                    return d.length ? (100 * w) / d.length : 0;
                  })() >= 50
                    ? "good"
                    : "bad"
                }
              />
              <KPI
                lab="Average Trade ($)"
                val={fmtUSD(
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const s = d.reduce((a, b) => a + b.pnl, 0);
                    return d.length ? s / d.length : 0;
                  })()
                )}
                tone={
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const s = d.reduce((a, b) => a + b.pnl, 0);
                    return d.length ? s / d.length : 0;
                  })() >= 0
                    ? "good"
                    : "bad"
                }
              />
              <KPI
                lab="Profit Factor"
                val={fmtNum(
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const w = d
                      .filter((x) => x.pnl > 0)
                      .reduce((a, b) => a + b.pnl, 0);
                    const l = Math.abs(
                      d.filter((x) => x.pnl < 0).reduce((a, b) => a + b.pnl, 0)
                    );
                    return l > 0 ? w / l : d.length ? 99 : 0;
                  })(),
                  2
                )}
                tone={
                  (() => {
                    const d = trades.filter(
                      (tr) =>
                        format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                        selectedDay
                    );
                    const w = d
                      .filter((x) => x.pnl > 0)
                      .reduce((a, b) => a + b.pnl, 0);
                    const l = Math.abs(
                      d.filter((x) => x.pnl < 0).reduce((a, b) => a + b.pnl, 0)
                    );
                    return l > 0 ? w / l : d.length ? 99 : 0;
                  })() >= 1
                    ? "good"
                    : "bad"
                }
              />
            </div>

            <div
              className="card"
              style={{ marginTop: 12, padding: 0, overflow: "hidden" }}
            >
              <table className="table">
                <thead>
                  <tr>
                    {[
                      "Side",
                      "Entry",
                      "Exit",
                      "Duration",
                      "PnL",
                      "Peak $",
                      "Max DD $",
                      "Reason",
                    ].map((h) => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {trades.filter(
                    (tr) =>
                      format(new Date(tr.exitTs), "yyyy-MM-dd") === selectedDay
                  ).length ? (
                    trades
                      .filter(
                        (tr) =>
                          format(new Date(tr.exitTs), "yyyy-MM-dd") ===
                          selectedDay
                      )
                      .map((tr, i) => {
                        let mfe = 0,
                          mae = 0;
                        for (let k = tr.entryIdx; k <= tr.exitIdx; k++) {
                          const hi = rows[k].high,
                            lo = rows[k].low;
                          if (tr.side === "LONG") {
                            mfe = Math.max(
                              mfe,
                              (hi - tr.entryPrice) * unitValue
                            );
                            mae = Math.max(
                              mae,
                              Math.max(0, (tr.entryPrice - lo) * unitValue)
                            );
                          } else {
                            mfe = Math.max(
                              mfe,
                              (tr.entryPrice - lo) * unitValue
                            );
                            mae = Math.max(
                              mae,
                              Math.max(0, (hi - tr.entryPrice) * unitValue)
                            );
                          }
                        }
                        const durMs = tr.exitTs - tr.entryTs;
                        const barsCount = tr.exitIdx - tr.entryIdx;

                        const reasonText =
                          tr.exitReason === "TP"
                            ? "Take Profit"
                            : tr.exitReason === "SL"
                            ? "Stop Loss"
                            : tr.exitReason === "End"
                            ? "End of Data"
                            : tr.exitReason === "MaxBars"
                            ? "Max Duration"
                            : tr.exitReason === "TargetLen"
                            ? "Target Range"
                            : tr.exitReason === "TurnedSideways"
                            ? "Turned Sideways"
                            : tr.exitReason === "LostConfidence"
                            ? "Lost Confidence"
                            : tr.exitReason;

                        return (
                          <tr key={i}>
                            <td
                              style={{
                                color:
                                  tr.side === "LONG" ? "#22c55e" : "#ef4444",
                                fontWeight: 700,
                              }}
                            >
                              {tr.side}
                            </td>
                            <td>
                              {format(new Date(tr.entryTs), "MMM d hh:mm a")}
                              <div className="muted" style={{ fontSize: 12 }}>
                                {fmtPrice(tr.entryPrice)}
                              </div>
                            </td>
                            <td>
                              {format(new Date(tr.exitTs), "MMM d hh:mm a")}
                              <div className="muted" style={{ fontSize: 12 }}>
                                {fmtPrice(tr.exitPrice)}
                              </div>
                            </td>
                            <td>
                              {`${barsCount} bars `}
                              <span className="muted">
                                ({fmtDuration(durMs)})
                              </span>
                            </td>
                            <td
                              style={{
                                color: tr.pnl >= 0 ? "#22c55e" : "#ef4444",
                                fontWeight: 700,
                              }}
                            >
                              {fmtUSD(tr.pnl)}
                            </td>
                            <td style={{ color: "#22c55e", fontWeight: 700 }}>
                              {fmtUSD(mfe)}
                            </td>
                            <td style={{ color: "#ef4444", fontWeight: 700 }}>
                              {fmtUSD(-mae)}
                            </td>
                            <td>{reasonText}</td>
                          </tr>
                        );
                      })
                  ) : (
                    <tr>
                      <td colSpan={8} className="muted">
                        No trades.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </>
        )}
        <div
          style={{ display: "flex", justifyContent: "center", marginTop: 18 }}
        >
          <button
            className="btn btn-rect"
            style={{ width: 360 }}
            onClick={handleDownloadJson}
            // Enabled only when a model is loaded. Downloading exports the model
            // rather than backtest results, so it does not depend on trades or stats.
            disabled={!readyModel}
          >
            Download JSON
          </button>
        </div>
      </div>
    </>
  );
}

/* ---------- Small components ---------- */
function KPI({
  lab,
  val,
  tone,
  span4,
  tooltip,
}: {
  /** Label text or node to describe the KPI. */
  lab: React.ReactNode;
  /** Value text to display. */
  val: string;
  /**
   * Tone determines the color of the value: "good" (green), "bad" (red),
   * "warn" (yellow) or "neutral" (blue). Undefined uses default color.
   */
  tone?: "good" | "bad" | "warn" | "neutral";
  /** Whether this KPI should span all four columns in its grid. */
  span4?: boolean;
  /**
   * Optional tooltip text. When provided, a question mark icon will appear
   * next to the label. Hovering over the icon shows the tooltip instantly.
   */
  tooltip?: string;
}) {
  return (
    <div className={`kpi ${tone ? tone : ""} ${span4 ? "span4" : ""}`}>
      <div
        className="lab"
        style={{ display: "flex", alignItems: "center", gap: 4 }}
      >
        {lab}
        {tooltip && (
          <span className="tt" data-tip={tooltip}>
            ?
          </span>
        )}
      </div>
      <div className="val">{val}</div>
    </div>
  );
}

/* ===== Dual handle slider ===== */
function DualRange({
  min,
  max,
  lo,
  hi,
  onChange,
}: {
  min: number;
  max: number;
  lo: number;
  hi: number;
  onChange: (lo: number, hi: number) => void;
}) {
  const barRef = useRef<HTMLDivElement | null>(null);
  const [low, setLow] = useState(lo);
  const [high, setHigh] = useState(hi);
  const dragging = useRef<"low" | "high" | null>(null);
  useEffect(() => setLow(lo), [lo]);
  useEffect(() => setHigh(hi), [hi]);

  const clamp = (v: number) => Math.max(min, Math.min(max, v));
  function posToValue(clientX: number) {
    const el = barRef.current!;
    const rect = el.getBoundingClientRect();
    const frac = (clientX - (rect.left + 8)) / (rect.width - 16);
    const v = min + frac * (max - min);
    return clamp(Math.round(v));
  }
  const onDownLow = () => {
    dragging.current = "low";
  };
  const onDownHigh = () => {
    dragging.current = "high";
  };
  function onMove(e: React.MouseEvent) {
    if (!dragging.current || !barRef.current) return;
    const val = posToValue(e.clientX);
    if (dragging.current === "low") {
      const nv = Math.min(val, high);
      setLow(nv);
      onChange(nv, high);
    } else {
      const nv = Math.max(val, low);
      setHigh(nv);
      onChange(low, nv);
    }
  }
  const endDrag = () => {
    dragging.current = null;
  };

  const leftPx = ((low - min) / (max - min)) * 100;
  const rightPx = ((high - min) / (max - min)) * 100;

  return (
    <div
      className="range2"
      onMouseMove={onMove}
      onMouseLeave={endDrag}
      onMouseUp={endDrag}
    >
      <div ref={barRef} className="range2-track" />
      <div
        className="range2-fill"
        style={{
          left: `calc(${leftPx}% + 8px)`,
          right: `calc(${100 - rightPx}% + 8px)`,
        }}
      />
      <div
        className="range2-handle"
        style={{ left: `calc(${leftPx}% + 8px)` }}
        onMouseDown={onDownLow}
        title="Minimum"
      />
      <div
        className="range2-handle"
        style={{ left: `calc(${rightPx}% + 8px)` }}
        onMouseDown={onDownHigh}
        title="Maximum"
      />
      <div className="tiny" style={{ position: "absolute", top: 0, right: 8 }}>
        {low} — {high} bars
      </div>
    </div>
  );
}
