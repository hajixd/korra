import { createPortal } from "react-dom";

function ToastPortal({ message }: { message: string | null }) {
  if (!message) return null;
  return createPortal(
    <div className="fixed inset-x-0 bottom-4 z-[100] flex justify-center pointer-events-none">
      <div className="pointer-events-auto px-6 py-3 rounded-2xl bg-emerald-600 text-white font-semibold shadow-2xl">
        {message}
      </div>
    </div>,
    document.body
  );
}

export default ToastPortal;
