import React, { useEffect, useMemo, useRef, useState } from "react";

const SHARED_MODEL_KEY = "intuition_model_v1";
const BACKTEST_HANDOFF_KEY = "intuition_backtest_v1";

const GlobalBlack: React.FC = () => {
  useEffect(() => {
    const style = document.createElement("style");
    style.innerHTML = `
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');

      html, body, #root { height:100%; background:#000; margin:0; padding:0; }
      body { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; color:#e5e7eb; }
      * { box-sizing:border-box; }

      .container { width:min(1200px, 96vw); margin:0 auto; }

      /* Buttons */
      .btn {
        border:1.5px solid rgba(255,255,255,.18);
        padding:12px 26px; border-radius:12px; font-size:20px;
        background:transparent; color:#e5e7eb; cursor:pointer;
        transition: transform .12s ease, box-shadow .2s ease, background .2s ease, color .2s ease, border-color .2s ease;
      }
      .btn:hover { transform: scale(1.03); }
      .btn:active { transform: scale(0.98); }
      .btn-green { border-color:#22c55e; color:#22c55e }
      .btn-green:hover { background:#22c55e; color:#0a0a0a; box-shadow:0 0 20px rgba(34,197,94,.3) }
      .btn-red { border-color:#ef4444; color:#ef4444 }
      .btn-red:hover { background:#ef4444; color:#0a0a0a; box-shadow:0 0 20px rgba(239,68,68,.3) }
      .btn-gray  { border-color:#6b7280; color:#9ca3af }
      .btn-gray:hover  { background:#9ca3af; color:#0a0a0a; box-shadow:0 0 20px rgba(156,163,175,.3) }
      .btn-full  { width: 100% }
      .btn-wide  { width: min(700px, 46vw) }

      /* Pills & Inputs */
      .pill {
        border:1.5px solid #262b39; border-radius:14px; min-height:60px;
        display:flex; align-items:center; padding:10px 14px; gap:12px;
        background:linear-gradient(180deg, rgba(12,13,16,.9), rgba(10,10,10,.6));
      }
      .pill:focus-within { border-color:#64748b; box-shadow:0 0 0 4px rgba(100,116,139,.12); }
      .pill-select, .pill-input {
        appearance:none; background:transparent; color:#e5e7eb;
        border:none; outline:none; font-size:16px;
      }
      .pill-select { padding:8px 10px; border-radius:10px; background:rgba(255,255,255,.03); }

      /* Tooltips */
      .tip { position:relative; display:inline-flex; align-items:center; gap:6px; }
      .tip-badge { display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; border-radius:999px; border:1px solid #334155; color:#94a3b8; font-size:12px; cursor:help; }
      .tip .tip-text {
        visibility:hidden; opacity:0; position:absolute; bottom:120%; left:50%; transform:translateX(-50%);
        background:#0b0f16; border:1px solid #1f2937; color:#cbd5e1; padding:8px 10px; border-radius:10px; white-space:nowrap; font-size:12px; transition:opacity .12s ease;
        box-shadow:0 10px 30px rgba(0,0,0,.45);
      }
      .tip:hover .tip-text { visibility:visible; opacity:1; }

      /* Sliders */
      .slider {
        -webkit-appearance:none; appearance:none; width:100%;
        height:12px; border-radius:999px;
        background: linear-gradient(90deg, #1f2937, #334155);
        outline:none; cursor:grab; pointer-events:auto; touch-action:none;
      }
      .slider:active { cursor:grabbing; }
      .slider::-webkit-slider-thumb {
        -webkit-appearance:none; width:28px; height:28px; border-radius:999px;
        background:#22c55e; border:2px solid #0b0b0b;
        box-shadow:0 0 0 6px rgba(34,197,94,.15);
        transition: box-shadow .15s ease, transform .12s ease;
      }
      .slider:hover::-webkit-slider-thumb { box-shadow:0 0 0 10px rgba(34,197,94,.22); transform: scale(1.04); }
      .slider:active::-webkit-slider-thumb { transform: scale(0.98); }
      .slider::-moz-range-thumb {
        width:28px; height:28px; border-radius:999px; background:#22c55e; border:2px solid #0b0b0b;
      }

      /* Spinner + Progress */
      @keyframes spin { to { transform: rotate(360deg); } }
      .spinner { width:56px; height:56px; border-radius:999px; border:4px solid #1f2937; border-top-color:#22c55e; animation: spin 0.9s linear infinite; }
      .pb { height:10px; width:100%; border:1px solid #2a2a2a; border-radius:999px; overflow:hidden; background:#0b0b0b; }
      .pb-fill { height:100%; background:#22c55e; transition: width .25s ease; }

      @keyframes pulseFlash { 0%{opacity:0} 12%{opacity:.35} 100%{opacity:0} }
      .pulse-green,.pulse-red,.pulse-gray { position:absolute; inset:0; border-radius:12px; pointer-events:none; animation:pulseFlash 420ms ease-out forwards; }
      .pulse-green { background: radial-gradient(circle at 50% 50%, rgba(34,197,94,.22), rgba(34,197,94,.12) 35%, rgba(34,197,94,0) 70%); box-shadow: 0 0 40px rgba(34,197,94,.18) inset, 0 0 16px rgba(34,197,94,.18); }
      .pulse-red   { background: radial-gradient(circle at 50% 50%, rgba(239,68,68,.22), rgba(239,68,68,.12) 35%, rgba(239,68,68,0) 70%); box-shadow: 0 0 40px rgba(239,68,68,.18) inset, 0 0 16px rgba(239,68,68,.18); }
      .pulse-gray  { background: radial-gradient(circle at 50% 50%, rgba(156,163,175,.22), rgba(156,163,175,.12) 35%, rgba(156,163,175,0) 70%); box-shadow: 0 0 40px rgba(156,163,175,.18) inset, 0 0 16px rgba(156,163,175,.18); }

      .grid { display:grid; gap:22px; }
      @media (min-width:1100px){ .grid-4 { grid-template-columns: repeat(4,minmax(220px,1fr)); } }
      @media (max-width:1099px){ .grid-4 { grid-template-columns: repeat(2,minmax(220px,1fr)); } }
      .card {
        border:1.5px solid #262b39; border-radius:18px; padding:20px;
        background:
          radial-gradient(420px 220px at 50% 0%, rgba(34,197,94,.05), transparent 70%),
          linear-gradient(180deg, rgba(10,10,10,.75), rgba(10,10,10,.5));
        transition:border-color .2s ease, box-shadow .2s ease, transform .12s ease, background .2s ease;
        cursor:pointer; min-height:220px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px;
      }
      .card:hover { transform: translateY(-3px); }
      .card.active { border-color:#22c55e; box-shadow: 0 0 26px rgba(34,197,94,.16) inset, 0 0 14px rgba(34,197,94,.16); }
      .card h3 { margin:0; font-size:16px; color:#e5e7eb; text-align:center; }
      .icon-wrap { width:88px; height:88px; border-radius:14px; border:1px solid #2b2f3c; display:flex; align-items:center; justify-content:center; background:#0a0a0a; }

      .sel-indicator { position:absolute; top:10px; right:10px; display:flex; align-items:center; gap:8px; }
      .sel-dot { width:10px; height:10px; border-radius:999px; background:#22c55e; box-shadow:0 0 12px #22c55e66; }

      .pager-btn { position:absolute; top:50%; transform:translateY(-50%); width:42px; height:42px; border-radius:999px; border:1px solid #2a2f3c; display:flex; align-items:center; justify-content:center; background:rgba(10,10,10,.8); cursor:pointer; }
      .pager-btn:hover { transform: translateY(-50%) scale(1.06); box-shadow: 0 0 16px rgba(255,255,255,.08); }
      .pager-left { left:-18px; }
      .pager-right { right:-18px; }

      .page-wrap { position:relative; overflow:hidden; width:100%; }
      .page { width:100%; }
      @keyframes slideInFromRight { 0% {opacity:0; transform:translateX(32px);} 100% {opacity:1; transform:translateX(0);} }
      @keyframes slideInFromLeft  { 0% {opacity:0; transform:translateX(-32px);} 100% {opacity:1; transform:translateX(0);} }
      .slide-right { animation: slideInFromRight 260ms ease-out; }
      .slide-left  { animation: slideInFromLeft  260ms ease-out; }

      /* Settings grids (centered & symmetrical) */
      .settings-grid {
        display:grid;
        grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
        gap:16px;
        align-items:stretch;
        justify-items:stretch;
        width:100%;
        margin-top:10px;
      }
      .settings-row {
        display:grid;
        grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
        gap:16px;
        width:100%;
      }

      /* Loader overlay */
      .load-overlay { position: fixed; inset: 0; z-index: 9999; display:flex; align-items:center; justify-content:center;
        background: radial-gradient(1000px 600px at 50% 40%, rgba(34,197,94,.08), transparent 60%), radial-gradient(900px 700px at 20% 80%, rgba(100,116,139,.08), transparent 60%), #000; backdrop-filter: blur(2px);
      }
      .load-box { width:min(680px, 92vw); border:1px solid #2a2f3c; border-radius:18px; padding:24px; background:linear-gradient(180deg, rgba(8,8,10,.92), rgba(8,8,10,.7));
        box-shadow: 0 20px 90px rgba(0,0,0,.6), inset 0 0 40px rgba(255,255,255,.02);
      }
      .load-title { font-size: 22px; font-weight: 800; margin-bottom: 8px; color:#e5e7eb; }
      .load-sub { color:#9ca3af; font-size: 14px; margin-bottom: 18px; }
      .load-row { display:flex; align-items:center; gap:14px; }
      .load-bar-outer { height:10px; border:1px solid #2b2b2b; border-radius:999px; overflow:hidden; background:#0b0b0b; width:100%; }
      .load-bar-fill { height:100%; width:0%; background:#22c55e; transition: width .35s ease; }
      .load-foot { margin-top:10px; color:#6b7280; font-size:12px; display:flex; gap:10px; flex-wrap:wrap; }

      /* Summary look — neon glass */
      .banner {
        width:100%;
        border:1px solid #263042; border-radius:18px;
        background:
          radial-gradient(900px 300px at 10% -20%, rgba(34,197,94,.12), transparent 60%),
          radial-gradient(900px 500px at 110% -10%, rgba(59,130,246,.12), transparent 60%),
          linear-gradient(180deg, rgba(9,11,15,.92), rgba(9,11,15,.7));
        padding:18px 20px; box-shadow: 0 20px 90px rgba(0,0,0,.55), inset 0 0 24px rgba(255,255,255,.02);
      }
      .badge {
        display:inline-flex; align-items:center; gap:10px;
        border:1px solid #2e394d; background:rgba(15,18,24,.7); border-radius:999px; padding:8px 14px; font-weight:700;
      }
      .stat-grid { display:grid; grid-template-columns:repeat(4,minmax(220px,1fr)); gap:12px; width:100%; }
      .stat-card {
        border:1px solid #263042; border-radius:14px; padding:14px;
        background:linear-gradient(180deg, rgba(10,12,15,.8), rgba(8,10,13,.6));
        box-shadow: inset 0 0 24px rgba(255,255,255,.02), 0 6px 30px rgba(0,0,0,.35);
        transition: box-shadow .15s ease, border-color .15s ease;
      }
      .stat-k { color:#9ca3af; font-size:12px; letter-spacing:.3px; margin-bottom:6px; }
      .stat-v { font-size:20px; font-weight:800; }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);
  return null;
};

/* ===================== Types & Utils ===================== */
interface Bar {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
}
type ClassLabel = "BULL" | "BEAR" | "SIDE";

type AnyObject = Record<string, any>;

type ModelSnapshot = {
  version: string;
  type: "OvR-perceptron";
  featureDim: number;
  sideMargin: number;
  scaleFeatures: boolean;
  classLabels: ClassLabel[];
  heads: { BULL: number[]; BEAR: number[]; SIDE: number[] };
  meta: AnyObject;
};

type BacktestHandoff = {
  version: string;
  savedAt: string;
  model: ModelSnapshot;
  data: {
    symbol: string;
    interval: string;
    windowLen: number;
    minWindowSep: number;
    strategies: string[];
    complexity: number;
    dataCacheKey: string;
    barsCount?: number;
  };
  metrics: {
    learned: number;
    tested: number;
    summary: {
      N: number;
      overallAcc: number;
      balancedAcc: number;
      macroF1: number;
    };
  };
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const clamp = (x: number, a: number, b: number) => Math.max(a, Math.min(b, x));
const safeDiv = (a: number, b: number) => (b === 0 ? 0 : a / b);
function mean(a: number[]) {
  return a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
}
function variance(a: number[]) {
  const m = mean(a);
  return a.length ? mean(a.map((v) => (v - m) * (v - m))) : 0;
}
function std(a: number[]) {
  return Math.sqrt(Math.max(variance(a), 1e-12));
}
function entropyFromCounts(cnts: number[]) {
  const n = cnts.reduce((s, x) => s + x, 0) || 1;
  let H = 0;
  for (const c of cnts)
    if (c > 0) {
      const p = c / n;
      H += -p * Math.log2(p);
    }
  return H;
}
function l2norm(v: number[]) {
  const s = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1;
  return v.map((x) => x / s);
}

/* ===================== Model (Perceptron with LR Decay) ===================== */
function sign(z: number) {
  return z >= 0 ? 1 : -1;
}
function dot(a: number[], b: number[]) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += (a[i] || 0) * (b[i] || 0);
  return s;
}

class Perceptron {
  w: number[];
  v: number[];
  lr: number;
  wd: number;
  mu: number;
  lrDecay: number;
  constructor(dim: number, lr = 0.25, wd = 0.0005, mu = 0.0, lrDecay = 0.0) {
    this.lr = lr;
    this.wd = wd;
    this.mu = mu;
    this.lrDecay = lrDecay;
    this.w = new Array(dim + 1).fill(0).map(() => (Math.random() - 0.5) * 0.01);
    this.v = new Array(dim + 1).fill(0);
  }
  score(x: number[]) {
    return dot(this.w, [1, ...x]);
  }
  train(x: number[], y: number) {
    const aug = [1, ...x];
    const yhat = sign(dot(this.w, aug));
    if (yhat !== y) {
      const delta = (this.lr * (y - yhat)) / 2;
      for (let i = 0; i < this.v.length; i++) {
        const grad = delta * (aug[i] || 0);
        this.v[i] = this.mu * this.v[i] + grad;
        this.w[i] = (1 - this.wd) * this.w[i] + this.v[i];
      }
    } else {
      for (let i = 0; i < this.w.length; i++) this.w[i] *= 1 - this.wd;
    }
    if (this.lrDecay > 0)
      this.lr = Math.max(1e-6, this.lr * (1 - this.lrDecay));
  }
}

class OvR {
  classes: ClassLabel[] = ["BULL", "BEAR", "SIDE"];
  heads: Record<ClassLabel, Perceptron>;
  sideMargin: number;
  constructor(
    dim: number,
    lr = 0.25,
    wd = 0.0005,
    mu = 0.0,
    sideMargin = 0.05,
    lrDecay = 0.0
  ) {
    this.heads = {
      BULL: new Perceptron(dim, lr, wd, mu, lrDecay),
      BEAR: new Perceptron(dim, lr, wd, mu, lrDecay),
      SIDE: new Perceptron(dim, lr, wd, mu, lrDecay),
    };
    this.sideMargin = sideMargin;
  }
  rawScores(x: number[]) {
    return {
      BULL: this.heads.BULL.score(x),
      BEAR: this.heads.BEAR.score(x),
      SIDE: this.heads.SIDE.score(x),
    };
  }
  predict(x: number[]): ClassLabel {
    const s = this.rawScores(x);
    const arr = [
      { k: "BULL", v: s.BULL },
      { k: "BEAR", v: s.BEAR },
      { k: "SIDE", v: s.SIDE },
    ].sort((a, b) => b.v - a.v);
    if (arr[0].v - arr[1].v < this.sideMargin) return "SIDE";
    return arr[0].k as ClassLabel;
  }
  train(x: number[], yTrue: ClassLabel) {
    for (const c of this.classes) this.heads[c].train(x, c === yTrue ? +1 : -1);
  }
  toJSON(featureDim: number, scaleFeatures: boolean): ModelSnapshot {
    return {
      version: "2025-11-08.iv1",
      type: "OvR-perceptron",
      featureDim,
      sideMargin: this.sideMargin,
      scaleFeatures,
      classLabels: ["BULL", "BEAR", "SIDE"],
      heads: {
        BULL: this.heads.BULL.w,
        BEAR: this.heads.BEAR.w,
        SIDE: this.heads.SIDE.w,
      },
      meta: {},
    };
  }
}

/* ===================== Features & Strategies ===================== */
function linRegStats(y: number[]) {
  const n = y.length,
    xm = (n - 1) / 2;
  let num = 0,
    den = 0,
    ym = mean(y);
  for (let i = 0; i < n; i++) {
    const dx = i - xm;
    num += dx * (y[i] - ym);
    den += dx * dx;
  }
  const slope = num / (den || 1e-9);
  let ssTot = 0,
    ssRes = 0;
  for (let i = 0; i < n; i++) {
    const yhat = slope * (i - xm) + ym;
    ssTot += (y[i] - ym) ** 2;
    ssRes += (y[i] - yhat) ** 2;
  }
  return { slope, r2: 1 - ssRes / (ssTot || 1e-9) };
}
function adxLike(
  highs: number[],
  lows: number[],
  closes: number[],
  period = 14
) {
  let trs: number[] = [],
    dmp: number[] = [],
    dmn: number[] = [];
  for (let i = 1; i < highs.length; i++) {
    const upMove = Math.max(0, highs[i] - highs[i - 1]);
    const dnMove = Math.max(0, lows[i - 1] - lows[i]);
    dmp.push(upMove > dnMove ? upMove : 0);
    dmn.push(dnMove > upMove ? dnMove : 0);
    trs.push(
      Math.max(
        highs[i] - lows[i],
        Math.abs(highs[i] - closes[i - 1]),
        Math.abs(lows[i] - closes[i - 1])
      )
    );
  }
  const sum = (arr: number[], i: number, p: number) =>
    arr.slice(Math.max(0, i - p + 1), i + 1).reduce((a, b) => a + b, 0);
  let dx: number[] = [];
  for (let i = 0; i < trs.length; i++) {
    const tr14 = sum(trs, i, period) || 1e-9,
      dmp14 = sum(dmp, i, period),
      dmn14 = sum(dmn, i, period);
    const dip = 100 * (dmp14 / tr14),
      dim = 100 * (dmn14 / tr14);
    dx.push(100 * (Math.abs(dip - dim) / Math.max(dip + dim, 1e-9)));
  }
  const adx = mean(dx.slice(-period));
  return isFinite(adx) ? adx : 0;
}
function autocorrLag1(a: number[]) {
  if (a.length < 2) return 0;
  const m = mean(a),
    s2 = variance(a) || 1e-9;
  let num = 0;
  for (let i = 1; i < a.length; i++) num += (a[i] - m) * (a[i - 1] - m);
  return num / ((a.length - 1) * s2);
}

/* ---- Strategy enums ---- */
enum CoreStrat {
  SR = "Support & Resistance",
  TREND = "Trend Following",
  MA = "Moving Averages",
  VOL = "Volatility / Bands",
  MOM = "Momentum",
  MR = "Mean Reversion",
  BO = "Breakout / ADX",
  CANDLE = "Candlestick Bodies",
}
enum FullStrat {
  ICT = "Inner Circle Trading (ICT)",
  SMC = "Smart Money Concepts (SMC)",
  WYCKOFF = "Wyckoff Method",
  RTM = "Read The Market (RTM)",
  TURTLE = "Turtle Trading System",
  DONCHIAN = "Donchian Channels Suite",
  MP = "Market Profile",
  VSA = "Volume Spread Analysis",
}
type AnyStrat = CoreStrat | FullStrat;
const CORE: CoreStrat[] = [
  CoreStrat.SR,
  CoreStrat.TREND,
  CoreStrat.MA,
  CoreStrat.VOL,
  CoreStrat.MOM,
  CoreStrat.MR,
  CoreStrat.BO,
  CoreStrat.CANDLE,
];
const FULL: FullStrat[] = [
  FullStrat.ICT,
  FullStrat.SMC,
  FullStrat.WYCKOFF,
  FullStrat.RTM,
  FullStrat.TURTLE,
  FullStrat.DONCHIAN,
  FullStrat.MP,
  FullStrat.VSA,
];

/* ---- Feature extraction ---- */
function buildFeatureBank(win: Bar[]) {
  const n = win.length;
  const closes = win.map((b) => b.close),
    highs = win.map((b) => b.high),
    lows = win.map((b) => b.low),
    opens = win.map((b) => b.open);
  const p = closes[n - 1];

  const rets: number[] = [];
  const body: number[] = [];
  for (let i = n - 5; i < n; i++) {
    rets.push(Math.log(closes[i] / (closes[i - 1] || closes[i])));
    const rng = Math.max(1e-9, highs[i] - lows[i]);
    body.push((closes[i] - opens[i]) / rng);
  }

  const c20 = closes.slice(-20),
    c50 = closes.slice(-50);
  const { slope: slope20, r2: r220 } = linRegStats(c20);
  const { slope: slope50, r2: r250 } = linRegStats(c50);
  const sd20 = std(c20),
    sd50 = std(c50);
  const slope20N = slope20 / Math.max(p, 1e-9),
    slope50N = slope50 / Math.max(p, 1e-9);
  const slope20z = slope20 / Math.max(sd20, 1e-9),
    slope50z = slope50 / Math.max(sd50, 1e-9);

  const m20 = mean(c20),
    m50 = mean(c50);
  const bbWidth20 = sd20 / Math.max(m20, 1e-9);

  const adx14 = adxLike(
    highs.slice(-60),
    lows.slice(-60),
    closes.slice(-60),
    14
  );

  const acRet = autocorrLag1(
    closes
      .slice(1)
      .map((c, i) => Math.log(c / (closes[i] || c)))
      .slice(-30)
  );
  const signs = closes.slice(1).map((c, i) => (c >= closes[i] ? 1 : -1));
  const acSign = autocorrLag1(signs.slice(-30));

  const last50 = c50,
    hi50 = Math.max(...last50),
    lo50 = Math.min(...last50),
    band50 = hi50 - lo50;
  const rangeStd50 = band50 / Math.max(std(last50), 1e-9);
  const trendEff50 = band50 / Math.max(Math.abs(slope50) * 50, 1e-9);

  const bodyRatios = win
    .slice(-10)
    .map((b) => (b.close - b.open) / Math.max(1e-9, b.high - b.low));
  const bodyMean = mean(bodyRatios),
    bodyAbsMean = mean(bodyRatios.map(Math.abs));
  const dojiRate =
    bodyRatios.filter((r) => Math.abs(r) < 0.1).length /
    Math.max(1, bodyRatios.length);

  const trs: number[] = [];
  for (let i = 1; i < highs.length; i++) {
    trs.push(
      Math.max(
        highs[i] - lows[i],
        Math.abs(highs[i] - closes[i - 1]),
        Math.abs(lows[i] - closes[i - 1])
      )
    );
  }
  const atr14 = mean(trs.slice(-14));

  const bandPos50 = band50 > 0 ? (p - lo50) / band50 : 0.5;
  const distToHi50 = (hi50 - p) / Math.max(p, 1e-9);
  const distToLo50 = (p - lo50) / Math.max(p, 1e-9);

  const sma20 = m20,
    sma50 = m50;
  const dist20 = (p - sma20) / Math.max(p, 1e-9);
  const dist50 = (p - sma50) / Math.max(p, 1e-9);
  const crossState =
    (closes[closes.length - 2] - mean(closes.slice(-21, -1))) * (p - sma20) < 0
      ? 1
      : 0;

  const hi20 = Math.max(...closes.slice(-20)),
    lo20 = Math.min(...closes.slice(-20));
  const hi10 = Math.max(...closes.slice(-10)),
    lo10 = Math.min(...closes.slice(-10));
  const donchHi20 = hi20,
    donchLo20 = lo20;
  const donchBreakUp = p >= donchHi20 ? 1 : 0;
  const donchBreakDn = p <= donchLo20 ? 1 : 0;

  return {
    closes,
    highs,
    lows,
    opens,
    p,
    rets,
    body,
    slope20N,
    slope50N,
    slope20z,
    slope50z,
    r220,
    r250,
    sd20,
    sd50,
    bbWidth20,
    adx14,
    acRet,
    acSign,
    band50,
    rangeStd50,
    trendEff50,
    bodyMean,
    bodyAbsMean,
    dojiRate,
    atr14,
    bandPos50,
    distToHi50,
    distToLo50,
    sma20,
    sma50,
    dist20,
    dist50,
    crossState,
    hi20,
    lo20,
    hi10,
    lo10,
    donchHi20,
    donchLo20,
    donchBreakUp,
    donchBreakDn,
  };
}
/**
 * Compute a set of extremely simple binary features for a given strategy. These
 * features are intended for the lowest complexity levels (0 and 1). They
 * capture only very coarse conditions such as being near local support or
 * resistance or whether a trend is up or down. Adding more strategies here
 * will ensure every trading style has at least a couple of boolean features
 * available at low complexity.
 */
function simpleBinaryFeaturesForStrategy(
  b: ReturnType<typeof buildFeatureBank>,
  s: AnyStrat
): number[] {
  switch (s) {
    case CoreStrat.SR: {
      // Within 10% of the 50‑bar band extremes
      const pos = b.bandPos50;
      const nearSupport = pos < 0.1 ? 1 : 0;
      const nearResistance = pos > 0.9 ? 1 : 0;
      return [nearSupport, nearResistance];
    }
    case CoreStrat.TREND: {
      const up = b.slope50N > 0 ? 1 : 0;
      const down = b.slope50N < 0 ? 1 : 0;
      return [up, down];
    }
    case CoreStrat.MA: {
      const above = b.p > b.sma50 ? 1 : 0;
      const below = b.p < b.sma50 ? 1 : 0;
      return [above, below];
    }
    case CoreStrat.VOL: {
      const highVol = b.sd20 > b.sd50 ? 1 : 0;
      return [highVol];
    }
    case CoreStrat.MOM: {
      const sumRet = b.rets.reduce((a, c) => a + c, 0);
      const pos = sumRet > 0 ? 1 : 0;
      return [pos];
    }
    case CoreStrat.MR: {
      const belowMA = b.p < b.sma20 ? 1 : 0;
      return [belowMA];
    }
    case CoreStrat.BO: {
      return [b.donchBreakUp, b.donchBreakDn];
    }
    case CoreStrat.CANDLE: {
      const manyDoji = b.dojiRate > 0.2 ? 1 : 0;
      return [manyDoji];
    }
    case FullStrat.ICT: {
      const premium = b.bandPos50 > 0.5 ? 1 : 0;
      return [premium];
    }
    case FullStrat.SMC: {
      const premium = b.bandPos50 > 0.5 ? 1 : 0;
      return [premium];
    }
    case FullStrat.WYCKOFF: {
      const spring = b.p < b.lo20 ? 1 : 0;
      const upthrust = b.p > b.hi20 ? 1 : 0;
      return [spring, upthrust];
    }
    case FullStrat.RTM: {
      const compress = b.rangeStd50 < 1 ? 1 : 0;
      return [compress];
    }
    case FullStrat.TURTLE: {
      return [b.donchBreakUp, b.donchBreakDn];
    }
    case FullStrat.DONCHIAN: {
      return [b.donchBreakUp, b.donchBreakDn];
    }
    case FullStrat.MP: {
      const nearLo = b.bandPos50 < 0.2 ? 1 : 0;
      const nearHi = b.bandPos50 > 0.8 ? 1 : 0;
      return [nearLo, nearHi];
    }
    case FullStrat.VSA: {
      const manyDoji = b.dojiRate > 0.2 ? 1 : 0;
      return [manyDoji];
    }
    default:
      return [];
  }
}

/**
 * Compute the full (base) feature vector for a strategy. These features are
 * analogous to the original implementation and ordered from simpler to more
 * complex where possible. They are used when complexity levels are high.
 */
function baseFeaturesForStrategy(
  b: ReturnType<typeof buildFeatureBank>,
  s: AnyStrat
): number[] {
  switch (s) {
    case CoreStrat.SR:
      return [b.band50, b.rangeStd50, b.bandPos50, b.distToHi50, b.distToLo50];
    case CoreStrat.TREND:
      return [
        b.slope20N,
        b.slope50N,
        b.slope20z,
        b.slope50z,
        b.r220,
        b.r250,
        b.trendEff50,
      ];
    case CoreStrat.MA:
      return [b.dist20, b.dist50, b.crossState];
    case CoreStrat.VOL:
      return [b.sd20, b.sd50, b.bbWidth20, b.atr14];
    case CoreStrat.MOM:
      return [...b.rets, b.acRet, b.acSign];
    case CoreStrat.MR: {
      const z20 = b.sd20 > 0 ? (b.p - b.sma20) / b.sd20 : 0;
      const z50 = b.sd50 > 0 ? (b.p - b.sma50) / b.sd50 : 0;
      return [z20, z50, -Math.abs(z20), -Math.abs(z50)];
    }
    case CoreStrat.BO:
      return [b.adx14 / 100, b.donchBreakUp, b.donchBreakDn];
    case CoreStrat.CANDLE:
      return [b.bodyMean, b.bodyAbsMean, b.dojiRate, ...b.body];
    case FullStrat.ICT: {
      const swingAmp = b.hi20 - b.lo20;
      const upperSweep = b.p > b.hi10 ? 1 : 0;
      const lowerSweep = b.p < b.lo10 ? 1 : 0;
      const fvgProxy = Math.max(
        0,
        (b.opens[b.opens.length - 2] ?? b.p) -
          (b.lows[b.lows.length - 1] ?? b.p)
      );
      return [
        b.bandPos50,
        b.adx14,
        b.slope20z,
        b.slope50z,
        b.bbWidth20,
        b.acSign,
        b.acRet,
        swingAmp,
        upperSweep,
        lowerSweep,
        fvgProxy,
        b.dist20,
        b.dist50,
        b.rangeStd50,
        b.bodyMean,
        b.bodyAbsMean,
        b.dojiRate,
      ];
    }
    case FullStrat.SMC: {
      const isPremium = b.bandPos50 > 0.5 ? 1 : 0;
      const imbalance = Math.max(0, b.sd20 - b.sd50);
      return [
        b.slope20N,
        b.slope50N,
        b.trendEff50,
        b.adx14,
        b.bbWidth20,
        b.rangeStd50,
        isPremium,
        imbalance,
        b.distToHi50,
        b.distToLo50,
        b.donchBreakUp,
        b.donchBreakDn,
        ...b.rets,
        ...b.body,
      ];
    }
    case FullStrat.WYCKOFF: {
      const spring = b.p < b.lo20 ? 1 : 0;
      const upthrust = b.p > b.hi20 ? 1 : 0;
      return [
        spring,
        upthrust,
        b.acSign,
        b.acRet,
        b.slope50z,
        b.sd50,
        b.bbWidth20,
        b.bodyMean,
        b.bodyAbsMean,
        b.dojiRate,
        b.dist20,
        b.dist50,
      ];
    }
    case FullStrat.RTM: {
      const compress = b.sd20 / Math.max(b.sd50, 1e-9);
      return [
        compress,
        b.rangeStd50,
        b.trendEff50,
        b.bbWidth20,
        b.adx14,
        ...b.rets,
        ...b.body,
      ];
    }
    case FullStrat.TURTLE:
      return [
        b.donchBreakUp,
        b.donchBreakDn,
        b.slope50N,
        b.slope50z,
        b.adx14,
        b.dist50,
        b.rangeStd50,
      ];
    case FullStrat.DONCHIAN:
      return [
        b.donchHi20,
        b.donchLo20,
        b.donchBreakUp,
        b.donchBreakDn,
        b.rangeStd50,
        b.trendEff50,
        b.bbWidth20,
        b.adx14,
      ];
    case FullStrat.MP:
      return [
        b.bandPos50,
        b.distToHi50,
        b.distToLo50,
        b.bbWidth20,
        b.sd20,
        b.sd50,
        b.slope20z,
        b.slope50z,
        b.acSign,
        b.acRet,
      ];
    case FullStrat.VSA: {
      const spread20 = b.hi20 - b.lo20;
      return [
        spread20,
        b.bodyMean,
        b.bodyAbsMean,
        b.dojiRate,
        b.sd20,
        b.sd50,
        b.bbWidth20,
        b.adx14,
        b.acSign,
      ];
    }
    default:
      return [];
  }
}

/**
 * Combine simple and base features based on the current complexity. When
 * complexity is very low we return only the simple binary features. As
 * complexity increases we progressively include a larger fraction of the base
 * features and optionally additional non‑linear transforms (squares and
 * cross‑products) when complexity is very high.
 */
function featuresForStrategy(
  b: ReturnType<typeof buildFeatureBank>,
  s: AnyStrat,
  complexity: number
): number[] {
  const simple = simpleBinaryFeaturesForStrategy(b, s);
  const base = baseFeaturesForStrategy(b, s);
  // Normalize complexity into stages 0–10. For complexity <= 1, return only simple features
  if (complexity <= 1) {
    return simple;
  }
  // Determine how many base features to include. Use up to all features by
  // complexity >= 4. When complexity is 2–3 include 50–75% of base.
  const frac = Math.min(1, complexity / 4);
  const nBase = Math.max(1, Math.round(base.length * frac));
  const selected = base.slice(0, nBase);
  const result: number[] = [...simple, ...selected];
  // Add squared features for high complexity (>=7). Only square the first few
  // selected features to avoid exploding dimensionality.
  if (complexity >= 7) {
    const m = Math.min(selected.length, complexity - 6);
    for (let i = 0; i < m; i++) {
      result.push(selected[i] * selected[i]);
    }
  }
  // Add simple cross products for the highest complexity levels (>=9). Use
  // the first two features as an example of interaction terms.
  if (complexity >= 9) {
    const limit = Math.min(3, selected.length);
    for (let i = 0; i < limit; i++) {
      for (let j = i + 1; j < limit; j++) {
        result.push(selected[i] * selected[j]);
      }
    }
  }
  return result;
}

function featuresFromWindowWithStrategies(
  win: Bar[],
  strats: AnyStrat[],
  complexity: number
): number[] {
  const b = buildFeatureBank(win);
  const out: number[] = [];
  for (const s of strats) {
    const feats = featuresForStrategy(b, s, complexity);
    out.push(...feats);
  }
  return out;
}

/* ---- Feature sizes for estimating rounds ---- */
const FEATURE_SIZE: Record<AnyStrat, number> = {
  [CoreStrat.SR]: 5,
  [CoreStrat.TREND]: 7,
  [CoreStrat.MA]: 3,
  [CoreStrat.VOL]: 4,
  [CoreStrat.MOM]: 7,
  [CoreStrat.MR]: 4,
  [CoreStrat.BO]: 3,
  [CoreStrat.CANDLE]: 8,
  [FullStrat.ICT]: 17,
  [FullStrat.SMC]: 23,
  [FullStrat.WYCKOFF]: 12,
  [FullStrat.RTM]: 15,
  [FullStrat.TURTLE]: 7,
  [FullStrat.DONCHIAN]: 8,
  [FullStrat.MP]: 10,
  [FullStrat.VSA]: 9,
};

/* ===================== Arena Chart Theme (drop-in) ===================== */

const ARENA = {
  bgTop: "#000000",
  bgBot: "#020406",
  grid: "#0E1216",
  gridSoft: "#0A0E12",
  bull: "#00FF9D", // Arena Green
  bear: "#FF3B3B", // Arena Red
  wick: "#98A2B3",
  lastLine: "rgba(0,255,157,0.25)",
  lastDot: "#00FF9D",
};

/** Crisp device-pixel-ratio canvas */
function useCrispCanvas(
  ref: React.RefObject<HTMLCanvasElement>,
  width: number,
  height: number
) {
  React.useLayoutEffect(() => {
    const cvs = ref.current;
    if (!cvs) return;
    const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    cvs.width = Math.floor(width * dpr);
    cvs.height = Math.floor(height * dpr);
    cvs.style.width = width + "px";
    cvs.style.height = height + "px";
    const ctx = cvs.getContext("2d");
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }, [ref, width, height]);
}

//* ===================== Charts (original) ===================== */
function drawCandles(
  ctx: CanvasRenderingContext2D,
  data: Bar[],
  W: number,
  H: number
) {
  if (!data || data.length === 0) {
    ctx.clearRect(0, 0, W, H);
    return;
  }
  // clear to matte black
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);

  const hi = Math.max(...data.map((d) => d.high));
  const lo = Math.min(...data.map((d) => d.low));
  const pad = (hi - lo) * 0.05;
  const ymax = hi + pad,
    ymin = lo - pad;
  const y = (v: number) => H - ((v - ymin) / (ymax - ymin)) * H;

  const n = data.length;
  const cw = Math.max(3, Math.floor((W - 40) / n));
  for (let i = 0; i < n; i++) {
    const d = data[i];
    const x = 20 + i * cw + Math.floor(cw / 2);
    const up = d.close >= d.open;
    const color = up ? "#22c55e" : "#ef4444"; // straight green/red

    // wick
    ctx.strokeStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y(d.high));
    ctx.lineTo(x, y(d.low));
    ctx.stroke();

    // body
    const top = y(Math.max(d.open, d.close));
    const bot = y(Math.min(d.open, d.close));
    ctx.fillStyle = color;
    ctx.fillRect(
      x - Math.max(2, cw - 3) / 2,
      top,
      Math.max(2, cw - 3),
      Math.max(1, bot - top)
    );
  }
}
function SlidingCandleChart({
  prev,
  next,
  active,
  width = 1180,
  height = 500,
}: {
  prev: Bar[];
  next: Bar[];
  active: boolean;
  width?: number;
  height?: number;
}) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const cvs = ref.current;
    if (!cvs) return;
    const ctx = cvs.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    const D = 900; // smoother/longer
    const start = performance.now();
    const n = prev.length;
    const cw = Math.max(3, Math.floor((width - 40) / Math.max(n, 1)));
    const shiftPx = Math.max(1, n) * cw;

    const offPrev = document.createElement("canvas");
    offPrev.width = width;
    offPrev.height = height;
    const offCtxPrev = offPrev.getContext("2d")!;
    drawCandles(offCtxPrev, prev, width, height);

    const offNext = document.createElement("canvas");
    offNext.width = width;
    offNext.height = height;
    const offCtxNext = offNext.getContext("2d")!;
    drawCandles(offCtxNext, next, width, height);

    const easeInOutCubic = (t: number) =>
      t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

    function tick(now: number) {
      const t = clamp((now - start) / D, 0, 1);
      const ease = easeInOutCubic(t);

      ctx.clearRect(0, 0, width, height);
      // Matte black background
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, width, height);

      if (prev.length) {
        ctx.save();
        ctx.translate(-ease * shiftPx, 0);
        ctx.drawImage(offPrev, 0, 0);
        ctx.restore();
      }
      if (next.length) {
        ctx.save();
        ctx.translate(width - ease * shiftPx, 0);
        ctx.drawImage(offNext, 0, 0);
        ctx.restore();
      }

      if (t < 1 && active) raf = requestAnimationFrame(tick);
      else if (!active) {
        // draw static frame when not animating
        drawCandles(ctx, next.length ? next : prev, width, height);
      }
    }

    ctx.clearRect(0, 0, width, height);
    if (active) raf = requestAnimationFrame(tick);
    else drawCandles(ctx, next.length ? next : prev, width, height);

    return () => cancelAnimationFrame(raf);
  }, [prev, next, active, width, height]);

  return (
    <canvas
      ref={ref}
      width={width}
      height={height}
      style={{ display: "block", background: "#000", borderRadius: 14 }}
    />
  );
}

/* ===================== Twelve Data helpers (cache-first, missing only) ===================== */
type TDBar = {
  datetime: string;
  open: string;
  high: string;
  low: string;
  close: string;
};
function normalizeBarsDescToAsc(arr: TDBar[]): Bar[] {
  const asBars = arr
    .map((r) => ({
      time: r.datetime,
      open: +r.open,
      high: +r.high,
      low: +r.low,
      close: +r.close,
    }))
    .filter((b) => [b.open, b.high, b.low, b.close].every(Number.isFinite));
  return asBars.reverse();
}
async function fetchBatch(
  symbol: string,
  interval: string,
  key: string,
  endISO?: string,
  size = 5000
): Promise<Bar[]> {
  const mk = (p: [string, string][]) => {
    const url = new URL("https://api.twelvedata.com/time_series");
    for (const [k, v] of p) url.searchParams.set(k, v);
    return url.toString();
  };
  const base: [string, string][][] = [
    [
      ["symbol", symbol],
      ["interval", interval],
      ["outputsize", String(size)],
      ["apikey", key],
      ...(endISO ? [["end_date", endISO]] : []),
    ],
    [
      ["symbol", symbol],
      ["interval", interval],
      ["outputsize", String(size)],
      ["apikey", key],
      ...(endISO ? [["end_time", endISO]] : []),
    ],
  ];
  for (const params of base) {
    const res = await fetch(mk(params));
    const js = await res.json();
    if (js?.values?.length) return normalizeBarsDescToAsc(js.values as TDBar[]);
    if (js?.status === "error" && js?.message) throw new Error(js.message);
  }
  return [];
}
function cKey(symbol: string, interval: string) {
  return `cache_${symbol.replace(/[^A-Za-z0-9]/g, "_")}_${interval}`;
}
function loadCache(symbol: string, interval: string): Bar[] {
  try {
    const raw = localStorage.getItem(cKey(symbol, interval));
    if (!raw) return [];
    const obj = JSON.parse(raw);
    if (Array.isArray(obj?.bars)) {
      const bars = (obj.bars as Bar[]).filter((b) =>
        [b.open, b.high, b.low, b.close].every(Number.isFinite)
      );
      if (bars.length >= 2 && bars[0].time > bars[1].time)
        return bars.slice().reverse();
      return bars;
    }
  } catch {}
  return [];
}
function saveCacheAppendFront(
  symbol: string,
  interval: string,
  olderAsc: Bar[]
) {
  const cur = loadCache(symbol, interval);
  const merged = olderAsc.concat(cur);
  try {
    localStorage.setItem(
      cKey(symbol, interval),
      JSON.stringify({ updatedAt: Date.now(), bars: merged })
    );
  } catch {}
}
async function ensureMinBarsScaled({
  symbol,
  interval,
  requiredCount,
  keys,
  setStatus,
  setProgressTarget,
  perBatchDelayMs = 900,
  minDurationMs = 3500,
}: {
  symbol: string;
  interval: string;
  requiredCount: number;
  keys: string[];
  setStatus: (s: string) => void;
  setProgressTarget: (pct: number) => void;
  perBatchDelayMs?: number;
  minDurationMs?: number;
}): Promise<Bar[]> {
  // Helper to keep progress strictly tied to bars collected
  const progressFrom = (n: number) =>
    Math.min(100, Math.floor((n / Math.max(1, requiredCount)) * 100));

  let collected = loadCache(symbol, interval);

  // Initialize progress based on cache contents (accurate from the start)
  setStatus(
    collected.length
      ? `Found ${collected.length}/${requiredCount} in cache…`
      : `Checking cache…`
  );
  setProgressTarget(progressFrom(collected.length));

  // If cache already satisfies requirement, finish (keep accurate 100% only if satisfied)
  if (collected.length >= requiredCount) {
    setStatus(`Ready — using cached ${collected.length} bars`);
    setProgressTarget(100);
    await sleep(minDurationMs);
    return collected;
  }

  // Prepare backward (older) pagination anchor
  let endISO: string | undefined = undefined;
  if (collected.length) {
    const t = new Date(collected[0].time);
    t.setMinutes(t.getMinutes() - 1);
    endISO = t.toISOString();
  }

  let keyIdx = 0;
  let attempts = 0;
  const STEP = 5000;
  const startTotal = collected.length;
  const t0 = Date.now();

  while (collected.length < requiredCount && attempts < 60) {
    const key = keys[keyIdx % keys.length];
    const need = requiredCount - collected.length;
    const batchSize = Math.max(500, Math.min(STEP, need));

    setStatus(
      `Fetching… ${collected.length}/${requiredCount} (key ${
        (keyIdx % keys.length) + 1
      }/${keys.length})`
    );

    try {
      const batch = await fetchBatch(symbol, interval, key, endISO, batchSize);

      // Gentle throttle + jitter
      const jitter = 200 + Math.floor(Math.random() * 400);
      await sleep(perBatchDelayMs + jitter);

      if (!batch.length) break;

      if (collected.length === 0) {
        collected = batch;
      } else {
        const firstTime = collected[0].time;
        const olderOnly = batch.filter((b) => b.time < firstTime);
        if (olderOnly.length) {
          collected = olderOnly.concat(collected);
          saveCacheAppendFront(symbol, interval, olderOnly);
        }
      }

      // Move the end cursor older
      const oldest = collected[0]?.time;
      if (!oldest) break;
      const t = new Date(oldest);
      t.setMinutes(t.getMinutes() - 1);
      endISO = t.toISOString();

      // ⬇️ Progress is *exactly* based on bars collected vs requirement
      setProgressTarget(progressFrom(collected.length));
    } catch {
      // swallow and rotate key
    }

    keyIdx++;
    attempts++;
  }

  // Respect a minimum visible duration for the UX, but keep progress accurate
  const elapsed = Date.now() - t0;
  if (elapsed < minDurationMs) await sleep(minDurationMs - elapsed);

  if (collected.length > startTotal) {
    setStatus(
      `Ready — fetched ${collected.length - startTotal} more (total ${
        collected.length
      })`
    );
  } else {
    setStatus(`Ready — using cached ${collected.length} bars`);
  }

  // Final progress reflects true share; only 100% if requirement was met
  setProgressTarget(progressFrom(collected.length));
  return collected;
}

/* ===================== Loading Screen ===================== */
/* ===================== ARENA LOADING SCREEN ===================== */
function LoadingScreen({
  show,
  status,
  symbol,
  interval,
  progressSmoothed,
}: {
  show: boolean;
  status: string;
  symbol: string;
  interval: string;
  progressSmoothed: number | null;
}) {
  const clamp = (x: number, a: number, b: number) =>
    Math.max(a, Math.min(b, x));
  const fmt = (n: number) =>
    n.toLocaleString(undefined, { maximumFractionDigits: 0 });

  function parseCounts(s: string): { have: number; need: number } | null {
    const m = s?.match(/(\d[\d,\s]*)\s*\/\s*(\d[\d,\s]*)/);
    if (!m) return null;
    const clean = (t: string) => Number(t.replace(/[,\s]/g, ""));
    return { have: clean(m[1]), need: clean(m[2]) };
  }

  const counts = parseCounts(status);

  const [p, setP] = React.useState(0);
  const targetRef = React.useRef(0);
  const rafRef = React.useRef<number | null>(null);
  const lastTsRef = React.useRef<number | null>(null);

  const targetPct = React.useMemo(() => {
    if (counts && counts.need > 0)
      return clamp((counts.have / counts.need) * 100, 0, 100);
    return clamp(progressSmoothed ?? 0, 0, 100);
  }, [counts, progressSmoothed]);

  React.useEffect(() => {
    targetRef.current = targetPct;
  }, [targetPct]);

  React.useEffect(() => {
    if (!show) return;

    const loop = (ts: number) => {
      const last = lastTsRef.current ?? ts;
      const dt = (ts - last) / 1000;
      lastTsRef.current = ts;

      const target = targetRef.current;
      setP((cur) => {
        const delta = target - cur;
        const speed = clamp((3.8 * Math.abs(delta)) / 100 + 2.2, 2.0, 6.5);
        const next = cur + (1 - Math.exp(-speed * dt)) * delta;
        if (Math.abs(target - next) < 0.03 && target < 100) return next + 0.012;
        return next;
      });

      rafRef.current = requestAnimationFrame(loop);
    };

    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
      lastTsRef.current = null;
    };
  }, [show]);

  if (!show) return null;

  const display = counts
    ? `${fmt(counts.have)} / ${fmt(counts.need)}`
    : `${Math.round(targetPct)}%`;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 99999,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#000",
      }}
    >
      {/* Atmospheric Glow */}
      <div
        style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          pointerEvents: "none",
          background:
            "radial-gradient(900px 600px at 50% 40%, rgba(0,255,157,0.12), transparent 65%)",
          filter: "blur(6px)",
        }}
      />

      <div
        style={{
          width: "min(1120px, 97vw)",
          padding: 32,
          borderRadius: 18,
          border: "1px solid #161A1D",
          background: "rgba(0,0,0,0.74)",
          backdropFilter: "blur(8px)",
          boxShadow: "0 0 120px rgba(0,255,157,0.065)",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            gap: 16,
            alignItems: "center",
            marginBottom: 18,
          }}
        >
          <div
            style={{
              width: 62,
              height: 62,
              borderRadius: "50%",
              border: "4px solid #0E1215",
              borderTopColor: "#00FF9D",
              animation: "spin 1.1s cubic-bezier(.4,0,.2,1) infinite",
              filter: "drop-shadow(0 0 12px rgba(0,255,157,0.45))",
            }}
          />
          <div>
            <div style={{ fontSize: 26, fontWeight: 800, color: "#E9FFF5" }}>
              Loading Candlestick Data…
            </div>
            <div style={{ marginTop: 2, color: "#6D8278", fontSize: 15 }}>
              {symbol} • {interval}
            </div>
          </div>
        </div>

        {/* Counter */}
        <div
          style={{
            marginBottom: 10,
            fontSize: 15,
            fontWeight: 700,
            color: "#C9FFE6",
          }}
        >
          {display}
        </div>

        {/* Progress Bar */}
        <div
          style={{
            height: 30,
            borderRadius: 10,
            overflow: "hidden",
            background: "#030505",
            border: "1px solid #121616",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              transformOrigin: "left center",
              transform: `scaleX(${clamp(p, 0, 100) / 100})`,
              background: "#00FF9D",
              boxShadow: "0 0 22px rgba(0,255,157,0.65)",
              transition: "transform 0.12s linear",
            }}
          />
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}

/* ===================== Style-based suggestions ===================== */
function suggestFromStyles(selected: AnyStrat[]) {
  let lr = 0.25,
    wd = 0.0005,
    mu = 0.0,
    side = 0.05,
    scale = true,
    minSep = 500,
    win = 100,
    lrDecay = 0.0;

  const has = (x: AnyStrat[]) => x.some((s) => selected.includes(s));

  const trendish = has([
    CoreStrat.TREND,
    CoreStrat.MOM,
    FullStrat.TURTLE,
    FullStrat.DONCHIAN,
    CoreStrat.MA,
  ]);
  const meanrev = has([CoreStrat.MR, FullStrat.RTM]);
  const breakout = has([CoreStrat.BO, FullStrat.TURTLE, FullStrat.DONCHIAN]);
  const patterny = has([
    FullStrat.ICT,
    FullStrat.SMC,
    FullStrat.WYCKOFF,
    FullStrat.MP,
    FullStrat.VSA,
    CoreStrat.CANDLE,
  ]);
  const volatility = has([CoreStrat.VOL]);

  if (trendish) {
    mu += 0.35;
    side -= 0.02;
    win += 30;
    minSep += 300;
  }
  if (meanrev) {
    side += 0.05;
    mu += 0.05;
    lr += 0.05;
    win -= 20;
    minSep -= 200;
  }
  if (breakout) {
    mu += 0.15;
    side -= 0.01;
    win += 10;
  }
  if (patterny) {
    lr -= 0.05;
    mu += 0.1;
    side += 0.01;
    minSep += 200;
    win += 10;
  }
  if (volatility) {
    side += 0.03;
  }

  lr = clamp(+lr.toFixed(2), 0.05, 1.0);
  wd = clamp(+wd.toFixed(4), 0.0, 0.01);
  mu = clamp(+mu.toFixed(2), 0.0, 0.95);
  side = clamp(+side.toFixed(2), 0.0, 2.0);
  minSep = Math.max(0, Math.min(5000, Math.round(minSep)));
  win = clamp(Math.round(win), 50, 500);

  return {
    lr,
    wd,
    mu,
    sideMargin: side,
    scaleFeatures: scale,
    minWindowSep: minSep,
    windowLen: win,
    lrDecay,
  };
}

/* ===================== App ===================== */
export default function App() {
  const [status, setStatus] = useState<string>("Idle");
  const [loading, setLoading] = useState<boolean>(false);

  // Preserve the previous progress percentage to avoid the progress bar
  // briefly resetting to 0 while new candles are loading. This state holds
  // the last non‑zero pct value and is used when done resets to zero.
  const [prevPct, setPrevPct] = useState<number>(0);

  // Smooth progress
  const [progressTarget, setProgressTarget] = useState<number>(0);
  const [progressSmoothed, setProgressSmoothed] = useState<number>(0);
  useEffect(() => {
    let raf = 0;
    let active = true;
    function step() {
      setProgressSmoothed((p) => p + (progressTarget - p) * 0.12);
      if (active) raf = requestAnimationFrame(step);
    }
    raf = requestAnimationFrame(step);
    return () => {
      active = false;
      cancelAnimationFrame(raf);
    };
  }, []);
  useEffect(() => {
    if (!loading) {
      setProgressTarget(100);
      sleep(200);
      setLoading(false);
    }
  }, [loading]);

  // Flow
  const [step, setStep] = useState<
    "landing" | "picker" | "config" | "running" | "summary"
  >("landing");
  const [pickerPage, setPickerPage] = useState<0 | 1>(0);
  const [pageAnim, setPageAnim] = useState<"slide-left" | "slide-right">(
    "slide-right"
  );

  // Data selection
  const TD_KEYS = [
    "139626f1aaa3426a942e411734ecb8c2",
    "161b08145b264df9bcbf13aed829da19",
    "41e91a08c67c4c2c8a8570f17bb2d917",
    "c7987057e54e4c528a3a05feb9cff435",
  ];
  const INSTRUMENTS = [
    { label: "XAU/USD (Gold spot)", symbol: "XAU/USD" },
    { label: "EUR/USD", symbol: "EUR/USD" },
    { label: "BTC/USD", symbol: "BTC/USD" },
    { label: "SPY (S&P 500 ETF)", symbol: "SPY" },
  ];
  const TIMEFRAMES = [
    { label: "1min", v: "1min" },
    { label: "5min", v: "5min" },
    { label: "15min", v: "15min" },
    { label: "1h", v: "1h" },
    { label: "4h", v: "4h" },
  ];
  const [symbol, setSymbol] = useState<string>(INSTRUMENTS[0].symbol);
  const [interval, setIntervalStr] = useState<string>(TIMEFRAMES[2].v);

  // General settings
  const [windowLen, setWindowLen] = useState<number>(100);
  const [minWindowSep, setMinWindowSep] = useState<number>(500);

  // ML settings
  const [ml, setMl] = useState({
    lr: 0.25,
    wd: 0.0005,
    mu: 0.0,
    sideMargin: 0.05,
    scaleFeatures: true,
    lrDecay: 0.0,
  });
  const [suggestBanner, setSuggestBanner] = useState<string | null>(null);

  // Selected strategies + complexity (formerly aggression)
  const [selectedStrats, setSelectedStrats] = useState<AnyStrat[]>([]);
  // Complexity controls the richness of extracted features and scales total rounds.
  const [complexity, setComplexity] = useState<number>(5);

  // Ideal class distribution percentages (must sum to 100). Defaults to 40/40/20.
  const [idealDist, setIdealDist] = useState<{
    BULL: number;
    BEAR: number;
    SIDE: number;
  }>({ BULL: 40, BEAR: 40, SIDE: 20 });

  /**
   * Handle changes to the user‑editable ideal class distribution. When any
   * value is updated we automatically normalize the three values so that
   * their sum equals 100%. The normalization preserves relative weights
   * while rounding to integers and adjusting the final class to ensure
   * the total is exactly 100.
   */
  const handleIdealChange = (cls: ClassLabel, val: number) => {
    const raw = { ...idealDist, [cls]: Math.max(0, val) };
    const sum = raw.BULL + raw.BEAR + raw.SIDE;
    if (sum > 0) {
      const bullPct = Math.round((raw.BULL / sum) * 100);
      const bearPct = Math.round((raw.BEAR / sum) * 100);
      // assign remainder to SIDE to ensure sum = 100
      const sidePct = Math.max(0, 100 - bullPct - bearPct);
      setIdealDist({ BULL: bullPct, BEAR: bearPct, SIDE: sidePct });
    } else {
      setIdealDist(raw);
    }
  };

  // Estimate rounds
  const PER_FEATURE_LEARN = 20,
    PER_FEATURE_TEST = 10;
  const totalSelectedFeatures = selectedStrats.reduce(
    (sum, s) => sum + (FEATURE_SIZE[s] || 0),
    0
  );
  const estimatedTotalRoundsBase =
    totalSelectedFeatures * (PER_FEATURE_LEARN + PER_FEATURE_TEST);
  const estimatedTotalRounds = Math.max(
    0,
    Math.round(estimatedTotalRoundsBase * complexity)
  );

  // Runtime
  const [allBars, setAllBars] = useState<Bar[]>([]);
  const [model, setModel] = useState<OvR | null>(null);
  const [featureDim, setFeatureDim] = useState<number>(0);
  const [cursor, setCursor] = useState<number>(0);
  const [phase, setPhase] = useState<"learn" | "test" | "summary">("learn");
  const [learnQuota, setLearnQuota] = useState(0);
  const [testQuota, setTestQuota] = useState(0);
  const [learned, setLearned] = useState(0);
  const [tested, setTested] = useState(0);
  const [testLog, setTestLog] = useState<
    {
      pred: ClassLabel;
      user: ClassLabel;
      scores: { BULL: number; BEAR: number; SIDE: number };
    }[]
  >([]);
  const [pulse, setPulse] = useState<"green" | "red" | "gray" | null>(null);

  // Slide state
  const [prevWin, setPrevWin] = useState<Bar[]>([]);
  const [nextWin, setNextWin] = useState<Bar[]>([]);
  const [sliding, setSliding] = useState<boolean>(false);

  // ==================== Auto Mode State ====================
  // Controls automatic selection and speed.  autoSpeed of 0 means automation
  // is disabled.  Speeds 1, 2 and 3 correspond to 1×, 2× and 3× faster
  // progression through windows and UI delays.  The derived autoMode flag
  // simply checks whether autoSpeed is non‑zero.
  const [autoSpeed, setAutoSpeed] = useState<number>(0);
  // Derive whether automation is enabled based on autoSpeed
  const autoMode = autoSpeed > 0;
  // Holds the currently highlighted button during auto selection
  const [autoPressed, setAutoPressed] = useState<ClassLabel | null>(null);
  // Remembers the last cursor index that triggered an auto selection
  const [autoLastCursor, setAutoLastCursor] = useState<number>(-1);

  // Cycle through automation speeds (off/1×/2×/3×) when the AUTO button is pressed.
  // 0 disables automation, while 1–3 select the corresponding acceleration factor.
  const handleAutoClick = () => {
    // Cycle through OFF (0×) to 10×.  After reaching 10× the next click turns automation off.
    setAutoSpeed((prev) => {
      const next = (prev + 1) % 11;
      return next;
    });
  };

  // Track the last non‑zero progress percentage during the running phase. This
  // prevents the progress bar from flashing back to 0 when a new batch of
  // candles is loading (i.e., when `done` resets to 0). Whenever `done`
  // increases, update prevPct to the current progress. This effect is placed
  // after `step` and other related state declarations to ensure variables are
  // initialized before use.
  useEffect(() => {
    if (step === "running") {
      const total = learnQuota + testQuota;
      const done = learned + tested;
      if (done > 0) {
        const current = (100 * done) / (total || 1);
        setPrevPct(current);
      }
    }
  }, [step, learned, tested, learnQuota, testQuota]);

  const randCursor = (len: number, win: number, prev?: number) => {
    let c = Math.floor(Math.random() * (len - win)) + win;
    if (typeof prev === "number" && minWindowSep > 0) {
      let tries = 0;
      while (Math.abs(c - prev) < minWindowSep && tries < 20) {
        c = Math.floor(Math.random() * (len - win)) + win;
        tries++;
      }
    }
    return c;
  };
  const currentWindow = useMemo(
    () =>
      step !== "running" || !allBars.length
        ? []
        : allBars.slice(cursor - windowLen, cursor),
    [allBars, cursor, windowLen, step]
  );

  // ==================== Automatic Selection Logic ====================
  // When autoMode is enabled and a new window is ready, automatically decide whether
  // the price is likely Bullish, Bearish or Sideways. We compute the 5‑candle
  // high and low of the next five candles and compare them against the current
  // window’s range. If the future high exceeds the current high we select BULL;
  // if the future low drops below the current low we select BEAR; otherwise we
  // select SIDE. The selected button is filled to show the animation before
  // automatically submitting the choice.
  useEffect(() => {
    // Only run when automation is enabled (autoSpeed > 0)
    if (!autoMode) return;
    if (step !== "running" || phase === "summary") return;
    if (sliding) return;
    if (cursor === autoLastCursor) return;
    if (!currentWindow.length || cursor >= allBars.length) return;
    // Compute range of current window
    let currHigh = -Infinity;
    let currLow = Infinity;
    for (const bar of currentWindow) {
      if (bar.high > currHigh) currHigh = bar.high;
      if (bar.low < currLow) currLow = bar.low;
    }
    // Determine number of future bars to inspect: half of the example size
    const half = Math.max(1, Math.floor(windowLen / 2));
    const futureBars = allBars.slice(cursor, cursor + half);
    if (!futureBars.length) return;
    let futHigh = -Infinity;
    let futLow = Infinity;
    for (const bar of futureBars) {
      if (bar.high > futHigh) futHigh = bar.high;
      if (bar.low < futLow) futLow = bar.low;
    }
    // Define a threshold margin based on the current range. Using 2% of the range
    let choice: ClassLabel;
    if (futHigh > currHigh) {
      choice = "BULL";
    } else if (futLow < currLow) {
      choice = "BEAR";
    } else {
      // If neither breakout happens, force BULL or BEAR
      // Choose whichever moved more
      const upMove = futHigh - currHigh;
      const downMove = currLow - futLow;
      choice = upMove >= downMove ? "BULL" : "BEAR";
    }

    setAutoLastCursor(cursor);
    setAutoPressed(choice);
    // Speed up the delay between highlighting the button and committing the choice.
    // Divide the base 500ms delay by the current automation speed.
    const delay = 500 / autoSpeed;
    const timer = setTimeout(() => {
      handleChoice(choice);
      setAutoPressed(null);
    }, delay);
    return () => clearTimeout(timer);
  }, [
    autoMode,
    autoSpeed,
    step,
    phase,
    sliding,
    cursor,
    currentWindow,
    allBars,
    windowLen,
  ]);

  // ==================== Monte Carlo Balancing ====================
  // Continuously sample random windows during the running phase to estimate the
  // distribution of the model’s predictions. If the model predicts
  // significantly more BULL or BEAR, train a few additional examples of the
  // under‑represented class to encourage balanced predictions.
  useEffect(() => {
    if (!model || step !== "running") return;
    let cancelled = false;
    const runSim = async () => {
      while (!cancelled && step === "running") {
        let bull = 0;
        let bear = 0;
        let side = 0;
        const samples = 40;
        // Sample a batch of random windows and tally predictions for each class
        for (let i = 0; i < samples; i++) {
          const maxStart = Math.max(1, allBars.length - windowLen);
          const c = Math.floor(Math.random() * maxStart) + windowLen;
          const win = allBars.slice(c - windowLen, c);
          const feats = makeFeats(win);
          const pred = model.predict(feats);
          if (pred === "BULL") bull++;
          else if (pred === "BEAR") bear++;
          else side++;
        }
        // Convert counts to fractional distribution
        const dist = {
          BULL: bull / samples,
          BEAR: bear / samples,
          SIDE: side / samples,
        };
        // Normalize the user‑specified ideal distribution to fractions
        const ideal = {
          BULL: idealDist.BULL / 100,
          BEAR: idealDist.BEAR / 100,
          SIDE: idealDist.SIDE / 100,
        };
        // Determine which classes are active (non‑zero ideal percentage).  Classes with
        // zero ideal weight are ignored entirely in the balancing logic.  This
        // effectively removes them from the Monte Carlo simulation when the user
        // sets their percentage to 0%.
        const activeClasses = (["BULL", "BEAR", "SIDE"] as ClassLabel[]).filter(
          (c) => ideal[c] > 0
        );
        if (activeClasses.length > 0) {
          // Compute differences only for active classes
          const diffs: Record<ClassLabel, number> = {
            BULL: dist.BULL - ideal.BULL,
            BEAR: dist.BEAR - ideal.BEAR,
            SIDE: dist.SIDE - ideal.SIDE,
          };
          const activeAbsDiffs = activeClasses.map((c) => Math.abs(diffs[c]));
          const maxAbsDiff = Math.max(...activeAbsDiffs);
          const tolerance = 0.1; // tolerate up to ±10 percentage points difference
          if (maxAbsDiff > tolerance) {
            // Pick the most under‑represented active class relative to ideal
            let target: ClassLabel = activeClasses[0];
            let minRatio = Infinity;
            activeClasses.forEach((c) => {
              const idealVal = ideal[c] || 1e-9;
              const ratio = dist[c] / idealVal;
              if (ratio < minRatio) {
                minRatio = ratio;
                target = c;
              }
            });
            // Inject additional training examples for the under‑represented class
            const rebalanceBatch = 8;
            for (let j = 0; j < rebalanceBatch; j++) {
              const maxStart2 = Math.max(1, allBars.length - windowLen);
              const c2 = Math.floor(Math.random() * maxStart2) + windowLen;
              const win2 = allBars.slice(c2 - windowLen, c2);
              const feats2 = makeFeats(win2);
              model.train(feats2, target);
            }
          }
        }
        // Slow down or speed up the balancing cycle based on automation speed.
        await sleep(200 / Math.max(1, autoSpeed));
      }
    };
    runSim();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model, step, allBars, windowLen, idealDist, autoSpeed]);
  const advanceRandom = () =>
    setCursor(randCursor(allBars.length, windowLen, cursor));

  /* ===== Flow transitions ===== */
  const goPicker = () => setStep("picker");
  const goConfig = () => setStep("config");

  // Auto-apply suggestions when entering Preferences after choosing styles
  const stylesKey = JSON.stringify([...selectedStrats].sort());
  const [appliedKey, setAppliedKey] = useState<string>("");
  useEffect(() => {
    if (step !== "config") return;
    if (stylesKey === appliedKey) return;
    const sug = suggestFromStyles(selectedStrats);
    setMl((m) => ({
      ...m,
      lr: sug.lr,
      wd: sug.wd,
      mu: sug.mu,
      sideMargin: sug.sideMargin,
      scaleFeatures: sug.scaleFeatures,
      lrDecay: sug.lrDecay,
    }));
    setMinWindowSep(sug.minWindowSep);
    setWindowLen(sug.windowLen);
    setSuggestBanner(
      `Suggested defaults applied — LR ${sug.lr}, WD ${sug.wd}, Momentum ${sug.mu}, SIDE margin ${sug.sideMargin}, Min sep ${sug.minWindowSep}, Window ${sug.windowLen}, LR Decay ${sug.lrDecay}`
    );
    setAppliedKey(stylesKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, stylesKey]);
  /* ===== Begin assessment (show loading immediately) ===== */
  const beginAssessment = async () => {
    if (selectedStrats.length === 0) return;

    const L = Math.max(
      1,
      Math.round(PER_FEATURE_LEARN * totalSelectedFeatures * complexity)
    );
    const T = Math.max(
      1,
      Math.round(PER_FEATURE_TEST * totalSelectedFeatures * complexity)
    );
    setLearnQuota(L);
    setTestQuota(T);
    setLearned(0);
    setTested(0);
    setTestLog([]);

    const roundsFactor = Math.max(
      20,
      Math.floor(estimatedTotalRounds / 2) + 20
    );
    const diversityFactor =
      1 + Math.min(2, minWindowSep / Math.max(1, windowLen * 1.0));
    const required = clamp(
      Math.round(windowLen * roundsFactor * diversityFactor),
      windowLen * 40,
      100000
    );

    setLoading(true);
    setStatus("Checking cache…");
    setProgressTarget(5);

    try {
      const bars = await ensureMinBarsScaled({
        symbol,
        interval,
        requiredCount: required,
        keys: TD_KEYS,
        setStatus,
        setProgressTarget,
        // Scale throttling and minimum loading duration by automation speed.
        perBatchDelayMs: 1000 / Math.max(1, autoSpeed),
        minDurationMs: 3800 / Math.max(1, autoSpeed),
      });
      setAllBars(bars);

      const probe = bars.slice(-windowLen);
      const dim = featuresFromWindowWithStrategies(
        probe,
        selectedStrats,
        complexity
      ).length;
      setFeatureDim(dim);
      const m = new OvR(dim, ml.lr, ml.wd, ml.mu, ml.sideMargin, ml.lrDecay);
      setModel(m);

      const startCur = randCursor(bars.length, windowLen);
      setCursor(startCur);
      const w = bars.slice(startCur - windowLen, startCur);
      setPrevWin(w);
      setNextWin(w);

      setPhase("learn");
      setStep("running");
    } catch (e: any) {
      setStatus(`Error: ${e?.message || e}`);
    } finally {
      // Speed up the final loading fade by automation factor
      await sleep(400 / Math.max(1, autoSpeed));
      setLoading(false);
      setProgressTarget(0);
    }
  };

  const makeFeats = (win: Bar[]) => {
    // incorporate the current complexity level when extracting features
    let f = featuresFromWindowWithStrategies(win, selectedStrats, complexity);
    if (ml.scaleFeatures) f = l2norm(f);
    return f;
  };

  function handleChoice(choice: ClassLabel) {
    if (step !== "running" || !model || !currentWindow.length) return;
    const feats = makeFeats(currentWindow);

    if (choice === "BULL") setPulse("green");
    if (choice === "BEAR") setPulse("red");
    if (choice === "SIDE") setPulse("gray");
    // Reduce the pulse fade delay when automation speed is increased
    setTimeout(() => setPulse(null), 420 / Math.max(1, autoSpeed));

    const doSlideToNewWindow = () => {
      const nextC = randCursor(allBars.length, windowLen, cursor);
      const nw = allBars.slice(nextC - windowLen, nextC);
      setPrevWin(currentWindow);
      setNextWin(nw);
      setSliding(true);
      // Shorten the slide animation duration based on the automation speed.  When
      // autoSpeed is 2 or 3, the sliding completes proportionally faster.
      const slideTime = 920 / Math.max(1, autoSpeed);
      setTimeout(() => {
        setCursor(nextC);
        setSliding(false);
      }, slideTime);
    };

    if (phase === "learn") {
      model.train(feats, choice);
      setLearned((v) => v + 1);
      doSlideToNewWindow();
      if (learned + 1 >= learnQuota) setPhase("test");
    } else if (phase === "test") {
      const scores = model.rawScores(feats);
      const pred = model.predict(feats);
      setTestLog((log) => [...log, { pred, user: choice, scores }]);
      setTested((v) => v + 1);
      doSlideToNewWindow();
      if (tested + 1 >= testQuota) setStep("summary");
    }
  }

  // Summary metrics
  const summary = useMemo(() => {
    const cls: ClassLabel[] = ["BULL", "BEAR", "SIDE"];
    const idx: Record<ClassLabel, number> = { BULL: 0, BEAR: 1, SIDE: 2 };
    const N = testLog.length;
    const conf = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
    ];
    for (const r of testLog) conf[idx[r.user]][idx[r.pred]]++;
    const support = cls.map((_c, i) => conf[i][0] + conf[i][1] + conf[i][2]);
    const predCol = cls.map((_c, j) => conf[0][j] + conf[1][j] + conf[2][j]);
    const precision = cls.map((_c, j) => safeDiv(conf[j][j], predCol[j]));
    const recall = cls.map((_c, i) => safeDiv(conf[i][i], support[i]));
    const f1 = cls.map((_, i) => {
      const p = precision[i],
        r = recall[i];
      return p + r === 0 ? 0 : (2 * p * r) / (p + r);
    });
    const overallAcc = safeDiv(conf[0][0] + conf[1][1] + conf[2][2], N);
    const balancedAcc = mean(recall);
    const macroF1 = mean(f1);
    const weightedF1 = safeDiv(
      f1[0] * support[0] + f1[1] * support[1] + f1[2] * support[2],
      support[0] + support[1] + support[2]
    );
    const tpSum = conf[0][0] + conf[1][1] + conf[2][2];
    const fpSum =
      predCol[0] -
      conf[0][0] +
      (predCol[1] - conf[1][1]) +
      (predCol[2] - conf[2][2]);
    const fnSum =
      support[0] -
      conf[0][0] +
      (support[1] - conf[1][1]) +
      (support[2] - conf[2][2]);
    const microPrec = safeDiv(tpSum, tpSum + fpSum);
    const microRec = safeDiv(tpSum, tpSum + fnSum);
    const microF1 =
      microPrec + microRec === 0
        ? 0
        : (2 * microPrec * microRec) / (microPrec + microRec);

    const specificity = [0, 1, 2].map((k) => {
      const TP = conf[k][k],
        FN = support[k] - TP,
        FP = predCol[k] - TP,
        TN = N - TP - FN - FP;
      return safeDiv(TN, TN + FP);
    });
    const fpr = [0, 1, 2].map((k) => {
      const TP = conf[k][k],
        FN = support[k] - TP,
        FP = predCol[k] - TP,
        TN = N - TP - FN - FP;
      return safeDiv(FP, FP + TN);
    });
    const fnr = [0, 1, 2].map((k) => {
      const TP = conf[k][k],
        FN = support[k] - TP;
      return safeDiv(FN, TP + FN);
    });

    const userDist = { BULL: support[0], BEAR: support[1], SIDE: support[2] };
    const predDist = { BULL: predCol[0], BEAR: predCol[1], SIDE: predCol[2] };

    const userEntropy = entropyFromCounts([
      userDist.BULL,
      userDist.BEAR,
      userDist.SIDE,
    ]);
    const predEntropy = entropyFromCounts([
      predDist.BULL,
      predDist.BEAR,
      predDist.SIDE,
    ]);

    const margins = testLog.map((r) => {
      const arr = [r.scores.BULL, r.scores.BEAR, r.scores.SIDE].sort(
        (a, b) => b - a
      );
      return arr[0] - arr[1];
    });
    const avgMargin = mean(margins);
    const sdMargin = std(margins);

    // Agreement metrics
    const po = overallAcc;
    const pe = safeDiv(
      userDist.BULL * predDist.BULL +
        userDist.BEAR * predDist.BEAR +
        userDist.SIDE * predDist.SIDE,
      N * N || 1
    );
    const kappa = pe === 1 ? 0 : safeDiv(po - pe, 1 - pe);

    const c = 3;
    const sumTP = conf[0][0] + conf[1][1] + conf[2][2];
    const sumPiGi =
      userDist.BULL * predDist.BULL +
      userDist.BEAR * predDist.BEAR +
      userDist.SIDE * predDist.SIDE;
    const sumPi = userDist.BULL + userDist.BEAR + userDist.SIDE;
    const sumGi = predDist.BULL + predDist.BEAR + predDist.SIDE;
    const sumPi2 = userDist.BULL ** 2 + userDist.BEAR ** 2 + userDist.SIDE ** 2;
    const sumGi2 = predDist.BULL ** 2 + predDist.BEAR ** 2 + predDist.SIDE ** 2;
    const mccNum = c * sumTP - sumPiGi;
    const mccDen = Math.sqrt(
      Math.max((c * sumPi - sumPi2) * (c * sumGi - sumGi2), 1e-12)
    );
    const mcc = mccDen === 0 ? 0 : mccNum / mccDen;

    const trainedWell =
      overallAcc >= 0.62 &&
      balancedAcc >= 0.6 &&
      [userDist.BULL, userDist.BEAR, userDist.SIDE].filter((s) => s >= 10)
        .length >= 2 &&
      [0, 1, 2].filter((i) => (recall[i] || 0) >= 0.55).length >= 2;

    return {
      N,
      conf,
      support,
      predCol,
      precision,
      recall,
      f1,
      overallAcc,
      balancedAcc,
      macroF1,
      weightedF1,
      microPrec,
      microRec,
      microF1,
      specificity,
      fpr,
      fnr,
      userDist,
      predDist,
      userEntropy,
      predEntropy,
      avgMargin,
      sdMargin,
      kappa,
      mcc,
      trainedWell,
    };
  }, [testLog]);

  function continueMore() {
    setPhase("learn");
    const addBase =
      (PER_FEATURE_LEARN + PER_FEATURE_TEST) *
      selectedStrats.reduce((s, id) => s + (FEATURE_SIZE[id] || 0), 0);
    const add = Math.max(1, Math.round(addBase * complexity));
    const addLearn = Math.floor(
      add * (PER_FEATURE_LEARN / (PER_FEATURE_LEARN + PER_FEATURE_TEST))
    );
    const addTest = Math.ceil(
      add * (PER_FEATURE_TEST / (PER_FEATURE_LEARN + PER_FEATURE_TEST))
    );
    setLearnQuota((x) => x + addLearn);
    setTestQuota((x) => x + addTest);
    const nextC = randCursor(allBars.length, windowLen, cursor);
    setPrevWin(allBars.slice(cursor - windowLen, cursor));
    setNextWin(allBars.slice(nextC - windowLen, nextC));
    setSliding(true);
    setTimeout(() => {
      setCursor(nextC);
      setSliding(false);
    }, 920);
    setStep("running");
  }

  /* ---------- Backtest congruity: build & persist payloads ---------- */
  function buildModelSnapshot(): ModelSnapshot | null {
    if (!model) return null;
    const snapshot = model.toJSON(featureDim, ml.scaleFeatures);
    return {
      ...snapshot,
      meta: {
        createdAt: new Date().toISOString(),
        symbol,
        interval,
        windowLen,
        minWindowSep,
        strategies: selectedStrats,
        complexity,
        hparams: ml,
      },
    };
  }

  function purgeOtherModels() {
    try {
      const keep = new Set([SHARED_MODEL_KEY, BACKTEST_HANDOFF_KEY]);
      const toRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k) continue;
        const lower = k.toLowerCase();
        const isCache = k.startsWith("cache_"); // keep data caches
        const looksLikeModel =
          lower.includes("model") ||
          lower.includes("weights") ||
          lower.includes("snapshot");
        if (!isCache && looksLikeModel && !keep.has(k)) {
          toRemove.push(k);
        }
      }
      toRemove.forEach((k) => localStorage.removeItem(k));
    } catch {}
  }
  function persistBacktestHandoff(): void {
    const snap = buildModelSnapshot();
    if (!snap) return;

    const payload: BacktestHandoff = {
      version: "2025-11-08.iv1",
      savedAt: new Date().toISOString(),
      model: snap,
      data: {
        symbol,
        interval,
        windowLen,
        minWindowSep,
        strategies: selectedStrats.map(String),
        complexity,
        dataCacheKey: cKey(symbol, interval),
        barsCount: allBars.length || undefined,
      },
      metrics: {
        learned,
        tested,
        summary: {
          N: summary.N,
          overallAcc: summary.overallAcc,
          balancedAcc: summary.balancedAcc,
          macroF1: summary.macroF1,
        },
      },
    };

    // ⬇️ NEW: remove any older/other models before saving the new one
    purgeOtherModels();

    try {
      localStorage.setItem(SHARED_MODEL_KEY, JSON.stringify(snap));
      localStorage.setItem(BACKTEST_HANDOFF_KEY, JSON.stringify(payload));
    } catch (err) {
      try {
        const keep = new Set([SHARED_MODEL_KEY, BACKTEST_HANDOFF_KEY]);
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (!k) continue;
          if (!keep.has(k) && !k.startsWith("cache_")) {
            localStorage.removeItem(k);
          }
        }
        localStorage.setItem(SHARED_MODEL_KEY, JSON.stringify(snap));
        localStorage.setItem(BACKTEST_HANDOFF_KEY, JSON.stringify(payload));
      } catch {}
    }
  }

  function downloadModel() {
    const snap = buildModelSnapshot();
    if (!snap) return;
    const blob = new Blob([JSON.stringify(snap, null, 2)], {
      type: "application/json",
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "intuition-model.json";
    a.click();
  }

  /* ===================== Screens ===================== */
  /* ===================== Start Page ===================== */
  if (step === "landing") {
    const GREEN = "#00FF9D";

    return (
      <>
        <GlobalBlack />

        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "#000",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "0 24px",
          }}
        >
          {/* soft ambient glow */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              pointerEvents: "none",
              background:
                "radial-gradient(900px 520px at 50% 38%, rgba(0,255,157,0.13), transparent 65%)",
              filter: "blur(7px)",
            }}
          />

          <div style={{ textAlign: "center", maxWidth: 900, marginTop: 520 }}>
            {/* Title */}
            <div
              style={{
                fontSize: 48,
                lineHeight: 1.15,
                fontWeight: 800,
                color: "#F2FFF8",
                marginBottom: 34,
                // Bump the header downward so the start page isn’t pinned to the top of the viewport.
                // Previously this value was negative which pulled the layout up too far on tall screens.
                marginTop: 80,
              }}
            >
              Machine Learning
              <br />
              <span
                style={{
                  color: GREEN,
                  textShadow: "0 0 14px rgba(0,255,157,0.35)",
                }}
              >
                Learns Your Intuition
              </span>
            </div>

            {/* Start Button */}
            <button
              onClick={goPicker}
              style={{
                width: 500,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "16px 36px",
                fontSize: 20,
                fontWeight: 600,
                color: "#00140E",
                background: GREEN,
                border: "none",
                borderRadius: 10,
                cursor: "pointer",
                boxShadow: "0 0 24px rgba(0,255,157,0.35)",
                transition: "transform .12s ease, box-shadow .15s ease",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform =
                  "translateY(-1px) scale(1.02)";
                e.currentTarget.style.boxShadow =
                  "0 0 32px rgba(0,255,157,0.55)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow =
                  "0 0 24px rgba(0,255,157,0.35)";
              }}
            >
              Start
            </button>
          </div>
        </div>
      </>
    );
  }

  if (step === "picker") {
    const Icon = ({ name }: { name: AnyStrat }) => {
      const common = { width: 76, height: 76, viewBox: "0 0 64 64" } as any;
      const stroke = "#cbd5e1",
        fill = "#22c55e";
      const ArrowUp = ({ x = 50, y = 18 }) => (
        <polygon
          points={`${x},${y - 4} ${x + 8},${y} ${x},${y + 4}`}
          fill={fill}
        />
      );
      const ArrowDn = ({ x = 50, y = 46 }) => (
        <polygon
          points={`${x},${y - 4} ${x - 8},${y} ${x},${y + 4}`}
          fill="#ef4444"
        />
      );
      switch (name) {
        case CoreStrat.SR:
          return (
            <svg {...common}>
              <g stroke={stroke} strokeWidth="2" fill="none">
                <line x1="8" y1="18" x2="56" y2="18" />
                <line x1="8" y1="46" x2="56" y2="46" />
                <path d="M10 32 Q 22 24 30 30 T 54 34" />
              </g>
              <circle cx="42" cy="33" r="4" fill={fill} />
            </svg>
          );
        case CoreStrat.TREND:
          return (
            <svg {...common}>
              <g
                fill="none"
                stroke={stroke}
                strokeWidth="2"
                strokeLinecap="round"
              >
                <polyline points="10,46 22,38 30,40 38,30 50,22" />
                <polyline
                  points="12,52 24,44 32,46 40,36 52,28"
                  opacity="0.35"
                />
              </g>
              <polygon points="50,18 56,22 50,26" fill={fill} />
            </svg>
          );
        case CoreStrat.MA:
          return (
            <svg {...common}>
              <path
                d="M8 44 C 16 34, 26 30, 36 32 S 52 38, 56 20"
                stroke={stroke}
                strokeWidth="2"
                fill="none"
              />
              <path
                d="M8 40 C 20 26, 26 24, 42 26 S 52 30, 56 16"
                stroke={fill}
                strokeWidth="2"
                fill="none"
              />
            </svg>
          );
        case CoreStrat.VOL:
          return (
            <svg {...common}>
              <path
                d="M8 20 C 20 10, 44 10, 56 20"
                stroke={stroke}
                strokeWidth="2"
                fill="none"
              />
              <path
                d="M8 44 C 20 54, 44 54, 56 44"
                stroke={stroke}
                strokeWidth="2"
                fill="none"
              />
              <path
                d="M8 32 C 20 28, 44 28, 56 32"
                stroke={fill}
                strokeWidth="2"
                fill="none"
              />
            </svg>
          );
        case CoreStrat.MOM:
          return (
            <svg {...common}>
              <g stroke={stroke} strokeWidth="2" fill="none">
                <polyline points="8,46 20,34 28,38 36,26 50,30" />
              </g>
              <polygon points="50,26 58,30 50,34" fill={fill} />
            </svg>
          );
        case CoreStrat.MR:
          return (
            <svg {...common}>
              <g stroke={stroke} strokeWidth="2" fill="none">
                <line x1="8" y1="32" x2="56" y2="32" strokeDasharray="4 4" />
                <path d="M10 40 C 20 54, 46 10, 54 22" />
              </g>
              <circle cx="32" cy="32" r="4" fill={fill} />
            </svg>
          );
        case CoreStrat.BO:
          return (
            <svg {...common}>
              <rect
                x="10"
                y="20"
                width="28"
                height="18"
                rx="3"
                stroke={stroke}
                strokeWidth="2"
                fill="none"
              />
              <g strokeWidth="2" fill="none">
                <line x1="38" y1="26" x2="53" y2="18" stroke={fill} />
                <polygon points="53,14 60,18 53,22" fill={fill} />
              </g>
            </svg>
          );
        case CoreStrat.CANDLE:
          return (
            <svg {...common}>
              <g stroke={stroke} strokeWidth="2">
                <line x1="16" y1="14" x2="16" y2="50" />
                <rect x="12" y="28" width="8" height="12" fill={fill} />
                <line x1="32" y1="18" x2="32" y2="46" />
                <rect x="28" y="22" width="8" height="16" fill="#ef4444" />
                <line x1="48" y1="12" x2="48" y2="52" />
                <rect x="44" y="26" width="8" height="14" fill={fill} />
              </g>
            </svg>
          );
        case FullStrat.ICT:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <path d="M8 44 Q 20 22, 32 32 T 56 20" />
                <line x1="44" y1="20" x2="58" y2="20" stroke="#22c55e" />
                <rect
                  x="38"
                  y="26"
                  width="10"
                  height="8"
                  fill="#22c55e"
                  opacity="0.25"
                />
              </g>
            </svg>
          );
        case FullStrat.SMC:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <rect x="10" y="18" width="44" height="28" rx="4" />
                <path d="M16 32 L 28 26 L 36 34 L 48 28" stroke={fill} />
              </g>
            </svg>
          );
        case FullStrat.WYCKOFF:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <path d="M8 40 C 16 28, 20 28, 28 40" />
                <path d="M28 40 C 36 52, 40 52, 48 40" />
                <path d="M48 40 C 54 30, 58 30, 60 36" />
                <circle cx="28" cy="40" r="2" fill="#22c55e" />
              </g>
            </svg>
          );
        case FullStrat.RTM:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <path d="M8 24 C 24 20, 40 20, 56 24" />
                <path d="M8 40 C 24 44, 40 44, 56 40" />
                <path d="M8 32 C 24 30, 40 34, 56 32" stroke="#22c55e" />
              </g>
            </svg>
          );
        case FullStrat.TURTLE:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <path d="M10 22 H54" />
                <path d="M10 42 H54" />
                <path d="M10 22 Q 28 34, 54 22" stroke="#22c55e" />
              </g>
              <polygon points="50,14 57,18 50,22" fill="#22c55e" />
            </svg>
          );
        case FullStrat.DONCHIAN:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <rect x="12" y="20" width="40" height="24" rx="3" />
                <line x1="16" y1="44" x2="22" y2="36" stroke="#22c55e" />
                <line x1="46" y1="20" x2="52" y2="26" stroke="#ef4444" />
              </g>
            </svg>
          );
        case FullStrat.MP:
          return (
            <svg {...common}>
              <g fill="none" stroke={stroke} strokeWidth="2">
                <path d="M12 22 C 24 28, 40 28, 52 22" />
                <path d="M12 42 C 24 36, 40 36, 52 42" />
                <line x1="32" y1="18" x2="32" y2="46" stroke="#22c55e" />
              </g>
            </svg>
          );
        case FullStrat.VSA:
          return (
            <svg {...common}>
              <g stroke={stroke} strokeWidth="2" fill="none">
                <rect x="14" y="24" width="10" height="16" fill="#22c55e" />
                <rect x="30" y="22" width="6" height="20" fill="#ef4444" />
                <rect x="40" y="28" width="4" height="10" />
              </g>
              <polygon points="44,42 52,46 44,50" fill="#ef4444" />
            </svg>
          );
      }
    };
    const toggle = (id: AnyStrat) =>
      setSelectedStrats((cur) =>
        cur.includes(id) ? cur.filter((s) => s !== id) : [...cur, id]
      );
    const page0 = (
      <div className="grid grid-4">
        {CORE.map((id) => {
          const active = selectedStrats.includes(id);
          return (
            <div
              key={id}
              className={`card ${active ? "active" : ""}`}
              onClick={() => toggle(id)}
              style={{ position: "relative" }}
            >
              {active && (
                <div className="sel-indicator">
                  <div className="sel-dot" />
                </div>
              )}
              <div className="icon-wrap">
                <Icon name={id} />
              </div>
              <h3>{id}</h3>
            </div>
          );
        })}
      </div>
    );
    const page1 = (
      <div className="grid grid-4">
        {FULL.map((id) => {
          const active = selectedStrats.includes(id);
          return (
            <div
              key={id}
              className={`card ${active ? "active" : ""}`}
              onClick={() => toggle(id)}
              style={{ position: "relative" }}
            >
              {active && (
                <div className="sel-indicator">
                  <div className="sel-dot" />
                </div>
              )}
              <div className="icon-wrap">
                <Icon name={id} />
              </div>
              <h3>{id}</h3>
            </div>
          );
        })}
      </div>
    );
    const goRight = () => {
      if (pickerPage === 0) {
        setPickerPage(1);
        setPageAnim("slide-right");
      }
    };
    const goLeft = () => {
      if (pickerPage === 1) {
        setPickerPage(0);
        setPageAnim("slide-left");
      }
    };

    return (
      <>
        <GlobalBlack />
        <div
          className="container"
          style={{
            minHeight: "100vh",
            padding: 24,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 18,
          }}
        >
          <div style={{ fontSize: 32, fontWeight: 700, textAlign: "center" }}>
            What’s Your Style
          </div>
          <div
            className="page-wrap"
            style={{ marginTop: 6, position: "relative" }}
          >
            {pickerPage === 0 && (
              <div
                className={`page ${pageAnim}`}
                style={{ position: "relative" }}
              >
                {page0}
                <button
                  className="pager-btn pager-right"
                  onClick={goRight}
                  aria-label="Next"
                >
                  {">"}
                </button>
              </div>
            )}
            {pickerPage === 1 && (
              <div
                className={`page ${pageAnim}`}
                style={{ position: "relative" }}
              >
                {page1}
                <button
                  className="pager-btn pager-left"
                  onClick={goLeft}
                  aria-label="Back"
                >
                  {"<"}
                </button>
              </div>
            )}
          </div>
          <div className="container" style={{ marginTop: 14 }}>
            <div className="settings-row" style={{ alignItems: "center" }}>
              <div style={{ color: "#9ca3af", justifySelf: "end" }}>
                Complexity
              </div>
              <input
                className="slider"
                type="range"
                min={0}
                max={10}
                step={1}
                value={complexity}
                onChange={(e) => setComplexity(Number(e.target.value))}
                onMouseDown={(e) => e.stopPropagation()}
              />
              <div style={{ color: "#e5e7eb", fontWeight: 700 }}>
                {complexity}
              </div>
            </div>
          </div>
          <div style={{ color: "#9ca3af", marginTop: 4, textAlign: "center" }}>
            Estimated rounds:{" "}
            <span style={{ color: "#e5e7eb" }}>{estimatedTotalRounds}</span>
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              width: "100%",
              marginTop: 8,
            }}
          >
            <button
              className="btn btn-green"
              onClick={goConfig}
              disabled={selectedStrats.length === 0}
              style={{
                opacity: selectedStrats.length === 0 ? 0.5 : 1,
                minWidth: 280,
                fontSize: 18,
              }}
            >
              Continue to Preferences
            </button>
          </div>
        </div>
      </>
    );
  }

  if (step === "config") {
    const Tip = ({ text }: { text: string }) => (
      <span className="tip" style={{ marginLeft: 8 }}>
        <span className="tip-badge">?</span>
        <span className="tip-text">{text}</span>
      </span>
    );
    const LabeledSlider = ({
      label,
      value,
      min,
      max,
      step,
      onChange,
      tooltip,
    }: {
      label: string;
      value: number;
      min: number;
      max: number;
      step: number;
      onChange: (v: number) => void;
      tooltip: string;
    }) => (
      <div
        className="pill"
        onMouseDown={(e) => e.stopPropagation()}
        style={{ width: "100%" }}
      >
        <div
          style={{
            minWidth: 180,
            color: "#9ca3af",
            fontSize: 13,
            paddingLeft: 6,
            display: "flex",
            alignItems: "center",
          }}
        >
          {label}
          <Tip text={tooltip} />
        </div>
        <div
          style={{ flex: 1, display: "flex", alignItems: "center", gap: 12 }}
        >
          <input
            className="slider"
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(e) => onChange(Number(e.target.value))}
            onMouseDown={(e) => e.stopPropagation()}
          />
          <div
            style={{
              width: 90,
              textAlign: "right",
              color: "#e5e7eb",
              fontWeight: 700,
            }}
          >
            {value}
          </div>
        </div>
      </div>
    );
    const Toggle = ({
      label,
      checked,
      onChange,
      tooltip,
    }: {
      label: string;
      checked: boolean;
      onChange: (v: boolean) => void;
      tooltip: string;
    }) => (
      <div className="pill" style={{ width: "100%" }}>
        <div
          style={{
            minWidth: 180,
            color: "#9ca3af",
            fontSize: 13,
            paddingLeft: 6,
            display: "flex",
            alignItems: "center",
          }}
        >
          {label}
          <Tip text={tooltip} />
        </div>
        <div
          style={{
            flex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
          }}
        >
          <div
            onClick={() => onChange(!checked)}
            style={{
              width: 64,
              height: 32,
              borderRadius: 999,
              background: checked ? "#22c55e" : "#1f2937",
              border: "1px solid #334155",
              position: "relative",
              cursor: "pointer",
            }}
          >
            <div
              style={{
                position: "absolute",
                top: 2,
                left: checked ? 32 : 2,
                width: 28,
                height: 28,
                borderRadius: 999,
                background: "#0b0b0b",
                border: "1px solid #111827",
                boxShadow: "0 2px 8px rgba(0,0,0,.35)",
                transition: "left .15s ease",
              }}
            />
          </div>
        </div>
      </div>
    );

    return (
      <>
        <GlobalBlack />
        <LoadingScreen
          show={loading}
          status={status}
          symbol={symbol}
          interval={interval}
          progressSmoothed={progressSmoothed}
        />
        <div
          className="container"
          style={{
            minHeight: "100vh",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 18,
            padding: 24,
          }}
        >
          <div
            style={{
              fontSize: 28,
              fontWeight: 700,
              marginBottom: 6,
              textAlign: "center",
            }}
          >
            Preferences
          </div>

          {/* Suggested banner removed per requirements */}

          {/* ===== General Settings ===== */}
          {/* Wrap both rows in a single grid container so that all six "pill" boxes share the same width.  */}
          <div
            style={{
              width: "100%",
              marginTop: 10,
              color: "#e5e7eb",
              fontWeight: 700,
              fontSize: 16,
              textAlign: "center",
            }}
          >
            General Settings
          </div>
          {/* Combined grid for both general settings and class representation to ensure uniform widths and centering. */}
          <div
            className="settings-grid"
            style={{
              gridTemplateColumns: "repeat(3, 1fr)",
              width: "100%",
              maxWidth: "900px",
              margin: "0 auto",
              justifyItems: "center",
              gap: 16,
            }}
          >
            {/* Instrument select */}
            <div className="pill" style={{ width: "100%" }}>
              <div
                style={{
                  minWidth: 150,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                }}
              >
                Instrument
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                <select
                  className="pill-select"
                  style={{ maxWidth: 200 }}
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                >
                  {INSTRUMENTS.map((o) => (
                    <option key={o.symbol} value={o.symbol}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            {/* Timeframe select */}
            <div className="pill" style={{ width: "100%" }}>
              <div
                style={{
                  minWidth: 150,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                }}
              >
                Timeframe
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                <select
                  className="pill-select"
                  value={interval}
                  onChange={(e) => setIntervalStr(e.target.value)}
                >
                  {TIMEFRAMES.map((o) => (
                    <option key={o.v} value={o.v}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            {/* Candles slider */}
            <div
              className="pill"
              onMouseDown={(e) => e.stopPropagation()}
              style={{ width: "100%" }}
            >
              <div
                style={{
                  minWidth: 180,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                  display: "flex",
                  alignItems: "center",
                }}
              >
                Candles / example
                <span className="tip" style={{ marginLeft: 8 }}>
                  <span className="tip-badge">?</span>
                  <span className="tip-text">
                    Bars per window shown to you and the model.
                  </span>
                </span>
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                }}
              >
                <input
                  className="slider"
                  type="range"
                  min={50}
                  max={500}
                  step={5}
                  value={windowLen}
                  onChange={(e) =>
                    setWindowLen(Math.round(Number(e.target.value)))
                  }
                />
                <div
                  style={{
                    width: 90,
                    textAlign: "right",
                    color: "#e5e7eb",
                    fontWeight: 700,
                  }}
                >
                  {windowLen}
                </div>
              </div>
            </div>

            {/* Section title for class representation.  This spans all 3 columns to center the text across the row. */}
            <div
              style={{
                width: "100%",
                marginTop: 16,
                color: "#e5e7eb",
                fontWeight: 700,
                fontSize: 16,
                textAlign: "center",
                gridColumn: "1 / -1",
              }}
            >
              Class Representation (%)
            </div>
            {/* Bull class input */}
            <div className="pill" style={{ width: "100%" }}>
              <div
                style={{
                  minWidth: 150,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                }}
              >
                Bull Class (%)
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                <input
                  className="pill-input"
                  type="number"
                  min={0}
                  max={100}
                  value={idealDist.BULL}
                  onChange={(e) =>
                    handleIdealChange("BULL", Number(e.target.value))
                  }
                />
              </div>
            </div>
            {/* Bear class input */}
            <div className="pill" style={{ width: "100%" }}>
              <div
                style={{
                  minWidth: 150,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                }}
              >
                Bear Class (%)
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                <input
                  className="pill-input"
                  type="number"
                  min={0}
                  max={100}
                  value={idealDist.BEAR}
                  onChange={(e) =>
                    handleIdealChange("BEAR", Number(e.target.value))
                  }
                />
              </div>
            </div>
            {/* Side class input */}
            <div className="pill" style={{ width: "100%" }}>
              <div
                style={{
                  minWidth: 150,
                  color: "#9ca3af",
                  fontSize: 12,
                  paddingLeft: 6,
                }}
              >
                Side Class (%)
              </div>
              <div
                style={{
                  flex: 1,
                  display: "flex",
                  justifyContent: "flex-start",
                }}
              >
                <input
                  className="pill-input"
                  type="number"
                  min={0}
                  max={100}
                  value={idealDist.SIDE}
                  onChange={(e) =>
                    handleIdealChange("SIDE", Number(e.target.value))
                  }
                />
              </div>
            </div>
          </div>

          {/* Machine Learning Settings removed per requirements */}

          <div
            className="container"
            style={{ display: "flex", justifyContent: "center", marginTop: 14 }}
          >
            <button
              className="btn btn-green"
              style={{ fontSize: 18, minWidth: 280 }}
              onClick={beginAssessment}
            >
              Begin Assessment
            </button>
          </div>
        </div>
      </>
    );
  }

  if (step === "running") {
    const total = learnQuota + testQuota;
    const done = learned + tested;
    const pctCurrent = (100 * done) / (total || 1);
    const pctDisplay = done > 0 ? pctCurrent : prevPct;
    const hasWindows = prevWin.length && nextWin.length;
    return (
      <>
        <GlobalBlack />
        <div
          className="container"
          style={{
            minHeight: "100vh",
            color: "#fff",
            padding: 24,
            display: "flex",
            flexDirection: "column",
            gap: 14,
          }}
        >
          <LoadingScreen
            show={loading}
            status={status}
            symbol={symbol}
            interval={interval}
            progressSmoothed={progressSmoothed}
          />
          {/* Progress summary and auto switch on the same row */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
              marginTop: 4,
            }}
          >
            <div style={{ color: "#9ca3af", fontSize: 14 }}>
              {done} / {total} ({pctCurrent.toFixed(0)}%) •{" "}
              <span style={{ color: "#cbd5e1" }}>
                {selectedStrats.length} style
                {selectedStrats.length === 1 ? "" : "s"} • {symbol} • {interval}{" "}
                • {windowLen} bars • complexity {complexity}
              </span>
            </div>
            <button
              className={`btn ${autoMode ? "btn-green" : "btn-gray"}`}
              style={{ padding: "6px 16px", fontSize: 14 }}
              onClick={handleAutoClick}
            >
              {autoSpeed > 0 ? `AUTO ${autoSpeed}x` : "AUTO OFF"}
            </button>
          </div>
          {/* Progress bar */}
          <div className="pb" style={{ marginTop: 6 }}>
            <div className="pb-fill" style={{ width: `${pctDisplay}%` }} />
          </div>

          {/* Chart frame: clean closed border on all sides */}
          <div
            style={{
              position: "relative",
              border: "2px solid #2b2b2b",
              borderRadius: 14,
              overflow: "hidden",
              background: "#000",
            }}
          >
            <div style={{ padding: 14 }}>
              {hasWindows ? (
                <SlidingCandleChart
                  prev={prevWin}
                  next={nextWin}
                  active={sliding}
                  width={1180}
                  height={500}
                />
              ) : (
                <div style={{ height: 500 }} />
              )}
              {pulse === "green" && <div className="pulse-green" />}
              {pulse === "red" && <div className="pulse-red" />}
              {pulse === "gray" && <div className="pulse-gray" />}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              gap: 16,
            }}
          >
            <button
              className="btn btn-green btn-wide"
              style={{
                background: autoPressed === "BULL" ? "#22c55e" : "transparent",
                color: autoPressed === "BULL" ? "#0a0a0a" : undefined,
                boxShadow:
                  autoPressed === "BULL"
                    ? "0 0 20px rgba(34,197,94,.3)"
                    : undefined,
                transform: autoPressed === "BULL" ? "scale(1.05)" : undefined,
                transition:
                  "transform 0.25s ease, background 0.25s ease, color 0.25s ease",
              }}
              onClick={() => handleChoice("BULL")}
            >
              Bullish
            </button>
            <button
              className="btn btn-red btn-wide"
              style={{
                background: autoPressed === "BEAR" ? "#ef4444" : "transparent",
                color: autoPressed === "BEAR" ? "#0a0a0a" : undefined,
                boxShadow:
                  autoPressed === "BEAR"
                    ? "0 0 20px rgba(239,68,68,.3)"
                    : undefined,
                transform: autoPressed === "BEAR" ? "scale(1.05)" : undefined,
                transition:
                  "transform 0.25s ease, background 0.25s ease, color 0.25s ease",
              }}
              onClick={() => handleChoice("BEAR")}
            >
              Bearish
            </button>
          </div>
          <div>
            <button
              className="btn btn-gray btn-full"
              style={{
                background: autoPressed === "SIDE" ? "#9ca3af" : "transparent",
                color: autoPressed === "SIDE" ? "#0a0a0a" : undefined,
                boxShadow:
                  autoPressed === "SIDE"
                    ? "0 0 20px rgba(156,163,175,.3)"
                    : undefined,
                transform: autoPressed === "SIDE" ? "scale(1.05)" : undefined,
                transition:
                  "transform 0.25s ease, background 0.25s ease, color 0.25s ease",
              }}
              onClick={() => handleChoice("SIDE")}
            >
              Sideways
            </button>
          </div>

          {phase === "learn" ? (
            <div style={{ textAlign: "center", color: "#9ca3af" }}>
              Learning your intuition…
            </div>
          ) : phase === "test" ? (
            <div style={{ textAlign: "center", color: "#9ca3af" }}>
              Testing (no learning)…
            </div>
          ) : null}
        </div>
      </>
    );
  }

  /* ===================== Summary with green/red glow ===================== */
  const s = summary;
  const isGood = s.trainedWell;
  const recColor = isGood ? "#22c55e" : "#ef4444";
  const recHeadline = isGood
    ? "Backtest is recommended."
    : "Backtest is not recommended right now.";
  const recBody = isGood
    ? "Your metrics suggest solid alignment — proceed to backtest."
    : "Metrics aren’t fully aligned yet — do more rounds to strengthen the model before backtesting.";
  const avgSpec = (s.specificity.reduce((a, b) => a + b, 0) / 3) * 100;
  const avgFpr = (s.fpr.reduce((a, b) => a + b, 0) / 3) * 100;
  const avgFnr = (s.fnr.reduce((a, b) => a + b, 0) / 3) * 100;

  const glow = (ok: boolean, bad: boolean = false) =>
    ok ? "green" : bad ? "red" : null;
  const goodAcc = s.overallAcc >= 0.62,
    badAcc = s.overallAcc <= 0.5;
  const goodBal = s.balancedAcc >= 0.6,
    badBal = s.balancedAcc <= 0.48;
  const goodMacro = s.macroF1 >= 0.6,
    badMacro = s.macroF1 <= 0.48;
  const goodWeighted = s.weightedF1 >= 0.6,
    badWeighted = s.weightedF1 <= 0.48;
  const goodMicroF1 = s.microF1 >= 0.6,
    badMicroF1 = s.microF1 <= 0.48;
  const goodKappa = s.kappa >= 0.2,
    badKappa = s.kappa <= 0.05;
  const goodMCC = s.mcc >= 0.2,
    badMCC = s.mcc <= 0.05;
  const goodSpec = avgSpec >= 60,
    badSpec = avgSpec <= 45;
  const goodFpr = avgFpr <= 20,
    badFpr = avgFpr >= 35;
  const goodFnr = avgFnr <= 20,
    badFnr = avgFnr >= 35;

  const glowStyle = (color: "green" | "red" | null) =>
    color
      ? {
          boxShadow:
            color === "green"
              ? "0 0 24px rgba(34,197,94,.22), inset 0 0 14px rgba(34,197,94,.12)"
              : "0 0 24px rgba(239,68,68,.22), inset 0 0 14px rgba(239,68,68,.12)",
          borderColor: color === "green" ? "#14532d" : "#7f1d1d",
        }
      : {};

  return (
    <>
      <GlobalBlack />
      <div
        className="container"
        style={{
          minHeight: "100vh",
          color: "#fff",
          padding: 24,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 20,
        }}
      >
        <div className="banner">
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 12,
              flexWrap: "wrap",
            }}
          >
            <div style={{ fontSize: 32, fontWeight: 800 }}>Summary</div>
            <div
              className="badge"
              style={{
                color: recColor,
                borderColor: recColor === "#22c55e" ? "#14532d" : "#7f1d1d",
              }}
            >
              <span
                style={{
                  width: 10,
                  height: 10,
                  borderRadius: 999,
                  background: recColor,
                  boxShadow: `0 0 10px ${recColor}66`,
                }}
              />
              {isGood ? "Ready to Backtest" : "Needs More Training"}
            </div>
          </div>
          <div style={{ marginTop: 8, color: recColor, fontWeight: 700 }}>
            {recHeadline}
          </div>
          <div style={{ marginTop: 4, color: "#cbd5e1" }}>{recBody}</div>
        </div>

        {/* KPI rows with glow */}
        <div className="stat-grid" style={{ marginTop: 10 }}>
          <Stat label="Eval Samples" value={String(s.N)} />
          <Stat
            label="Accuracy"
            value={`${Math.round(s.overallAcc * 100)}%`}
            styleExtra={glowStyle(glow(goodAcc, badAcc))}
          />
          <Stat
            label="Balanced Acc"
            value={`${Math.round(s.balancedAcc * 100)}%`}
            styleExtra={glowStyle(glow(goodBal, badBal))}
          />
          <Stat
            label="Macro F1"
            value={`${(s.macroF1 * 100).toFixed(1)}%`}
            styleExtra={glowStyle(glow(goodMacro, badMacro))}
          />
        </div>
        <div className="stat-grid">
          <Stat
            label="Weighted F1"
            value={`${(s.weightedF1 * 100).toFixed(1)}%`}
            styleExtra={glowStyle(glow(goodWeighted, badWeighted))}
          />
          <Stat
            label="Micro P/R/F1"
            value={`${(s.microPrec * 100).toFixed(0)} / ${(
              s.microRec * 100
            ).toFixed(0)} / ${(s.microF1 * 100).toFixed(0)}%`}
            styleExtra={glowStyle(glow(goodMicroF1, badMicroF1))}
          />
          <Stat
            label="Cohen's κ"
            value={`${s.kappa.toFixed(3)}`}
            styleExtra={glowStyle(glow(goodKappa, badKappa))}
          />
          <Stat
            label="Matthews CC"
            value={`${s.mcc.toFixed(3)}`}
            styleExtra={glowStyle(glow(goodMCC, badMCC))}
          />
        </div>
        <div className="stat-grid">
          <Stat
            label="Pred Dist (Bull/Bear/Side)"
            value={`${s.predDist.BULL} / ${s.predDist.BEAR} / ${s.predDist.SIDE}`}
          />
          <Stat
            label="Your Dist (Bull/Bear/Side)"
            value={`${s.userDist.BULL} / ${s.userDist.BEAR} / ${s.userDist.SIDE}`}
          />
          <Stat
            label="Entropy (pred/user)"
            value={`${s.predEntropy.toFixed(2)} / ${s.userEntropy.toFixed(2)}`}
          />
          <Stat label="Avg Margin" value={`${s.avgMargin.toFixed(3)}`} />
        </div>
        <div className="stat-grid">
          <Stat
            label="Avg Specificity"
            value={`${(
              (s.specificity.reduce((a, b) => a + b, 0) / 3) *
              100
            ).toFixed(1)}%`}
          />
          <Stat
            label="Avg FPR"
            value={`${((s.fpr.reduce((a, b) => a + b, 0) / 3) * 100).toFixed(
              1
            )}%`}
          />
          <Stat
            label="Avg FNR"
            value={`${((s.fnr.reduce((a, b) => a + b, 0) / 3) * 100).toFixed(
              1
            )}%`}
          />
          <Stat label="Margin SD" value={`${s.sdMargin.toFixed(3)}`} />
        </div>

        {/* Confusion Matrix */}
        <section style={{ width: "100%", marginTop: 8 }}>
          <div style={{ fontSize: 20, margin: "8px 0 10px 0" }}>
            Confusion Matrix (Rows: You, Cols: Model)
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "180px 1fr 1fr 1fr",
              border: "1px solid #2a2a2a",
              borderRadius: 12,
              overflow: "hidden",
            }}
          >
            <Cell header />
            <Cell header center>
              Model: Bull
            </Cell>
            <Cell header center>
              Model: Bear
            </Cell>
            <Cell header center>
              Model: Side
            </Cell>
            <Cell header>You: Bull</Cell>
            <Cell center>{s.conf[0][0]}</Cell>
            <Cell center>{s.conf[0][1]}</Cell>
            <Cell center>{s.conf[0][2]}</Cell>
            <Cell header>You: Bear</Cell>
            <Cell center>{s.conf[1][0]}</Cell>
            <Cell center>{s.conf[1][1]}</Cell>
            <Cell center>{s.conf[1][2]}</Cell>
            <Cell header>You: Side</Cell>
            <Cell center>{s.conf[2][0]}</Cell>
            <Cell center>{s.conf[2][1]}</Cell>
            <Cell center>{s.conf[2][2]}</Cell>
          </div>
        </section>

        {/* Per‑class metrics table */}
        <section style={{ width: "100%", marginTop: 16 }}>
          <div style={{ fontSize: 20, margin: "8px 0 10px 0" }}>
            Precision / Sensitivity / Specificity per class
          </div>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "180px 1fr 1fr 1fr",
              border: "1px solid #2a2a2a",
              borderRadius: 12,
              overflow: "hidden",
            }}
          >
            <Cell header />
            <Cell header center>
              Precision
            </Cell>
            <Cell header center>
              Sensitivity
            </Cell>
            <Cell header center>
              Specificity
            </Cell>
            <Cell header>Bull</Cell>
            <Cell center>{(s.precision[0] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.recall[0] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.specificity[0] * 100).toFixed(1)}%</Cell>
            <Cell header>Bear</Cell>
            <Cell center>{(s.precision[1] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.recall[1] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.specificity[1] * 100).toFixed(1)}%</Cell>
            <Cell header>Side</Cell>
            <Cell center>{(s.precision[2] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.recall[2] * 100).toFixed(1)}%</Cell>
            <Cell center>{(s.specificity[2] * 100).toFixed(1)}%</Cell>
          </div>
        </section>

        {/* Actions */}
        <div
          className="container"
          style={{
            display: "flex",
            gap: 12,
            marginTop: 8,
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <button className="btn" onClick={downloadModel}>
            Download (.json)
          </button>
          <button className="btn btn-green" onClick={continueMore}>
            Not Complete (Continue)
          </button>
          <button
            className="btn"
            onClick={() => {
              // Persist both shared model and backtest handoff before routing.
              persistBacktestHandoff();
              // Navigate to your Backtest route. Adjust path if needed.
              window.location.href = "/Backtest";
            }}
          >
            Backtest Your Intuition
          </button>
        </div>

        <div
          style={{
            marginTop: 16,
            textAlign: "center",
            maxWidth: 900,
            lineHeight: 1.5,
            fontWeight: 700,
            color: recColor,
          }}
        >
          {recHeadline}
          <div style={{ marginTop: 6, color: recColor, fontWeight: 600 }}>
            {recBody}
          </div>
        </div>
      </div>
    </>
  );
}

/* ===================== Presentational helpers ===================== */
function Stat({
  label,
  value,
  styleExtra,
}: {
  label: string;
  value: string;
  styleExtra?: React.CSSProperties;
}) {
  return (
    <div className="stat-card" style={styleExtra}>
      <div className="stat-k">{label}</div>
      <div className="stat-v">{value}</div>
    </div>
  );
}
function Cell({
  children,
  header = false,
  center = false,
}: {
  children?: React.ReactNode;
  header?: boolean;
  center?: boolean;
}) {
  return (
    <div
      style={{
        padding: "12px 14px",
        borderTop: "1px solid #2a2a2a",
        borderLeft: "1px solid #2a2a2a",
        background: header ? "#0b0b0b" : "transparent",
        color: header ? "#cbd5e1" : "#e5e7eb",
        fontWeight: header ? 600 : 400,
        textAlign: center ? ("center" as const) : ("left" as const),
      }}
    >
      {children}
    </div>
  );
}
