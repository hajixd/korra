// === PART 1/4 ===
// Seasons Live — XAUUSD (15m)
// Adds: per-second UTC/Local clock (theme-matched, header right, left of theme toggle)
// Fixes: Twelve Data timestamp parsed as true UTC

import ToastPortal from "./ToastPortal";
import { useGlow, useEdgeGlow, glowClass } from "./effects";

import React, {
  useEffect,
  useMemo,
  useState,
  useCallback,
  useRef,
} from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceDot,
  ResponsiveContainer,
  CartesianGrid,
  ReferenceArea,
} from "recharts";
import { motion } from "framer-motion";

// ====== CONFIG ======
// ====== API Keys (rotate across these) ======
const TD_KEYS = [
  "139626f1aaa3426a942e411734ecb8c2",
  "161b08145b264df9bcbf13aed829da19",
  "41e91a08c67c4c2c8a8570f17bb2d917",
  "c7987057e54e4c528a3a05feb9cff435",
] as const;
const LS_TD_KEYPTR = "seasons.td.keyPtr"; // remembers last-used index

function getKeyPtr(): number {
  try {
    const raw = localStorage.getItem(LS_TD_KEYPTR);
    const idx = raw == null ? 0 : Number(raw);
    return Number.isFinite(idx)
      ? Math.max(0, Math.min(idx, TD_KEYS.length - 1))
      : 0;
  } catch {
    return 0;
  }
}
function setKeyPtr(i: number) {
  try {
    localStorage.setItem(LS_TD_KEYPTR, String(i % TD_KEYS.length));
  } catch {}
}
function pickKey(): string {
  return TD_KEYS[getKeyPtr()];
}
function advanceKey() {
  setKeyPtr((getKeyPtr() + 1) % TD_KEYS.length);
}

const SYMBOL = "XAU/USD";
const INTERVAL = "15min";
const LOOKBACK_BARS = 200;

const SIGMA_WINDOW = 100;
const SIGMA_MULT = 1;
const DOLLARS_PER_UNIT = 100;

/**
 * Deterministic pseudo‑random number generator (LCG).  This generator
 * produces a repeatable sequence of pseudo‑random numbers for
 * simulations.  Both the backtest and live simulators use the same
 * implementation and default seed to ensure identical sampling
 * behaviour when using the same model and settings.
 */
function makeSeededRand(seed: number): () => number {
  let state = seed >>> 0;
  return function () {
    state = Math.imul(48271, state) % 0x7fffffff;
    return (state & 0x7fffffff) / 0x7fffffff;
  };
}

// Default seed used by the pseudo‑random generator.  Changing this value
// will generate a different deterministic sequence.  To match the
// backtest exactly, this constant must be identical in both files.
const DEFAULT_RNG_SEED = 123456789;

/* ===== Backtest ML helpers for live predicted trading ===== */

/**
 * Minimal representation of the IntuitionModel used in the backtest.  An
 * OvR-perceptron consists of three heads (BULL, BEAR, SIDE) each of which
 * contains a bias term followed by one or more weights.  The savedAt
 * timestamp is used to select the most recent model from localStorage.
 */
type IntuitionModel = {
  type: "OvR-perceptron";
  heads: { BULL: number[]; BEAR: number[]; SIDE: number[] };
  meta?: { feature?: string; windowLen?: number; savedAt?: number };
  savedAt?: number;
};

/**
 * Coerce an arbitrary object into a valid IntuitionModel.  If the object
 * cannot be interpreted as a model the function returns null.
 */
function coerceToIntuitionModel(raw: any): IntuitionModel | null {
  if (!raw || typeof raw !== "object") return null;
  const toArrHeads = (h: any) => {
    try {
      const BULL = (h.BULL ?? []).map((z: any) => +z || 0);
      const BEAR = (h.BEAR ?? []).map((z: any) => +z || 0);
      const SIDE = (h.SIDE ?? []).map((z: any) => +z || 0);
      if (
        [BULL, BEAR, SIDE].every(
          (arr) =>
            Array.isArray(arr) && arr.length >= 1 && arr.every(Number.isFinite)
        )
      )
        return { BULL, BEAR, SIDE };
      return null;
    } catch {
      return null;
    }
  };
  if (raw.type === "OvR-perceptron" && raw.heads) {
    let H = toArrHeads(raw.heads);
    if (!H && raw.heads.BULL?.w) {
      try {
        const B = [
          +(raw.heads.BULL.bias ?? 0),
          ...raw.heads.BULL.w.map((z: any) => +z || 0),
        ];
        const R = [
          +(raw.heads.BEAR.bias ?? 0),
          ...raw.heads.BEAR.w.map((z: any) => +z || 0),
        ];
        const S = [
          +(raw.heads.SIDE.bias ?? 0),
          ...raw.heads.SIDE.w.map((z: any) => +z || 0),
        ];
        H = { BULL: B, BEAR: R, SIDE: S };
      } catch {
        H = null;
      }
    }
    if (H)
      return {
        type: "OvR-perceptron",
        heads: H,
        meta: raw.meta,
        savedAt: raw.savedAt ?? raw.meta?.savedAt ?? Date.now(),
      };
  }
  if (raw.BULL && raw.BEAR && raw.SIDE) {
    const H = toArrHeads(raw);
    if (H)
      return {
        type: "OvR-perceptron",
        heads: H,
        meta: raw.meta,
        savedAt: raw.savedAt ?? raw.meta?.savedAt ?? Date.now(),
      };
  }
  return null;
}

/**
 * Attempt to load the most recently saved IntuitionModel from localStorage.
 * The search prefers explicit keys and snapshot/fallback keys but will
 * scan all keys if necessary.  Returns null if no valid model is found.
 */
const BT_BACKTEST_SNAPSHOT_KEY = "backtest_snapshot_v1";
const BT_FALLBACK_MODEL_KEY = "intuition_model_latest";
function loadIntuitionModelFromStorage(): IntuitionModel | null {
  // 1) Check the backtest snapshot key for a nested model
  try {
    const rawSnap = localStorage.getItem(BT_BACKTEST_SNAPSHOT_KEY);
    if (rawSnap) {
      const snap = JSON.parse(rawSnap);
      const mm = coerceToIntuitionModel(snap?.model);
      if (mm) return mm;
    }
  } catch {}
  // 2) Check a fallback key used by earlier versions
  try {
    const raw = localStorage.getItem(BT_FALLBACK_MODEL_KEY);
    if (raw) {
      const j = JSON.parse(raw);
      const mm = coerceToIntuitionModel(j);
      if (mm) return mm;
    }
  } catch {}
  // 3) Check the explicit model key used by the live upload handler
  try {
    const rawModel = localStorage.getItem("intuition-model.json");
    if (rawModel) {
      const j = JSON.parse(rawModel);
      const mm = coerceToIntuitionModel(j);
      if (mm) return mm;
    }
  } catch {}
  // 4) Otherwise scan all keys and pick the most recent model
  let best: { m: IntuitionModel; t: number } | null = null;
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i)!;
    try {
      const v = localStorage.getItem(k);
      if (!v || v.length < 10) continue;
      const j = JSON.parse(v);
      const mm = coerceToIntuitionModel(j);
      if (mm) {
        const t = mm.savedAt ?? mm.meta?.savedAt ?? Date.now();
        if (!best || t > best.t) best = { m: mm, t };
      }
    } catch {}
  }
  return best?.m ?? null;
}

/* ----- ML feature and scoring helpers ----- */

/**
 * Compute a simple feature vector for bar i from the OHLC rows.  The vector
 * consists of (1) the return since the previous close, (2) the high-low
 * range normalised by the max price, and (3) the deviation of the close
 * from its trailing average over the last 10 bars.  Missing previous bars
 * are handled gracefully.
 */
function makeF(r: any[], i: number) {
  const c = r[i].close,
    p = i > 0 ? r[i - 1].close : c;
  const ret = (c - p) / (p || 1);
  const rg = (r[i].high - r[i].low) / Math.max(r[i].high, 1e-9);
  let avg = 0,
    n = 0;
  for (let k = Math.max(0, i - 9); k <= i; k++) {
    avg += r[k].close;
    n++;
  }
  avg /= n || 1;
  const dev = (c - avg) / (avg || 1);
  return [ret, rg, dev];
}

/** Score a feature vector against a model head (bias + weights). */
const scoreHeadVector = (f: number[], head: number[]) => {
  const bias = head?.[0] ?? 0;
  const K = Math.min(f.length, Math.max(0, (head?.length ?? 1) - 1));
  let s = bias;
  for (let i = 0; i < K; i++) s += f[i] * (head[i + 1] ?? 0);
  return s;
};

/** Score all three heads for a given feature vector. */
const scoreHeadsFlexible = (
  f: number[],
  h: { BULL: number[]; BEAR: number[]; SIDE: number[] }
) => ({
  BULL: scoreHeadVector(f, h.BULL),
  BEAR: scoreHeadVector(f, h.BEAR),
  SIDE: scoreHeadVector(f, h.SIDE),
});

/** Softmax helper for three-element objects. */
function softmax3(s: { BULL: number; BEAR: number; SIDE: number }) {
  const m = Math.max(s.BULL, s.BEAR, s.SIDE);
  const eB = Math.exp(s.BULL - m),
    eR = Math.exp(s.BEAR - m),
    eS = Math.exp(s.SIDE - m);
  const Z = eB + eR + eS || 1;
  return { BULL: eB / Z, BEAR: eR / Z, SIDE: eS / Z };
}

/** Argmax helper for three‑way probabilities. */
const argmax3p = (p: {
  BULL: number;
  BEAR: number;
  SIDE: number;
}): "BULL" | "BEAR" | "SIDE" =>
  p.BULL >= p.BEAR && p.BULL >= p.SIDE
    ? "BULL"
    : p.BEAR >= p.SIDE
    ? "BEAR"
    : "SIDE";

/**
 * Convert class frequency biases into a normalised prior distribution.  Each
 * bias (0–100) is treated as a weight; the returned values sum to 1.
 */
function normalizedPriors(
  bBull = 50,
  bBear = 50,
  bSide = 50
): { BULL: number; BEAR: number; SIDE: number } {
  const s = Math.max(1e-9, bBull + bBear + bSide);
  return { BULL: bBull / s, BEAR: bBear / s, SIDE: bSide / s };
}

/**
 * Blend strength determines how strongly to mix the model predictions with
 * the prior distribution.  When all biases equal 50 the blend strength is
 * zero; as the biases move away from 50 the strength increases up to 1.
 */
function blendStrength(bBull = 50, bBear = 50, bSide = 50) {
  const d = Math.abs(bBull - 50) + Math.abs(bBear - 50) + Math.abs(bSide - 50);
  return Math.max(0, Math.min(1, d / 150));
}

/**
 * Given an OvR perceptron model and a series of rows, compute a signed
 * margin prediction for each bar using a feature vector whose length
 * matches the model weights.  The returned array has the same length as
 * rows; values before the model's feature window are zero.  Positive
 * values favour bullish positions, negative values favour bearish,
 * and zero indicates sideways dominance.  Returns null if the model
 * cannot be interpreted.
 */
function computeMarginPredictions(
  model: any,
  rows: { close: number }[]
): number[] | null {
  if (!model || typeof model !== "object") return null;
  const heads = (model as any).heads;
  if (!heads) return null;
  const bullW: number[] | undefined = heads.BULL || heads.Bull || heads.bull;
  const bearW: number[] | undefined = heads.BEAR || heads.Bear || heads.bear;
  const sideW: number[] | undefined = heads.SIDE || heads.Side || heads.side;
  if (!bullW || !bearW || !sideW) return null;
  const L = bullW.length;
  if (bearW.length !== L || sideW.length !== L) return null;
  const out: number[] = [];
  for (let i = 0; i < rows.length; i++) {
    if (i < L) {
      out.push(0);
      continue;
    }
    const feats: number[] = [];
    for (let k = 0; k < L; k++) {
      const idxCur = i - (L - 1) + k;
      const idxPrev = idxCur - 1;
      if (idxPrev < 0 || idxCur >= rows.length) {
        feats.push(0);
      } else {
        const prevClose = rows[idxPrev].close;
        const curClose = rows[idxCur].close;
        const diff = prevClose !== 0 ? (curClose - prevClose) / prevClose : 0;
        feats.push(diff);
      }
    }
    let sBull = 0,
      sBear = 0,
      sSide = 0;
    for (let j = 0; j < L; j++) {
      const f = feats[j];
      sBull += (bullW[j] ?? 0) * f;
      sBear += (bearW[j] ?? 0) * f;
      sSide += (sideW[j] ?? 0) * f;
    }
    const m = Math.max(sBull, sBear, sSide);
    const eB = Math.exp(sBull - m);
    const eR = Math.exp(sBear - m);
    const eS = Math.exp(sSide - m);
    const Z = eB + eR + eS || 1;
    const pBull = eB / Z;
    const pBear = eR / Z;
    const pSide = eS / Z;
    const probs = [pBull, pBear, pSide].sort((a, b) => b - a);
    const margin = probs[0] - probs[1];
    let signal = 0;
    if (pBull >= pBear && pBull >= pSide) signal = margin;
    else if (pBear >= pSide) signal = -margin;
    else signal = 0;
    out.push(signal);
  }
  return out;
}

/**
 * Convert an exit reason code into a more descriptive human‑readable label.
 * This function maps known backtest and simulator exit codes to friendly
 * strings.  Unknown codes are transformed from camelCase or ALLCAPS into
 * spaced words (e.g. "LostConfidence" → "Lost Confidence").
 */
function humanizeReason(r: string): string {
  const map: Record<string, string> = {
    TP: "Take Profit",
    SL: "Stop Loss",
    TargetLen: "Target Range",
    MaxBars: "Max Bars Reached",
    TurnedSideways: "Turned Sideways",
    LostConfidence: "Lost Confidence",
    End: "End",
    SIGNAL: "Signal Flip",
    LENGTH: "Max Bars",
    TRAIL: "Trailing Stop",
    EXIT: "Exit",
    ANCHOR: "Anchor",
    HORIZON: "Horizon",
  };
  if (map[r]) return map[r];
  // Replace uppercase letters with space+letter, trim, and capitalise first char
  return r
    .replace(/([A-Z])/g, " $1")
    .trim()
    .replace(/^\w/, (c) => c.toUpperCase());
}
// Layout & axis
const CHART_MARGINS = { top: 10, right: 24, left: 12, bottom: 0 };
const Y_AXIS_WIDTH = 64;

// ====== "Alpha Arena"-ish palette & type ======
const ARENA_GREEN = "#16C784"; // crypto‑style green
const ARENA_RED = "#EA3943"; // crypto‑style red
const ARENA_BLUE = "#5B8DEF";
const ARENA_DARK = "#0F1113";
// Neutral grey used for sideways confidence bands.  When sideways confidence is high
// the band appears grey; at zero confidence the band is transparent.
const ARENA_GRAY = "#6B7280";

// ====== LABELS ======
const SEASON_LABELS: Record<number, string> = {
  1: "Spring",
  2: "Summer",
  3: "Fall",
  4: "Winter",
};
const DAY_LABELS: Record<number, string> = { 1: "Day", 2: "Night" };
const WEATHER_LABELS: Record<number, string> = {
  1: "Clear Skies",
  2: "Sunshine",
  3: "Cloudy",
  4: "Rain",
};

// Colors for bands
const seasonColor = (v: number) =>
  v === 1 ? "#34d399" : v === 2 ? "#fbbf24" : v === 3 ? "#fb923c" : "#60a5fa";
// Night now deeper blue (not near-black)
const dayColor = (v: number) => (v === 1 ? "#60a5fa" : "#0b2565");
const weatherColor = (v: number) =>
  v === 1 ? "#fde68a" : v === 2 ? "#22c55e" : v === 3 ? "#38bdf8" : "#ef4444";

// Extend the band label type to support new bull/bear/side classifications.
type LabelType = "Season" | "Day" | "Weather" | "Bull" | "Bear" | "Side";

type Criterion = {
  type: LabelType;
  values: number[];
  temporal?: "Current" | "Previous" | "MostNext";
  progressionPct?: number;
  progressionCmp?: "Higher" | "Lower";
  stddevEarlyExit?: boolean;
  anchor?: boolean;
  required?: boolean;
  not?: boolean;
};

type Trade = {
  side: "BUY" | "SELL";
  entryIdx: number;
  exitIdx: number;
  entryPrice: number;
  exitPrice: number;
  reason: "TP" | "SL" | "EXIT" | "ANCHOR" | "HORIZON";
  pnl: number;
};

type OpenTrade = {
  side: "BUY" | "SELL";
  entryIdx: number;
  entryPrice: number;
  unrealized: number;
} | null;

// ====== Throttling/cache keys ======
const LS_LAST_FETCH = "seasons.lastFetchMs";
const LS_CACHED_BARS = "seasons.cachedBars";

/**
 * Attempt to load an array of numeric predictions from localStorage.
 * The first key containing a JSON array of numbers will be returned.
 * If none are found, returns null.
 */
function loadModelPredictionsFromStorage(): number[] | null {
  /**
   * Attempt to read a predictions array from well‑known keys first, then
   * iterate through all keys in localStorage.  A predictions array is
   * defined as either an array of numbers or an object containing a
   * `predictions` property which itself is an array of numbers.  The
   * function returns the first matching array, or null if none are found.
   */
  try {
    const explicitKeys = [
      "intuition-model.json",
      "intuition-model",
      "intuitionModel",
      "modelPredictions",
    ];
    for (const key of explicitKeys) {
      const item = localStorage.getItem(key);
      if (!item) continue;
      try {
        const parsed = JSON.parse(item);
        if (
          Array.isArray(parsed) &&
          parsed.every((v: any) => typeof v === "number")
        ) {
          return parsed as number[];
        }
        if (
          parsed &&
          typeof parsed === "object" &&
          Array.isArray((parsed as any).predictions) &&
          (parsed as any).predictions.every((v: any) => typeof v === "number")
        ) {
          return (parsed as any).predictions as number[];
        }
      } catch {
        // ignore parse errors for explicit keys
      }
    }
    // fallback: iterate through all localStorage keys
    for (const key in localStorage) {
      if (!Object.prototype.hasOwnProperty.call(localStorage, key)) continue;
      const item = localStorage.getItem(key);
      if (!item) continue;
      try {
        const parsed = JSON.parse(item);
        if (
          Array.isArray(parsed) &&
          parsed.every((v: any) => typeof v === "number")
        ) {
          return parsed as number[];
        }
        if (
          parsed &&
          typeof parsed === "object" &&
          Array.isArray((parsed as any).predictions) &&
          (parsed as any).predictions.every((v: any) => typeof v === "number")
        ) {
          return (parsed as any).predictions as number[];
        }
      } catch {
        // ignore parse errors for arbitrary keys
      }
    }
  } catch {
    // Access to localStorage may throw (e.g. in server environments)
  }
  return null;
}

// ====== Market session helpers (UTC) ======
// Detect NY DST via timeZoneName (EDT vs EST)
function isNYDST(d: Date) {
  const tz = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    timeZoneName: "short",
  })
    .formatToParts(d)
    .find((p) => p.type === "timeZoneName")?.value;
  return tz?.includes("EDT");
}
// Common CFD/FX schedules: 21:00 UTC in DST, 22:00 UTC in standard time
function sessionOpenUtcHour(d: Date) {
  return isNYDST(d) ? 21 : 22;
}
function sessionCloseUtcHour(d: Date) {
  return isNYDST(d) ? 21 : 22;
}

/**
 * True if a UTC datetime falls inside the weekly trading session.
 * SUNDAY opens 2 hours earlier than standard openH.
 */
function isTradingSessionUTC(dUtc: Date) {
  // Use local day/hour/minute instead of UTC.  This aligns the trading
  // session with the user's local timezone rather than UTC.  The
  // open/close hours are still computed via sessionOpenUtcHour and
  // sessionCloseUtcHour which use NY DST to derive the session schedule.
  const dow = dUtc.getDay(); // 0=Sun ... 6=Sat
  const h = dUtc.getHours();
  const m = dUtc.getMinutes();
  const openH = sessionOpenUtcHour(dUtc);
  const closeH = sessionCloseUtcHour(dUtc);

  if (dow === 6) return false; // Saturday closed

  // Sunday: open 2 hours earlier than standard openH
  if (dow === 0) {
    const sunOpenH = (openH - 2 + 24) % 24;
    return h > sunOpenH || (h === sunOpenH && m >= 0);
  }

  // Friday closes at 21/22:00 UTC
  if (dow === 5) return h < closeH;

  // Mon–Thu fully open
  return true;
}

// Local-time helpers (updated Sunday reopen = 3:00 PM local)
function nextMarketOpen(from = new Date()): Date {
  const res = new Date(from);
  res.setSeconds(0, 0);

  const setToSunday15 = (base: Date) => {
    const t = new Date(base);
    const diffToSun = (7 - t.getDay()) % 7; // days until Sunday (0..6)
    t.setDate(t.getDate() + diffToSun);
    t.setHours(15, 0, 0, 0); // 3:00 PM local
    return t;
  };

  const sunday15 = setToSunday15(res);
  if (res.getTime() <= sunday15.getTime()) return sunday15;

  const next = new Date(sunday15);
  next.setDate(next.getDate() + 7);
  return next;
}
function formatDHMS(msLeft: number) {
  if (msLeft <= 0) return "0d 0h 0m 0s";
  const s = Math.floor(msLeft / 1000);
  const days = Math.floor(s / 86400);
  const hrs = Math.floor((s % 86400) / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  return `${days}d ${hrs}h ${mins}m ${secs}s`;
}

// ====== UTILS ======
function toMs(t: number | string | null | undefined) {
  if (t == null) return NaN;
  if (typeof t === "number") return t > 1e12 ? t : t * 1000;

  const s = String(t).trim();

  // Detect "YYYY-MM-DD HH:MM:SS" (no TZ) -> treat as UTC
  if (/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/.test(s)) {
    return Date.parse(s.replace(" ", "T") + "Z");
  }

  const n = Number(s);
  if (!Number.isNaN(n)) return n > 1e12 ? n : n * 1000;

  const d = Date.parse(s);
  return Number.isNaN(d) ? NaN : d;
}

const fmtPrice0 = new Intl.NumberFormat(undefined, {
  maximumFractionDigits: 0,
});
const fmtPrice2 = new Intl.NumberFormat(undefined, {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

// Unified stamp format (same look for Local and UTC)
function formatStamp(ms: number, tz?: "UTC" | "LOCAL") {
  const d = new Date(ms);
  const opts: Intl.DateTimeFormatOptions = {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
    timeZone: tz === "UTC" ? "UTC" : undefined,
  };
  // "Nov 02, 01:30:45 PM"
  return d.toLocaleString(undefined, opts);
}
function formatLocalShort(ms: number) {
  const d = new Date(ms);
  const date = d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
  });
  const time = d.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
  return `${date} ${time}`;
}
// === PART 2/4 ===
// Heikin Ashi & label derivation (aligned 1:1 to rows)
const ema = (arr: number[], p: number) => {
  if (!p || p < 1) return Array(arr.length).fill(NaN);
  const out = Array(arr.length).fill(NaN);
  const k = 2 / (p + 1);
  let prev: number | undefined;
  for (let i = 0; i < arr.length; i++) {
    const v = arr[i];
    prev = prev === undefined ? v : v * k + (prev as number) * (1 - k);
    out[i] = prev;
  }
  return out;
};
const highestPrev = (arr: number[], i: number, L: number) => {
  let m = -Infinity;
  for (let k = Math.max(0, i - L); k <= i - 1; k++) m = Math.max(m, arr[k]);
  return m;
};
const lowestPrev = (arr: number[], i: number, L: number) => {
  let m = Infinity;
  for (let k = Math.max(0, i - L); k <= i - 1; k++) m = Math.min(m, arr[k]);
  return m;
};

function computeHeikinAshi(
  ohlc: { open: number; high: number; low: number; close: number }[]
) {
  const n = ohlc.length;
  const ha = Array(n)
    .fill(null)
    .map(() => ({ open: NaN, high: NaN, low: NaN, close: NaN }));
  for (let i = 0; i < n; i++) {
    const { open: o, high: h, low: l, close: c } = ohlc[i];
    const closeHA = (o + h + l + c) / 4;
    const openHA =
      i === 0 ? (o + c) / 2 : (ha[i - 1].open + ha[i - 1].close) / 2;
    ha[i] = {
      open: openHA,
      high: Math.max(h, openHA, closeHA),
      low: Math.min(l, openHA, closeHA),
      close: closeHA,
    };
  }
  return ha;
}

// === Label assignment copied-in (only this logic taken from the reference) ===
function deriveLabelsFromOHLC(
  rows: {
    open: number;
    high: number;
    low: number;
    close: number;
    timeMs: number;
  }[],
  params: any
) {
  const {
    softLen,
    sharpLen,
    emaLen,
    refLen,
    sqzLen,
    timeSmcLen,
    timeModel,
    weatherModel,
  } = params;
  const n = rows.length;
  if (!n) return [];
  const closeArr = rows.map((r) => r.close),
    highArr = rows.map((r) => r.high),
    lowArr = rows.map((r) => r.low);
  const ma = ema(closeArr, emaLen),
    closema = closeArr.map((c, i) => c - ma[i]),
    sqzma = ema(closeArr, sqzLen).map((v, i) => v - ma[i]);
  const ha = computeHeikinAshi(rows);

  // Arrays aligned index-for-index with rows
  const Season: (number | null)[] = Array(n).fill(null),
    Day: (number | null)[] = Array(n).fill(null),
    Weather: (number | null)[] = Array(n).fill(null);

  const bull = (i: number, L: number) =>
    i > 0 &&
    highArr[i] > highestPrev(highArr, i, L) &&
    lowArr[i] > lowestPrev(lowArr, i, L);
  const bear = (i: number, L: number) =>
    i > 0 &&
    lowArr[i] < lowestPrev(lowArr, i, L) &&
    highArr[i] < highestPrev(highArr, i, L);

  for (let i = 0; i < n; i++) {
    // carry forward last known value, update in-place when a rule fires on THIS candle
    Season[i] = i > 0 ? Season[i - 1] : null;
    if (bull(i, softLen)) Season[i] = 1;
    if (bear(i, softLen)) Season[i] = 3;
    if (bull(i, sharpLen)) Season[i] = 2;
    if (bear(i, sharpLen)) Season[i] = 4;

    // Day
    if (timeModel === "Momentum") {
      const cm = closema[i],
        sm = sqzma[i];
      if (isFinite(cm) && isFinite(sm))
        Day[i] =
          cm >= sm && cm >= 0
            ? 1
            : cm <= sm && cm <= 0
            ? 2
            : i > 0
            ? Day[i - 1]
            : null;
    } else if (timeModel === "Heikin Ashi") {
      Day[i] = ha[i].close >= ha[i].open ? 1 : 2;
    } else {
      if (bull(i, timeSmcLen)) Day[i] = 1;
      if (bear(i, timeSmcLen)) Day[i] = 2;
      if (Day[i] == null) Day[i] = i > 0 ? Day[i - 1] : null;
    }

    // Weather
    if (weatherModel === "Heikin Ashi") {
      const green = ha[i].close >= ha[i].open,
        up = ha[i].high > Math.max(ha[i].open, ha[i].close),
        lo = ha[i].low < Math.min(ha[i].open, ha[i].close);
      Weather[i] =
        green && up && !lo
          ? 2
          : green && up && lo
          ? 1
          : !green && lo && !up
          ? 4
          : !green && up && lo
          ? 3
          : i > 0
          ? Weather[i - 1]
          : null;
    } else {
      const cm = closema[i],
        sm = sqzma[i];
      if (isFinite(cm) && isFinite(sm))
        Weather[i] =
          cm >= sm && cm <= 0
            ? 1
            : cm <= sm && cm >= 0
            ? 3
            : cm >= sm && cm >= 0
            ? 2
            : cm <= sm && cm <= 0
            ? 4
            : i > 0
            ? Weather[i - 1]
            : null;
    }
  }

  // Backfill initial nulls from the first non-null
  const backfill = (a: (number | null)[]) => {
    let last: number | null = null;
    for (let i = 0; i < a.length; i++) {
      if (a[i] == null) a[i] = last;
      else last = a[i];
    }
  };
  backfill(Season);
  backfill(Day);
  backfill(Weather);

  // Return rows aligned 1:1 with computed labels
  return rows.map((r, i) => ({
    ...r,
    Season: Season[i],
    Day: Day[i],
    Weather: Weather[i],
  }));
}
// Criterion/temporal evaluation and CriteriaBuilder (UI)

function getLabelValue(row: any, t: LabelType) {
  return t === "Season" ? row.Season : t === "Day" ? row.Day : row.Weather;
}
function runAgeSinceStart(rows: any[], type: LabelType, idx: number) {
  const v = getLabelValue(rows[idx], type);
  let age = 1;
  let j = idx - 1;
  while (j >= 0 && getLabelValue(rows[j], type) === v) {
    age++;
    j--;
  }
  return age;
}
function avgRunLengthTrailing(
  rows: any[],
  type: LabelType,
  value: number,
  idx: number,
  window: number
) {
  let runs: number[] = [];
  let cur = 0;
  for (let i = Math.max(0, idx - window); i <= idx; i++) {
    if (getLabelValue(rows[i], type) === value) cur++;
    else if (cur > 0) {
      runs.push(cur);
      cur = 0;
    }
  }
  if (cur > 0) runs.push(cur);
  if (!runs.length) return NaN;
  return runs.reduce((a, b) => a + b, 0) / runs.length;
}
function runLengthStatsTrailing(
  rows: any[],
  type: LabelType,
  value: number,
  idx: number,
  window: number
) {
  let runs: number[] = [];
  let cur = 0;
  for (let i = Math.max(0, idx - window); i <= idx; i++) {
    if (getLabelValue(rows[i], type) === value) cur++;
    else if (cur > 0) {
      runs.push(cur);
      cur = 0;
    }
  }
  if (cur > 0) runs.push(cur);
  if (!runs.length) return { avg: NaN, stdev: NaN };
  const avg = runs.reduce((a, b) => a + b, 0) / runs.length;
  const stdev = Math.sqrt(
    runs.reduce((s, v) => s + (v - avg) ** 2, 0) / runs.length
  );
  return { avg, stdev };
}

function mostLikelyNextLabel(
  rows: any[],
  type: LabelType,
  i: number,
  lookback = 500
): number {
  if (!rows?.length) return NaN as any;
  const end = Math.max(0, i - 1);
  const start = Math.max(0, end - lookback);
  const cur = Number(getLabelValue(rows[i], type));
  if (!Number.isFinite(cur)) return NaN as any;
  const counts = new Map<number, number>();
  for (let j = start; j < end; j++) {
    const a = Number(getLabelValue(rows[j], type));
    const b = Number(getLabelValue(rows[j + 1], type));
    if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
    if (a !== cur) continue;
    if (b === a) continue;
    counts.set(b, (counts.get(b) || 0) + 1);
  }
  if (counts.size === 0) return NaN as any;
  let best = NaN;
  let bestC = -1;
  for (const [val, c] of counts.entries()) {
    if (c > bestC) {
      bestC = c;
      best = val;
    }
  }
  return best as any;
}

function getTemporalValue(
  rows: any[],
  type: LabelType,
  i: number,
  temporal: "Current" | "Previous" | "MostNext" = "Current"
): number {
  if (temporal === "Current") return Number(getLabelValue(rows[i], type));
  if (temporal === "Previous") {
    if (i <= 0) return NaN as any;
    return Number(getLabelValue(rows[i - 1], type));
  }
  return mostLikelyNextLabel(rows, type, i, 500);
}

function criterionHolds(rows: any[], i: number, c: Criterion) {
  const temporal = c.temporal ?? "Current";
  const v = getTemporalValue(rows, c.type, i, temporal);
  if (!c.values?.length || !Number.isFinite(v)) return false;
  const isMember = c.values.includes(Number(v));
  if (c.not) return !isMember;
  if (!isMember) return false;

  if (temporal !== "Current") return true;
  if (c.progressionPct == null && !c.stddevEarlyExit) return true;

  const trackValue = c.values[0];
  if (Number(getLabelValue(rows[i], c.type)) !== trackValue) return false;

  const age = runAgeSinceStart(rows, c.type, i);

  if (c.stddevEarlyExit) {
    const { avg, stdev } = runLengthStatsTrailing(
      rows,
      c.type,
      trackValue,
      i,
      SIGMA_WINDOW
    );
    if (!Number.isFinite(avg) || !Number.isFinite(stdev) || avg <= 0)
      return false;
    const sigmaAdj = stdev * SIGMA_MULT;
    const targetBar = Math.max(1, Math.round(avg - sigmaAdj));
    return age >= targetBar;
  }

  const avgLen = avgRunLengthTrailing(rows, c.type, trackValue, i, 100);
  if (!Number.isFinite(avgLen) || avgLen <= 0) return false;
  const targetBar = Math.max(
    1,
    Math.round(((c.progressionPct ?? 0) * avgLen) / 100)
  );
  const cmp = c.progressionCmp ?? "Higher";
  return cmp === "Lower" ? age <= targetBar : age >= targetBar;
}

function buildEntryPredicateFromList(rows: any[], list: Criterion[]) {
  const hasAny = list?.length > 0;
  const requiredList = list.filter((c) => c.required);
  const holdsRequired = (i: number) =>
    requiredList.every((c) => criterionHolds(rows, i, c));
  const anchors = list.filter((c) => c.anchor);
  const holds = (i: number) => (requiredList.length ? holdsRequired(i) : true);
  return { hasAny, holds, anchors };
}
function buildExitPredicateFromList(rows: any[], list: Criterion[]) {
  const hasAny = list?.length > 0;
  const holds = (i: number) => list.some((c) => criterionHolds(rows, i, c));
  return { hasAny, holds };
}

function CriteriaBuilder({
  title,
  disabled,
  items,
  setItems,
  canAnchor,
}: {
  title: string;
  disabled: boolean;
  items: Criterion[];
  setItems: (v: Criterion[]) => void;
  canAnchor?: boolean;
}) {
  const [showForm, setShowForm] = useState(false);
  const [t, setT] = useState<LabelType>("Season");
  const [vals, setVals] = useState<number[]>([]);
  const [temporal, setTemporal] = useState<"Current" | "Previous" | "MostNext">(
    "Current"
  );
  const [prog, setProg] = useState<number | "">("");
  const [cmp, setCmp] = useState<"Higher" | "Lower">("Higher");
  const [useStdDev, setUseStdDev] = useState(false);

  const [editingIdx, setEditingIdx] = useState<number | null>(null);
  const [eVals, setEVals] = useState<number[]>([]);
  const [eTemporal, setETemporal] = useState<
    "Current" | "Previous" | "MostNext"
  >("Current");
  const [eProg, setEProg] = useState<number | "">("");
  const [eCmp, setECmp] = useState<"Higher" | "Lower">("Higher");
  const [eUseStdDev, setEUseStdDev] = useState(false);

  const add = () => {
    const c: Criterion = {
      type: t,
      values: vals.slice(),
      temporal,
      anchor: false,
      required: false,
      not: false,
    };
    if (temporal === "Current") {
      if (useStdDev) c.stddevEarlyExit = true;
      else if (prog !== "") {
        c.progressionPct = Number(prog);
        c.progressionCmp = cmp;
      }
    }
    setItems([...items, c]);
    setShowForm(false);
    setVals([]);
    setTemporal("Current");
    setProg("");
    setCmp("Higher");
    setUseStdDev(false);
  };
  const remove = (i: number) => {
    const copy = items.slice();
    copy.splice(i, 1);
    setItems(copy);
  };
  const toggleRequired = (i: number) => {
    const n = items.slice();
    const cur = n[i];
    const will = !cur.required;
    n[i] = { ...cur, required: will, anchor: will ? cur.anchor : false };
    setItems(n);
  };
  const toggleNot = (i: number) => {
    const n = items.slice();
    const cur = n[i];
    const will = !cur.not;
    n[i] = {
      ...cur,
      not: will,
      progressionPct: will ? undefined : cur.progressionPct,
      progressionCmp: will ? undefined : cur.progressionCmp,
      stddevEarlyExit: will ? false : cur.stddevEarlyExit,
    };
    setItems(n);
  };
  const toggleAnchor = (i: number) => {
    if (!canAnchor) return;
    const n = items.slice();
    const cur = n[i];
    const will = !cur.anchor;
    n[i] = {
      ...cur,
      anchor: will,
      required: will ? true : cur.required,
      progressionPct: undefined,
      progressionCmp: undefined,
      stddevEarlyExit: false,
      temporal: "Current",
    };
    setItems(n);
  };

  const LABEL_OPTIONS: Record<LabelType, { label: string; value: number }[]> = {
    Season: Object.entries(SEASON_LABELS).map(([v, l]) => ({
      value: Number(v),
      label: l,
    })),
    Day: Object.entries(DAY_LABELS).map(([v, l]) => ({
      value: Number(v),
      label: l,
    })),
    Weather: Object.entries(WEATHER_LABELS).map(([v, l]) => ({
      value: Number(v),
      label: l,
    })),
  };

  const Btn = (props: any) => (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      {...props}
    />
  );

  return (
    <div className="p-4 rounded-2xl bg-white border border-neutral-200 mb-6">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-extrabold tracking-tight">{title}</h3>
        <Btn
          type="button"
          onClick={() => setShowForm((v: any) => !v)}
          disabled={disabled}
          className={`px-3 py-1 rounded-xl text-sm border ${
            showForm ? "bg-neutral-100" : "bg-black text-white"
          }`}
        >
          {showForm ? "Close" : "Add +"}
        </Btn>
      </div>

      {items.length === 0 ? (
        <div className="text-xs text-neutral-500">No criteria.</div>
      ) : (
        <div className="space-y-2">
          {items.map((c, i) => (
            <div
              key={i}
              className="p-2 rounded-xl bg-white border border-neutral-200 text-sm"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex flex-wrap gap-x-3 gap-y-1">
                  <span className="text-neutral-900 font-semibold">
                    {c.type}
                  </span>
                  <span className="text-neutral-700">
                    ∈ [
                    {c.values
                      .map(
                        (v) =>
                          LABEL_OPTIONS[c.type].find((o) => o.value === v)
                            ?.label
                      )
                      .join(", ")}
                    ]
                  </span>
                  {c.temporal && c.temporal !== "Current" && (
                    <span className="text-neutral-500">
                      • {c.temporal === "Previous" ? "Previous" : "Most-Next"}
                    </span>
                  )}
                  {c.temporal === "Current" &&
                    c.progressionPct != null &&
                    !c.stddevEarlyExit &&
                    !c.not && (
                      <span className="text-neutral-500">
                        • Prog {c.progressionCmp === "Lower" ? "≤" : "≥"}{" "}
                        {c.progressionPct}%
                      </span>
                    )}
                  {c.temporal === "Current" && c.stddevEarlyExit && !c.not && (
                    <span className="text-amber-600">• 1σ early exit</span>
                  )}
                  {c.required && (
                    <span className="text-purple-700 font-semibold">
                      • REQUIRED
                    </span>
                  )}
                  {c.anchor && (
                    <span className="text-emerald-700 font-semibold">
                      • ANCHOR
                    </span>
                  )}
                  {c.not && (
                    <span className="font-semibold text-rose-600">• NOT</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {canAnchor && (
                    <>
                      <Btn
                        type="button"
                        onClick={() => toggleRequired(i)}
                        className={`text-xs px-2 py-1 rounded-lg border ${
                          c.required
                            ? "border-purple-500 text-purple-700 bg-purple-50"
                            : "border-neutral-300"
                        }`}
                      >
                        Required
                      </Btn>
                      <Btn
                        type="button"
                        onClick={() => toggleNot(i)}
                        className={`text-xs px-2 py-1 rounded-lg border ${
                          c.not
                            ? "border-rose-500 text-rose-600 bg-rose-50"
                            : "border-neutral-300"
                        }`}
                      >
                        Not
                      </Btn>
                      <Btn
                        type="button"
                        onClick={() => toggleAnchor(i)}
                        className={`text-xs px-2 py-1 rounded-lg border ${
                          c.anchor
                            ? "border-emerald-500 text-emerald-700 bg-emerald-50"
                            : "border-neutral-300"
                        }`}
                      >
                        Anchor
                      </Btn>
                    </>
                  )}
                  <Btn
                    type="button"
                    onClick={() => remove(i)}
                    className="text-xs px-2 py-1 rounded-lg border"
                  >
                    Remove
                  </Btn>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <div className="mt-3 grid grid-cols-1 md:grid-cols-5 gap-3 text-sm">
          <label className="flex flex-col gap-1">
            <span className="text-xs text-neutral-500">Temporal</span>
            <select
              className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
              value={temporal}
              onChange={(e) => setTemporal(e.target.value as any)}
            >
              <option value="Current">Current</option>
              <option value="Previous">Previous</option>
              <option value="MostNext">Most Likely Next</option>
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-xs text-neutral-500">Type</span>
            <select
              className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
              value={t}
              onChange={(e) => {
                setT(e.target.value as LabelType);
                setVals([]);
              }}
            >
              <option>Season</option>
              <option>Day</option>
              <option>Weather</option>
            </select>
          </label>
          <label className="flex flex-col gap-1">
            <span className="text-xs text-neutral-500">Values</span>
            <select
              multiple
              className="min-h-28 bg-white border border-neutral-300 rounded-xl px-3 py-2"
              value={vals.map(String)}
              onChange={(e) =>
                setVals(
                  Array.from(e.target.selectedOptions).map((o) =>
                    Number(o.value)
                  )
                )
              }
            >
              {Object.entries(
                t === "Season"
                  ? SEASON_LABELS
                  : t === "Day"
                  ? DAY_LABELS
                  : WEATHER_LABELS
              ).map(([value, label]) => (
                <option key={`${t}-${value}`} value={Number(value)}>
                  {label}
                </option>
              ))}
            </select>
          </label>

          <div className="flex flex-col gap-2">
            <span className="text-xs text-neutral-500">Progression or 1σ</span>
            <label className="flex items-center gap-2 text-sm">
              <span className="text-xs text-neutral-500 w-24">Compare</span>
              <select
                className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                value={cmp}
                onChange={(e) => setCmp((e.target.value as any) ?? "Higher")}
                disabled={useStdDev || temporal !== "Current"}
              >
                <option value="Higher">Higher (≥ %)</option>
                <option value="Lower">Lower (≤ %)</option>
              </select>
            </label>
            <div className="flex items-center gap-3">
              <input
                type="range"
                min={0}
                max={500}
                step={1}
                disabled={useStdDev || temporal !== "Current"}
                className="w-full"
                value={
                  useStdDev || temporal !== "Current"
                    ? 0
                    : prog === ""
                    ? 0
                    : Number(prog)
                }
                onChange={(e) => setProg(Number(e.target.value))}
              />
              <div className="text-sm w-12 text-right">
                {useStdDev || temporal !== "Current"
                  ? "—"
                  : prog === ""
                  ? "—"
                  : `${prog}%`}
              </div>
            </div>
            <label className="inline-flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={temporal === "Current" ? useStdDev : false}
                disabled={temporal !== "Current"}
                onChange={(e) => {
                  const v = e.target.checked;
                  setUseStdDev(v);
                  if (v) setProg("");
                }}
              />
              <span>Exit 1σ early (avgLen − stdev)</span>
            </label>
          </div>

          <div className="md:col-span-5">
            <motion.button
              type="button"
              onClick={add}
              className="px-3 py-2 rounded-xl bg-black text-white"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              disabled={disabled || vals.length === 0}
            >
              Add
            </motion.button>
          </div>
        </div>
      )}
    </div>
  );
}
// === PART 3/4 ===
// Main App & Chart — true index X-axis, UTC+Local tooltip, Sunday open 2h earlier,
// + new per-second clock (UTC & Local) in header (left of theme toggle).

function CustomTooltip({
  active,
  label,
  payload,
  rows,
  dark,
}: {
  active?: boolean;
  label?: any; // numeric index
  payload?: any[];
  rows: any[];
  dark: boolean;
}) {
  if (!active || !rows?.length) return null;
  const idx = Math.max(0, Math.min(rows.length - 1, Math.round(Number(label))));
  const row = rows[idx];
  if (!row) return null;

  const utcStr = formatStamp(row.timeMs, "UTC");
  const locStr = formatStamp(row.timeMs, "LOCAL");
  const price = rows[idx].close;

  return (
    <div
      className="recharts-default-tooltip"
      style={{
        backgroundColor: dark ? "#111827" : "#ffffff",
        border: `1px solid ${dark ? "#374151" : "#e5e7eb"}`,
        color: dark ? "#e5e7eb" : "#111827",
        boxShadow: "0 8px 24px rgba(0,0,0,0.35)",
        borderRadius: 12,
        padding: "8px 10px",
      }}
    >
      <div style={{ fontWeight: 800, marginBottom: 4 }}>
        {fmtPrice2.format(price)}
      </div>
      <div style={{ fontSize: 12, opacity: 0.9 }}>UTC: {utcStr}</div>
      <div style={{ fontSize: 12, opacity: 0.9 }}>Local: {locStr}</div>
    </div>
  );
}

// Small live clock (UTC + Local), theme-aware
function LiveClocks({ dark }: { dark: boolean }) {
  const [now, setNow] = useState<number>(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const utcStr = formatStamp(now, "UTC");
  const locStr = formatStamp(now, "LOCAL");
  const textColor = dark ? "#e5e7eb" : "#111827";
  const subColor = dark ? "#9ca3af" : "#6b7280";

  return (
    <div className="flex flex-col items-end mr-1 select-none">
      <div
        style={{ color: textColor, fontSize: 12, lineHeight: "14px" }}
        title="Coordinated Universal Time"
      >
        UTC: {utcStr}
      </div>
      <div
        style={{ color: subColor, fontSize: 12, lineHeight: "14px" }}
        title="Your Local Time"
      >
        Local: {locStr}
      </div>
    </div>
  );
}

export default function SeasonsLiveApp() {
  const [bars, setBars] = useState<any[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  // Theme
  const [dark, setDark] = useState<boolean>(() => {
    try {
      return localStorage.getItem("seasons.theme") === "dark";
    } catch {
      return false;
    }
  });

  // Models
  const [timeModel, setTimeModel] = useState("Momentum");
  const [weatherModel, setWeatherModel] = useState("Heikin Ashi");
  const [softLen, setSoftLen] = useState(20);
  const [sharpLen, setSharpLen] = useState(40);
  const [emaLen, setEmaLen] = useState(50);
  const [refLen, setRefLen] = useState(13);
  const [sqzLen, setSqzLen] = useState(5);
  const [timeSmcLen, setTimeSmcLen] = useState(6);

  // Criteria
  const [buyEntry, setBuyEntry] = useState<Criterion[]>([]);
  const [buyExit, setBuyExit] = useState<Criterion[]>([]);
  const [sellEntry, setSellEntry] = useState<Criterion[]>([]);
  const [sellExit, setSellExit] = useState<Criterion[]>([]);

  // Risk
  // Dollars per point (multiplier for PnL calculations) is now
  // configurable by the user.  It defaults to 100 to match the
  // original DOLLARS_PER_UNIT constant.
  const [dollarsPerPoint, setDollarsPerPoint] = useState<string | number>(
    "100"
  );
  const [stopLossUSD, setStopLossUSD] = useState<string | number>("");
  const [takeProfitUSD, setTakeProfitUSD] = useState<string | number>("");
  // Removed lotSize: risk sizing is controlled solely via dollarsPerPoint
  // horizonBars has been removed; the max trade length is now governed solely by the
  // user‑specified maximum trade length.  There is no fallback horizon anymore.
  // const [horizonBars, setHorizonBars] = useState<number>(100);

  // === Advanced options (Backtest settings) ===
  // Minimum Entry Margin (percentage or points). Determines the required margin to enter a trade.
  const [minEntryMargin, setMinEntryMargin] = useState<number>(0);
  // Minimum Hold Margin (%). Keeps a position open until this margin is met.
  const [minHoldMargin, setMinHoldMargin] = useState<number>(0);
  // Hysteresis in bars to smooth out signal flipping.
  const [hysteresisBars, setHysteresisBars] = useState<number>(0);
  // Target Range measured in bars.  We track the lower and upper bounds separately
  // to support a dual‑slider UI (min and max).  Defaults to 10–60 bars.
  const [targetRangeMinBars, setTargetRangeMinBars] = useState<number>(10);
  const [targetRangeMaxBars, setTargetRangeMaxBars] = useState<number>(60);
  // Percentage of price move used to pull a trade to its target.
  const [pullToTargetPct, setPullToTargetPct] = useState<number>(0);
  // Percentage of price move used to push a trade to its target.
  const [pushToTargetPct, setPushToTargetPct] = useState<number>(0);
  // Minimum trade length in bars.
  const [minTradeLengthBars, setMinTradeLengthBars] = useState<number>(0);
  // Maximum trade length in bars.
  const [maxTradeLengthBars, setMaxTradeLengthBars] = useState<number>(0);
  // Trailing Stop is considered enabled when trailDistancePts > 0; no dedicated toggle state.
  // const [trailingStop, setTrailingStop] = useState<boolean>(false);
  // Trailing stop distance in points (price units).
  const [trailDistancePts, setTrailDistancePts] = useState<number>(0);
  // Thresholds for entering trades based on model confidence (percent).
  const [bullBiasPct, setBullBiasPct] = useState<number>(50);
  const [bearBiasPct, setBearBiasPct] = useState<number>(50);
  const [sidewaysBiasPct, setSidewaysBiasPct] = useState<number>(50);

  // === File upload handling ===
  // A ref to the hidden file input used for uploading a model JSON.  When the
  // user clicks the "Upload Model" button, this ref is triggered to open
  // the file picker.  The uploaded file should contain an array of numeric
  // predictions or an object with a `predictions` array.  Upon upload, any
  // existing model keys are removed from localStorage and the new predictions
  // are stored under "intuition-model.json".  A flash message informs the
  // user of success and rows are recomputed to pick up the new model.
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleModelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const text = ev.target?.result as string;
        const parsed = JSON.parse(text);
        let predictions: number[] | null = null;
        // If the uploaded file contains an OvR perceptron model (with heads),
        // persist the raw model JSON so that the simulator can derive
        // predictions on the fly.  We avoid computing predictions
        // immediately because the current bar data may not be loaded
        // when the user uploads the model.  Persisting the model
        // allows the live simulator to load it via loadIntuitionModelFromStorage().
        try {
          const maybeModel = coerceToIntuitionModel(parsed);
          if (maybeModel) {
            // Remove any existing predictions or model keys
            const rmKeys = [
              "intuition-model.json",
              "intuition-model",
              "intuitionModel",
              "modelPredictions",
            ];
            for (const k of rmKeys) {
              try {
                localStorage.removeItem(k);
              } catch {}
            }
            // Save the model JSON under the canonical key
            try {
              localStorage.setItem(
                "intuition-model.json",
                JSON.stringify(parsed)
              );
              localStorage.setItem("intuition-model-name", file.name);
            } catch {}
            // Update the UI state to reflect the uploaded model
            setModelName(file.name);
            // bump the version so predictions recompute on next render
            setModelVersion((v) => v + 1);
            setFlashMsg("Model uploaded");
            setTimeout(() => setFlashMsg(null), 3000);
            // Recompute rows and run the simulation using the newly loaded model.
            recomputeRowsFromBars();
            setTimeout(() => {
              onSave();
            }, 0);
            return;
          }
        } catch {}
        // Helper to compute predictions from an OvR perceptron model with heads.  Each head should
        // contain a numeric weight vector.  We derive features from the candlestick
        // series by computing relative close‑to‑close differences over the window length.
        const computePredsFromWeights = (model: any): number[] | null => {
          /**
           * Derive a signed margin signal from a perceptron model.  Each head
           * (BULL, BEAR, SIDE) is a weight vector.  For each row we
           * compute dot products and apply a softmax to obtain class
           * probabilities.  The margin is defined as the difference
           * between the highest and second‑highest probabilities.  The
           * returned signal is positive when the bullish probability
           * dominates, negative when bearish dominates, and zero when
           * sideways dominates.  This closely mirrors the margin logic
           * used in the backtest simulator.
           */
          if (!model || typeof model !== "object") return null;
          const heads = (model as any).heads;
          if (!heads) return null;
          // Extract weight vectors under tolerant key names
          const bullW: number[] | undefined =
            heads.BULL || heads.Bull || heads.bull;
          const bearW: number[] | undefined =
            heads.BEAR || heads.Bear || heads.bear;
          const sideW: number[] | undefined =
            heads.SIDE || heads.Side || heads.side;
          if (!bullW || !bearW || !sideW) return null;
          const L = bullW.length;
          // Ensure all heads share the same length
          if (bearW.length !== L || sideW.length !== L) return null;
          const out: number[] = [];
          for (let i = 0; i < rows.length; i++) {
            // Until we have enough history to compute all L features, emit zero.
            if (i < L) {
              out.push(0);
              continue;
            }
            const feats: number[] = [];
            // Build a feature vector of length L: each element is the
            // normalised change between consecutive closes at a given offset.
            for (let k = 0; k < L; k++) {
              const idxCur = i - (L - 1) + k;
              const idxPrev = idxCur - 1;
              if (idxPrev < 0 || idxCur >= rows.length) {
                feats.push(0);
              } else {
                const prevClose = rows[idxPrev].close;
                const curClose = rows[idxCur].close;
                const diff =
                  prevClose !== 0 ? (curClose - prevClose) / prevClose : 0;
                feats.push(diff);
              }
            }
            // Compute linear scores for each class
            let bullScore = 0;
            let bearScore = 0;
            let sideScore = 0;
            for (let j = 0; j < L; j++) {
              const f = feats[j];
              bullScore += (bullW[j] ?? 0) * f;
              bearScore += (bearW[j] ?? 0) * f;
              sideScore += (sideW[j] ?? 0) * f;
            }
            // Compute class probabilities via softmax to obtain a proper
            // probability distribution.  Subtract the max for numerical stability.
            const m = Math.max(bullScore, bearScore, sideScore);
            const eB = Math.exp(bullScore - m);
            const eR = Math.exp(bearScore - m);
            const eS = Math.exp(sideScore - m);
            const Z = eB + eR + eS || 1;
            const pBull = eB / Z;
            const pBear = eR / Z;
            const pSide = eS / Z;
            // Identify the top two probabilities
            const probs = [pBull, pBear, pSide].sort((a, b) => b - a);
            const margin = probs[0] - probs[1];
            // Determine the dominant class
            let label: "BULL" | "BEAR" | "SIDE";
            if (pBull >= pBear && pBull >= pSide) label = "BULL";
            else if (pBear >= pSide) label = "BEAR";
            else label = "SIDE";
            // The signal is signed by class.  Sideways dominance yields zero.
            let signal = 0;
            if (label === "BULL") signal = margin;
            else if (label === "BEAR") signal = -margin;
            else signal = 0;
            out.push(signal);
          }
          return out;
        };
        // Accept either a plain array of numbers, an object with a `predictions` array,
        // or compute predictions from a perceptron model with heads.  If the parsed
        // object contains `heads` with weight vectors, derive predictions from it.
        if (
          Array.isArray(parsed) &&
          parsed.every((v: any) => typeof v === "number")
        ) {
          predictions = parsed as number[];
        } else if (Array.isArray(parsed)) {
          // If the array is of objects, attempt to derive a numeric signal from a `signal`, `prediction` or `value` property.
          const maybeNums = parsed.map((item: any) => {
            if (typeof item === "number") return item;
            if (item && typeof item === "object") {
              const sig = item.signal ?? item.prediction ?? item.value;
              if (typeof sig === "number") return sig;
            }
            return null;
          });
          if (
            maybeNums.every((v: any) => typeof v === "number" && isFinite(v))
          ) {
            predictions = maybeNums as number[];
          }
        } else if (parsed && typeof parsed === "object") {
          // If predictions array provided directly
          const preds = (parsed as any).predictions;
          if (
            Array.isArray(preds) &&
            preds.every((v: any) => typeof v === "number")
          ) {
            predictions = preds as number[];
          } else {
            // Attempt to compute predictions from weights
            const comp = computePredsFromWeights(parsed);
            if (comp && Array.isArray(comp)) {
              predictions = comp;
            }
          }
        }
        if (!predictions) {
          // The uploaded JSON did not contain a usable predictions array.  Process the
          // file the same way backtest.tsx does: if it is an array, attempt to
          // interpret each element as a trade definition and set trades directly.
          if (Array.isArray(parsed)) {
            const loaded: Trade[] = (parsed as any[])
              .map((item) => {
                const date =
                  (item as any).date ||
                  (item as any).datetime ||
                  (item as any).time;
                const price =
                  (item as any).price ||
                  (item as any).entry ||
                  (item as any).close;
                const units = (item as any).units || (item as any).qty || 1;
                const stopLoss =
                  (item as any).stopLoss ?? (item as any).sl ?? null;
                const takeProfit =
                  (item as any).takeProfit ?? (item as any).tp ?? null;
                if (!date || price == null) return null;
                const entryP =
                  typeof price === "number" ? price : parseFloat(price);
                const u = typeof units === "number" ? units : parseFloat(units);
                return {
                  entryIdx: 0,
                  exitIdx: 0,
                  reason: "UPLOAD",
                  side: u && u < 0 ? "SELL" : "BUY",
                  entryPrice: entryP,
                  exitPrice: entryP,
                  pnl: 0,
                  units: u,
                  stopLossUSD: stopLoss != null ? parseFloat(stopLoss) : null,
                  takeProfitUSD:
                    takeProfit != null ? parseFloat(takeProfit) : null,
                } as any;
              })
              .filter((t): t is Trade => !!t);
            // When trades are provided directly, we bypass the simulator and
            // simply display them in the history.  Clear any existing
            // predictions from localStorage so that the simulator doesn’t
            // attempt to run on stale data.
            const removeKeys = [
              "intuition-model.json",
              "intuition-model",
              "intuitionModel",
              "modelPredictions",
            ];
            for (const k of removeKeys) {
              try {
                localStorage.removeItem(k);
              } catch {}
            }
            setTrades(loaded);
            setOpenTrade(null);
            setPnlHistory(loaded.map(() => 0));
            setFlashMsg(`Loaded ${loaded.length} trades`);
            setTimeout(() => setFlashMsg(null), 3000);
            return;
          }
          alert(
            "Invalid model file. Expected an array of numbers or an object containing a 'predictions' array, or a list of trades."
          );
          return;
        }
        // Remove any existing known model keys before saving the new predictions
        const keys = [
          "intuition-model.json",
          "intuition-model",
          "intuitionModel",
          "modelPredictions",
        ];
        for (const k of keys) {
          try {
            localStorage.removeItem(k);
          } catch {}
        }
        // Persist the new predictions under the stable key and remember the file name.
        try {
          localStorage.setItem(
            "intuition-model.json",
            JSON.stringify(predictions)
          );
          // Persist the file name for display in the header
          localStorage.setItem("intuition-model-name", file.name);
        } catch {}
        // Update model name state for immediate display
        setModelName(file.name);
        // Notify the user and refresh internal state.  We reuse the flash
        // message system to indicate success and recompute rows so that
        // the memoised predictions are reloaded on the next run.
        setFlashMsg("Model uploaded");
        setTimeout(() => setFlashMsg(null), 3000);
        // Recompute labels from the existing bars; this triggers the
        // predictions memo to update on the next run.
        recomputeRowsFromBars();
        // Immediately run the simulation using the current settings so that
        // the bands and trade history are updated without requiring the user
        // to click Run.  Use a timeout to ensure state updates have been flushed.
        setTimeout(() => {
          onSave();
        }, 0);
      } catch {
        alert("Failed to parse model file.");
      }
    };
    reader.readAsText(file);
  };

  // Slider configuration for the dual Target Range control.  The slider
  // operates on a discrete scale from 0 to SLIDER_MAX.  The colour bar
  // between the two thumbs is computed from the current min/max values.  A
  // memoised style object is returned to avoid recalculating the gradient on
  // every render.
  const SLIDER_MAX = 200;
  const targetRangeTrackStyle = useMemo(() => {
    const minP = (targetRangeMinBars / SLIDER_MAX) * 100;
    const maxP = (targetRangeMaxBars / SLIDER_MAX) * 100;
    return {
      background: `linear-gradient(to right, ${ARENA_DARK} 0%, ${ARENA_DARK} ${minP}%, ${ARENA_GREEN} ${minP}%, ${ARENA_GREEN} ${maxP}%, ${ARENA_DARK} ${maxP}%, ${ARENA_DARK} 100%)`,
    };
  }, [targetRangeMinBars, targetRangeMaxBars]);

  // === Model status ===
  // Version counter for model changes. When incremented, this state triggers
  // recomputation of margin predictions.  It must be declared before
  // modelPredsMemo uses it in its dependency array.
  const [modelVersion, setModelVersion] = useState<number>(0);

  // Compute a memoized reference to the predictions array stored in localStorage.  If
  // predictions exist and have length > 0, we consider the model loaded.  This
  // effect is re‑evaluated whenever `rows` changes so that the dashboard
  // reflects the current model status when new data arrives.
  const modelPredsMemo = useMemo(() => {
    // First attempt to load a persisted predictions array.  If one
    // exists return it directly.
    const preds = loadModelPredictionsFromStorage();
    if (preds && preds.length > 0) return preds;
    // Otherwise attempt to load an OvR perceptron model and derive a
    // signed margin signal from the current row data.  When a model is
    // available compute a margin for each bar using the full weight
    // length of the model.  This produces a richer signal than the
    // three‑feature approximation and aligns with the backtest logic.  If
    // no model is available return an empty array so that downstream
    // logic gracefully handles the absence of predictions.
    const mdl = loadIntuitionModelFromStorage();
    if (mdl && (mdl as any).heads && rows && rows.length > 0) {
      const out = computeMarginPredictions(mdl as any, rows);
      return out ?? [];
    }
    return [];
  }, [rows, modelVersion]);
  const modelLoaded = modelPredsMemo != null && modelPredsMemo.length > 0;
  // Track the name of the last uploaded model file.  This is stored in
  // localStorage so it persists across reloads.  When no model has been
  // uploaded or predictions are missing, this string will be empty.
  const [modelName, setModelName] = useState<string>(() => {
    try {
      return localStorage.getItem("intuition-model-name") || "";
    } catch {
      return "";
    }
  });

  // Compute a display string for the model.  If a model is loaded we
  // display the file name (if available) or a generic "OK".  Otherwise
  // display "Missing".
  const modelDisplayName = modelLoaded ? modelName || "OK" : "Missing";

  // === Model dropdown and upload (mirroring backtest) ===
  // Controls whether the model list dropdown is visible.  When the user clicks
  // the "Model:" pill, this toggles and a list of available models is shown.
  const [modelDropdownOpen, setModelDropdownOpen] = useState<boolean>(false);
  // A list of available models discovered in localStorage.  Populated on
  // demand when opening the dropdown.  Each entry has the storage key and
  // parsed model.  We do not persist this state across runs.
  const [availableModels, setAvailableModels] = useState<
    { key: string; model: any }[]
  >([]);

  /**
   * Enumerate all IntuitionModels found in localStorage.  This searches every
   * key and attempts to coerce its JSON value into a valid model.  Only
   * entries that can be successfully coerced are returned.  This mirrors
   * the backtest behaviour for listing models.
   */
  function listAvailableModels(): { key: string; model: any }[] {
    const list: { key: string; model: any }[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i) as string;
      try {
        const v = localStorage.getItem(k);
        if (!v || v.length < 10) continue;
        const j = JSON.parse(v);
        const mm = coerceToIntuitionModel((j as any)?.model ?? j);
        if (mm) list.push({ key: k, model: mm });
      } catch {
        // ignore malformed entries
      }
    }
    return list;
  }

  /**
   * Delete a model by its storage key.  Removing the key from
   * localStorage and updating any dependent state.  If the deleted
   * model is currently selected, reset the modelName and force a
   * re-computation of predictions and simulation.  Errors are
   * ignored.
   */
  function deleteModelKey(k: string) {
    try {
      localStorage.removeItem(k);
    } catch {}
    // If the deleted model was selected, clear the selection
    if (modelName === k) {
      setModelName("");
      // also remove canonical keys so predictions don't persist
      try {
        localStorage.removeItem("intuition-model.json");
        localStorage.removeItem("intuition-model-name");
      } catch {}
    }
    // bump version to force recomputation
    setModelVersion((v) => v + 1);
    // refresh the list
    refreshAvailableModels();
    // re-run simulation on updated model set
    recomputeRowsFromBars();
    setTimeout(() => {
      onSave();
    }, 0);
  }

  /**
   * Refresh the availableModels state.  This sorts the list by the savedAt
   * property descending so that the most recently saved model appears first.
   */
  function refreshAvailableModels() {
    const list = listAvailableModels();
    list.sort((a, b) => {
      const ta =
        (a.model as any).savedAt ?? (a.model as any).meta?.savedAt ?? 0;
      const tb =
        (b.model as any).savedAt ?? (b.model as any).meta?.savedAt ?? 0;
      return tb - ta;
    });
    setAvailableModels(list);
  }

  /**
   * Toggle the model dropdown.  When opening the dropdown, refresh the list
   * of available models.  When closing, simply hide the dropdown.  This
   * mirrors the backtest logic.
   */
  function handleModelChipClick() {
    if (!modelDropdownOpen) refreshAvailableModels();
    setModelDropdownOpen((v) => !v);
  }

  /**
   * Select a model by its localStorage key.  This loads the model from
   * storage, validates it, and, if valid, saves it under the canonical
   * key "intuition-model.json" so that the simulator picks it up.  The
   * model name is updated, the dropdown is closed, and the rows are
   * recomputed and simulation run.  If loading fails, the dropdown is
   * simply closed.
   */
  function selectModelKey(k: string) {
    try {
      const raw = localStorage.getItem(k);
      if (raw) {
        const j = JSON.parse(raw);
        const mm = coerceToIntuitionModel((j as any)?.model ?? j);
        if (mm) {
          try {
            localStorage.setItem("intuition-model.json", JSON.stringify(mm));
            localStorage.setItem("intuition-model-name", k);
          } catch {}
          setModelName(k);
          // bump the version to trigger prediction recomputation
          setModelVersion((v) => v + 1);
          setModelDropdownOpen(false);
          // Recompute rows and rerun the simulation
          recomputeRowsFromBars();
          setTimeout(() => {
            onSave();
          }, 0);
          return;
        }
      }
    } catch {}
    // Loading failed; simply close the dropdown
    setModelDropdownOpen(false);
  }

  // Trades
  const [pnlHistory, setPnlHistory] = useState<number[]>(() => {
    try {
      const s = localStorage.getItem("seasons.pnl");
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });
  const [trades, setTrades] = useState<Trade[]>([]);
  const [lockedTradeIdx, setLockedTradeIdx] = useState<number | null>(null);
  const [openTrade, setOpenTrade] = useState<OpenTrade>(null);

  const [saving, setSaving] = useState(false);

  const hoverSpring = {
    type: "spring",
    stiffness: 500,
    damping: 28,
    mass: 0.6,
  };

  const [flashMsg, setFlashMsg] = useState<string | null>(null);
  const [bottomToast, setBottomToast] = useState<string | null>(null);

  // Band hover state (for highlight color)
  const [hoverBand, setHoverBand] = useState<null | {
    type: LabelType;
    label: number | string;
  }>(null);

  // Hover highlight for open (active) trade card
  const [hoverOpenTrade, setHoverOpenTrade] = useState<boolean>(false);

  // NEW: closed pill hover countdown
  const [closedHover, setClosedHover] = useState(false);
  const [countdownText, setCountdownText] = useState<string>("");

  const onSave = useCallback(() => {
    setSaving(true);
    try {
      // Build config to persist
      const cfg = {
        timeModel,
        weatherModel,
        softLen,
        sharpLen,
        emaLen,
        refLen,
        sqzLen,
        timeSmcLen,
        buyEntry,
        buyExit,
        sellEntry,
        sellExit,
        stopLossUSD,
        takeProfitUSD,
        // lotSize removed
        // horizonBars removed from config
        dollarsPerPoint,
        // Persist advanced options settings
        minEntryMargin,
        minHoldMargin,
        hysteresisBars,
        // Persist the target range as two separate values (min and max)
        targetRangeMinBars,
        targetRangeMaxBars,
        pullToTargetPct,
        pushToTargetPct,
        minTradeLengthBars,
        maxTradeLengthBars,
        // trailingStop is not persisted; it is derived from trailDistancePts > 0
        trailDistancePts,
        bullBiasPct,
        bearBiasPct,
        sidewaysBiasPct,
      };

      // 1) Persist config + current pnl history
      try {
        localStorage.setItem("seasons.config", JSON.stringify(cfg));
        localStorage.setItem("seasons.pnl", JSON.stringify(pnlHistory));
      } catch {}

      // 2) Locally recompute labels from current bars (no setState race)
      const labeledRows = deriveLabelsFromOHLC(bars, {
        softLen,
        sharpLen,
        emaLen,
        refLen,
        sqzLen,
        timeSmcLen,
        timeModel,
        weatherModel,
      });
      setRows(labeledRows); // update UI

      // 3) Run simulation on the freshly labeled data
      // Always load predictions at run time so that newly uploaded models are
      // honoured.  If no predictions are available the simulator will
      // generate no trades.
      // Do not override the model‑derived margins when running the
      // simulation.  Passing null for predictions forces the simulator to
      // compute predictions from the loaded perceptron model.
      const sim = simulatePredictedTrades(labeledRows, {
        // Use the memoised margin predictions when available.  Passing
        // predictions aligns the simulator with the dynamic feature‑based
        // signal used for the bands.  When the array is empty the
        // simulator will fallback to computing its own margin.
        predictions:
          modelPredsMemo && modelPredsMemo.length > 0 ? modelPredsMemo : null,
        stopLossUSD: Number(stopLossUSD) || null,
        takeProfitUSD: Number(takeProfitUSD) || null,
        // lotSize removed
        minTradeLength: Number(minTradeLengthBars) || 0,
        // maxTradeLength: use the user‑specified maximum; there is no horizon fallback
        maxTradeLength: Number(maxTradeLengthBars) || 0,
        // Activate the trailing stop when the trail distance is greater than zero.
        trailingStop: Number(trailDistancePts) > 0,
        trailDistancePts: Number(trailDistancePts) || 0,
        bullBiasPct: Number(bullBiasPct) || 0,
        bearBiasPct: Number(bearBiasPct) || 0,
        sidewaysBiasPct: Number(sidewaysBiasPct) || 0,
        dollarsPerPoint: Number(dollarsPerPoint) || DOLLARS_PER_UNIT,
        // Backtest‑style advanced options
        minEntryMargin: Number(minEntryMargin) || 0,
        minHoldMargin: Number(minHoldMargin) || 0,
        hysteresisBars: Number(hysteresisBars) || 1,
        targetRangeMinBars: Number(targetRangeMinBars) || 1,
        targetRangeMaxBars:
          Number(targetRangeMaxBars) || Number(targetRangeMinBars) || 1,
        pullToTargetPct: Number(pullToTargetPct) || 0,
        pushToTargetPct: Number(pushToTargetPct) || 0,
      });
      setTrades(sim.trades);
      setOpenTrade(sim.openTrade);
      const pnls = sim.trades.map((t) => t.pnl);
      setPnlHistory(pnls);
      try {
        localStorage.setItem("seasons.pnl", JSON.stringify(pnls));
      } catch {}

      setFlashMsg("Ran Successfully");
      setBottomToast("Ran Successfully");
      setTimeout(() => setFlashMsg(null), 2000);
      setTimeout(() => setBottomToast(null), 2200);
    } finally {
      setSaving(false);
    }
  }, [
    // inputs it uses
    bars,
    timeModel,
    weatherModel,
    softLen,
    sharpLen,
    emaLen,
    refLen,
    sqzLen,
    timeSmcLen,
    stopLossUSD,
    takeProfitUSD,
    // horizonBars removed
    minTradeLengthBars,
    maxTradeLengthBars,
    trailDistancePts,
    bullBiasPct,
    bearBiasPct,
    sidewaysBiasPct,
    pnlHistory,
  ]);

  const bandStrokeColor = useMemo(() => {
    if (!hoverBand) return null;
    const { type, label } = hoverBand;
    if (type === "Season") return seasonColor(label);
    if (type === "Day") return dayColor(label);
    if (type === "Weather") return weatherColor(label);
    // New band types for model-based signals
    if (type === "Bull") return ARENA_GREEN;
    if (type === "Bear") return ARENA_RED;
    if (type === "Side") return ARENA_BLUE;
    return null;
  }, [hoverBand]);

  // Compute per‑bar opacities for the bullish, bearish and sideways signal bands.
  // Opacities are derived solely from model predictions.  When no predictions are
  // available, all bands remain transparent.  The values are normalised so that
  // predictions reaching the specified bias thresholds appear fully opaque.  These
  // values drive the gradient intensity of each band.
  const bandData = useMemo(() => {
    const count = rows.length;
    if (!count)
      return {
        bull: [] as number[],
        bear: [] as number[],
        side: [] as number[],
        norm: [] as number[],
      };
    // Compute opacities directly from model probabilities when a model is loaded.
    // If a model exists, derive bullish/bearish/sideways confidence at each
    // bar using the same softmax and bias blending used by the backtest.
    const model = loadIntuitionModelFromStorage();
    if (model && (model as any).heads) {
      // Use dynamic margin predictions derived from the full model weights.
      // We compute a signed margin for each bar using computeMarginPredictions
      // and then normalise the series to [-1,1].  This produces the same
      // signal that drives the simulator when predictions are provided via
      // the `predictions` option.
      const predsModel = computeMarginPredictions(model as any, rows) ?? [];
      // Align the prediction series to the current row count.
      let preds: number[] = [];
      if (predsModel.length >= count) {
        preds = predsModel.slice(predsModel.length - count);
      } else {
        const diff = count - predsModel.length;
        const firstVal = predsModel[0] ?? 0;
        preds = new Array(diff).fill(firstVal).concat(predsModel);
      }
      // Normalise the predictions for threshold scaling.
      const maxAbs = preds.reduce((m, v) => Math.max(m, Math.abs(v)), 0) || 1;
      const norm = preds.map((p) => (p === 0 ? 0 : p / maxAbs));
      const bullThresh = (Number(bullBiasPct) ?? 0) / 100;
      const bearThresh = (Number(bearBiasPct) ?? 0) / 100;
      const sideThresh = (Number(sidewaysBiasPct) ?? 0) / 100;
      const bullOps: number[] = [];
      const bearOps: number[] = [];
      const sideOps: number[] = [];
      for (let i = 0; i < count; i++) {
        const p = norm[i];
        const bullScore = Math.max(p, 0);
        const bearScore = Math.max(-p, 0);
        const sideScore = 1 - Math.abs(p);
        const bullOpacity =
          bullThresh > 0 ? Math.min(bullScore / bullThresh, 1) : bullScore;
        const bearOpacity =
          bearThresh > 0 ? Math.min(bearScore / bearThresh, 1) : bearScore;
        const ratio =
          sideThresh > 0 ? Math.min(sideScore / sideThresh, 1) : sideScore;
        const sideOpacity = 1 - ratio;
        bullOps.push(Number.isFinite(bullOpacity) ? bullOpacity : 0);
        bearOps.push(Number.isFinite(bearOpacity) ? bearOpacity : 0);
        sideOps.push(Number.isFinite(sideOpacity) ? sideOpacity : 0);
      }
      return { bull: bullOps, bear: bearOps, side: sideOps, norm };
    }
    // Otherwise fall back to the legacy margin-based opacities using the memoised predictions.
    const modelPreds = modelPredsMemo;
    if (!modelPreds || modelPreds.length === 0) {
      return {
        bull: new Array(count).fill(0),
        bear: new Array(count).fill(0),
        side: new Array(count).fill(0),
        norm: new Array(count).fill(0),
      };
    }
    // Align prediction series to rows length
    let preds: number[] = [];
    if (modelPreds.length >= count) {
      preds = modelPreds.slice(modelPreds.length - count);
    } else {
      const diff = count - modelPreds.length;
      const firstVal = modelPreds[0] ?? 0;
      preds = new Array(diff).fill(firstVal).concat(modelPreds);
    }
    // Normalise predictions for threshold scaling
    const maxAbs = preds.reduce((m, v) => Math.max(m, Math.abs(v)), 0) || 1;
    const norm = preds.map((p) => (p === 0 ? 0 : p / maxAbs));
    const bullThresh = (Number(bullBiasPct) ?? 0) / 100;
    const bearThresh = (Number(bearBiasPct) ?? 0) / 100;
    const sideThresh = (Number(sidewaysBiasPct) ?? 0) / 100;
    const bullOps: number[] = [];
    const bearOps: number[] = [];
    const sideOps: number[] = [];
    for (let i = 0; i < count; i++) {
      const p = norm[i];
      const bullScore = Math.max(p, 0);
      const bearScore = Math.max(-p, 0);
      const sideScore = 1 - Math.abs(p);
      const bullOpacity =
        bullThresh > 0 ? Math.min(bullScore / bullThresh, 1) : 0;
      const bearOpacity =
        bearThresh > 0 ? Math.min(bearScore / bearThresh, 1) : 0;
      const ratio = sideThresh > 0 ? Math.min(sideScore / sideThresh, 1) : 0;
      const sideOpacity = 1 - ratio;
      bullOps.push(Number.isFinite(bullOpacity) ? bullOpacity : 0);
      bearOps.push(Number.isFinite(bearOpacity) ? bearOpacity : 0);
      sideOps.push(Number.isFinite(sideOpacity) ? sideOpacity : 0);
    }
    return { bull: bullOps, bear: bearOps, side: sideOps, norm };
  }, [rows, bullBiasPct, bearBiasPct, sidewaysBiasPct, modelPredsMemo]);

  const [bandTip, setBandTip] = useState<{
    show: boolean;
    x: number;
    y: number;
    text: string;
    owner?: LabelType;
  }>({ show: false, x: 0, y: 0, text: "", owner: undefined });
  const bandsWrapRef = useRef<HTMLDivElement | null>(null);

  // Typography & style injection (+ dark overrides)
  useEffect(() => {
    const id = "arena-font-inject";
    let style = document.getElementById(id) as HTMLStyleElement | null;
    if (!style) {
      style = document.createElement("style");
      style.id = id;
      document.head.appendChild(style);
    }
    style.innerHTML = `
    @import url('https://fonts.googleapis.com/css2?family=Archivo:wght@400;600;700;800&display=swap');
    :root { --arena-green:${ARENA_GREEN}; --arena-red:${ARENA_RED}; --arena-blue:${ARENA_BLUE}; --arena-gray:${ARENA_GRAY}; }
    body { font-family: "Archivo", system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, "Noto Sans", "Apple Color Emoji","Segoe UI Emoji", "Segoe UI Symbol"; color: ${ARENA_DARK}; }
    .arena-strong { font-weight: 800; letter-spacing: .2px; }
    .arena-pill { border-radius: 9999px; font-weight: 700; }
    @keyframes pillGlow { 0%{ box-shadow:0 0 0 0 rgba(22,199,132,.45);} 50%{ box-shadow:0 0 18px 6px rgba(22,199,132,.35);} 100%{ box-shadow:0 0 0 0 rgba(22,199,132,.45);} }
    .live-pill { animation: pillGlow 1.6s ease-in-out infinite; }
    #hoverGlow feGaussianBlur { stdDeviation: 1.6; }
    @keyframes priceBlink { 0%,49%{ opacity:.4 } 50%,100%{ opacity:1 } }
    .price-dot  { filter:url(#priceGlow);  animation: priceBlink 1.2s steps(2,end) infinite; }
    .price-ring { filter:url(#priceGlow);  animation: priceBlink 1.2s steps(2,end) infinite; }
    @keyframes pnlGlow { 0%{ text-shadow:0 0 0 rgba(0,0,0,0);} 50%{ text-shadow:0 0 14px rgba(0,0,0,.18);} 100%{ text-shadow:0 0 0 rgba(0,0,0,0);} }
    .pnl-hero { font-weight:800; animation:pnlGlow 1.6s ease-in-out infinite; }
    #seasons-app.dark { background:#0b0d0f; color:#e5e7eb; }
    #seasons-app.dark .bg-white { background-color:#0f1113 !important; }
    #seasons-app.dark .border-neutral-200 { border-color:#1f2937 !important; }
    #seasons-app.dark .text-neutral-900 { color:#f3f4f6 !important; }
    #seasons-app.dark .text-neutral-800 { color:#e5e7eb !important; }
    #seasons-app.dark .text-neutral-700 { color:#d1d5db !important; }
    #seasons-app.dark .text-neutral-600 { color:#cbd5e1 !important; }
    #seasons-app.dark .text-neutral-500 { color:#9ca3af !important; }
    #seasons-app.dark .bg-neutral-100 { background-color:#0f172a !important; }
    #seasons-app.dark .bg-blue-50\\/40 { background-color:rgba(59,130,246,0.15) !important; }
    #seasons-app.dark .bg-emerald-50, #seasons-app.dark .bg-rose-50, #seasons-app.dark .bg-purple-50 { background-color: rgba(255,255,255,0.06) !important; }
    #seasons-app.dark .shadow { box-shadow: 0 8px 24px rgba(0,0,0,.45) !important; }
    .history-card.gain { background:#ecfdf5; border-color:#6ee7b7; }
    .history-card.loss { background:#fef2f2; border-color:#fca5a5; }
    #seasons-app.dark .history-card.gain { background: rgba(22,199,132,0.10); border-color: rgba(22,199,132,0.45); }
    #seasons-app.dark .history-card.loss { background: rgba(234,57,67,0.10); border-color: rgba(234,57,67,0.45); }
    #seasons-app.dark .history-card .text-neutral-700,
    #seasons-app.dark .history-card .text-neutral-600,
    #seasons-app.dark .history-card .text-neutral-500 { color:#e5e7eb !important; }
    /* Styles for the custom dual‑range slider used for Target Range (bars).
       We increase the thickness of the slider track and enlarge the
       circular thumb to better match the Alpha Arena aesthetic shown in the
       reference image.  The track itself remains transparent; the coloured
       bar between the two thumbs is drawn separately via targetRangeTrackStyle. */
    .multi-range-slider input[type='range'] {
      -webkit-appearance: none;
      width: 100%;
      height: 8px;
      background: transparent;
      cursor: pointer;
    }
    .multi-range-slider input[type='range']::-webkit-slider-runnable-track {
      height: 8px;
      background: transparent;
    }
    .multi-range-slider input[type='range']::-moz-range-track {
      height: 8px;
      background: transparent;
    }
    .multi-range-slider input[type='range']::-webkit-slider-thumb {
      -webkit-appearance: none;
      height: 20px;
      width: 20px;
      border-radius: 9999px;
      background: #0f1113;
      border: 3px solid #16C784;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .multi-range-slider input[type='range']::-moz-range-thumb {
      height: 20px;
      width: 20px;
      border-radius: 9999px;
      background: #0f1113;
      border: 3px solid #16C784;
      box-sizing: border-box;
      pointer-events: auto;
    }
    .multi-range-slider input[type='range']::-ms-thumb {
      height: 20px;
      width: 20px;
      border-radius: 9999px;
      background: #0f1113;
      border: 3px solid #16C784;
      box-sizing: border-box;
      pointer-events: auto;
    }
  `;
  }, []);

  const recomputeRowsFromBars = useCallback(() => {
    const labeled = deriveLabelsFromOHLC(bars, {
      softLen,
      sharpLen,
      emaLen,
      refLen,
      sqzLen,
      timeSmcLen,
      timeModel,
      weatherModel,
    });
    setRows(labeled);
  }, [
    bars,
    softLen,
    sharpLen,
    emaLen,
    refLen,
    sqzLen,
    timeSmcLen,
    timeModel,
    weatherModel,
  ]);

  // Load config/theme
  useEffect(() => {
    try {
      const s = localStorage.getItem("seasons.config");
      if (s) {
        const cfg = JSON.parse(s);
        setTimeModel(cfg.timeModel ?? "Momentum");
        setWeatherModel(cfg.weatherModel ?? "Heikin Ashi");
        setSoftLen(cfg.softLen ?? 12);
        setSharpLen(cfg.sharpLen ?? 24);
        setEmaLen(cfg.emaLen ?? 50);
        setRefLen(cfg.refLen ?? 13);
        setSqzLen(cfg.sqzLen ?? 5);
        setTimeSmcLen(cfg.timeSmcLen ?? 6);
        setBuyEntry(cfg.buyEntry ?? []);
        setBuyExit(cfg.buyExit ?? []);
        setSellEntry(cfg.sellEntry ?? []);
        setSellExit(cfg.sellExit ?? []);
        setStopLossUSD(cfg.stopLossUSD ?? "");
        setTakeProfitUSD(cfg.takeProfitUSD ?? "");
        // lotSize is no longer persisted or restored
        // horizonBars removed; do not restore from config
        // Load advanced options values if present
        setMinEntryMargin(cfg.minEntryMargin ?? 0);
        setMinHoldMargin(cfg.minHoldMargin ?? 0);
        setHysteresisBars(cfg.hysteresisBars ?? 0);
        // Restore target range slider (min and max).  Defaults to 10–60 bars
        setTargetRangeMinBars(cfg.targetRangeMinBars ?? 10);
        setTargetRangeMaxBars(cfg.targetRangeMaxBars ?? 60);
        setPullToTargetPct(cfg.pullToTargetPct ?? 0);
        setPushToTargetPct(cfg.pushToTargetPct ?? 0);
        setMinTradeLengthBars(cfg.minTradeLengthBars ?? 0);
        setMaxTradeLengthBars(cfg.maxTradeLengthBars ?? 0);
        // trailingStop flag is derived from trailDistancePts; do not restore from config
        setTrailDistancePts(cfg.trailDistancePts ?? 0);
        setBullBiasPct(cfg.bullBiasPct ?? 50);
        setBearBiasPct(cfg.bearBiasPct ?? 50);
        setSidewaysBiasPct(cfg.sidewaysBiasPct ?? 50);
        // Load the saved dollarsPerPoint if present; otherwise use the default DOLLARS_PER_UNIT.
        setDollarsPerPoint(cfg.dollarsPerPoint ?? DOLLARS_PER_UNIT);
      }
      const theme = localStorage.getItem("seasons.theme");
      if (theme === "dark") setDark(true);
    } catch {}
  }, []);

  // ====== Data bootstrap from cache (REFILTER) ======
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LS_CACHED_BARS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length) {
          const filtered = parsed.filter((p: any) =>
            isTradingSessionUTC(new Date(p.timeMs))
          );
          setBars(filtered);
        }
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!bars.length) {
      setRows([]);
      return;
    }
    recomputeRowsFromBars();
  }, [bars, recomputeRowsFromBars]);

  // ====== Fetch with 5-min throttle + session-aware guard + occasional catch-up while closed ======
  useEffect(() => {
    let alive = true;

    const doFetch = async () => {
      // Try up to N keys before giving up
      let attempts = 0;
      let lastErr: any = null;

      while (attempts < TD_KEYS.length) {
        const apiKey = pickKey();
        try {
          setLoading(true);
          const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(
            SYMBOL
          )}&interval=${INTERVAL}&outputsize=${LOOKBACK_BARS}&timezone=UTC&format=JSON&apikey=${apiKey}`;

          const r = await fetch(url);
          // If HTTP rate limit or other network error, rotate
          if (!r.ok) {
            // advance to the next key and try again
            lastErr = new Error(`HTTP ${r.status} ${r.statusText}`);
            advanceKey();
            attempts++;
            continue;
          }

          const j = await r.json();

          // TwelveData can return objects like { code:429, message:"..." } or { status:"error", message:"..." }
          const isError =
            !j ||
            (!!j.status && String(j.status).toLowerCase() === "error") ||
            (!!j.code && Number(j.code) !== 0 && !j.values) ||
            !j.values;

          if (isError) {
            lastErr = new Error(j?.message || "Bad response");
            // rotate to next key and retry
            advanceKey();
            attempts++;
            continue;
          }

          // Good response -> parse, cache, advance key (to spread usage), and return
          const parsedRaw = j.values
            .map((v: any) => ({
              // parse as true UTC
              timeMs: toMs(v.datetime),
              open: Number(v.open),
              high: Number(v.high),
              low: Number(v.low),
              close: Number(v.close),
            }))
            .sort((a: any, b: any) => a.timeMs - b.timeMs);

          // Filter by UTC session window (keeps Sun earlier reopen, drops Sat + Fri after close)
          const parsed = parsedRaw.filter((p: any) =>
            isTradingSessionUTC(new Date(p.timeMs))
          );

          setBars(parsed);
          setErr(null);

          // cache filtered bars
          try {
            localStorage.setItem(LS_CACHED_BARS, JSON.stringify(parsed));
            localStorage.setItem(LS_LAST_FETCH, String(Date.now()));
          } catch {}

          // Success: move pointer forward so next call uses the next key
          advanceKey();

          return; // done
        } catch (e: any) {
          lastErr = e;
          // rotate and try next key
          advanceKey();
          attempts++;
          continue;
        } finally {
          setLoading(false);
        }
      }

      // If we exhausted all keys:
      setErr(lastErr?.message || "Failed to load data (all API keys tried)");
    };

    // Controller that decides if we should fetch
    const maybeFetch = async () => {
      const now = new Date();
      const sessionOpen = isTradingSessionUTC(now); // session-aware
      // Throttle: only if >= 5 minutes since last fetch
      let lastFetch = 0;
      try {
        const s = localStorage.getItem(LS_LAST_FETCH);
        lastFetch = s ? Number(s) : 0;
      } catch {}
      const due = Date.now() - lastFetch >= 5 * 60 * 1000;

      if (sessionOpen) {
        if (due) await doFetch();
        return;
      }

      // While closed: occasional catch-up
      const haveBars = bars.length > 0;
      const tooOld =
        haveBars &&
        Date.now() - Number(bars[bars.length - 1].timeMs) > 6 * 60 * 60 * 1000;
      const weekendCatchupDue = Date.now() - lastFetch >= 12 * 60 * 60 * 1000;

      if ((!haveBars || tooOld) && weekendCatchupDue) {
        await doFetch(); // one catch-up call
      }
    };

    // initial call
    maybeFetch();

    // Periodic check (every minute) — obeys 5-min throttle & session rules
    const id = setInterval(maybeFetch, 60_000);

    return () => {
      alive = false;
      clearInterval(id);
    };
  }, [bars.length]);

  // X data (1:1 index mapping)
  const chartData = useMemo(() => {
    return rows.map((r, i) => ({
      x: i, // true index
      price: r.close,
      t: r.timeMs,
      Season: r.Season,
      Day: r.Day,
      Weather: r.Weather,
      high: r.high,
      low: r.low,
      open: r.open,
      close: r.close,
      idx: i,
    }));
  }, [rows]);

  const yDomain = useMemo<[number, number]>(() => {
    if (!rows.length) return [0, 1];
    let min = Infinity;
    let max = -Infinity;
    for (const r of rows) {
      if (r.low < min) min = r.low;
      if (r.high > max) max = r.high;
    }
    const pad = (max - min) * 0.02 || 1;
    return [min - pad, max + pad];
  }, [rows]);

  const last = rows[rows.length - 1];
  const candleUp = last ? last.close >= last.open : false;

  // Hover highlight data for bands
  // Hover highlight data for bands — extend 1 bar past each run end
  const highlightedData = useMemo(() => {
    if (!hoverBand || !chartData.length) return null;

    const key = hoverBand.type as "Season" | "Day" | "Weather";
    const val = hoverBand.label;

    // Indices to keep visible in the overlay line
    const keep = new Set<number>();

    for (let i = 0; i < chartData.length; i++) {
      const cur = Number(chartData[i][key]);
      const prev = i > 0 ? Number(chartData[i - 1][key]) : NaN;

      // Normal: keep bars that match the hovered label
      if (cur === val) {
        keep.add(i);
        continue;
      }

      // NEW: extend one bar *after* a run ends (prev matched, current doesn't)
      if (i > 0 && prev === val && cur !== val) {
        keep.add(i);
      }
    }

    // Build an overlay dataset that nulls out everything except the kept indices
    return chartData.map((d, i) =>
      keep.has(i) ? d : { ...d, price: null as any }
    );
  }, [hoverBand, chartData]);

  // Locked trade for highlight (from history list)
  const activeTrade = useMemo(() => {
    if (!trades.length) return null;
    if (lockedTradeIdx != null) return trades[lockedTradeIdx];
    return null;
  }, [trades, lockedTradeIdx]);

  // === Live PnL updater ===
  useEffect(() => {
    if (!openTrade || !rows.length) return;
    const lastClose = rows[rows.length - 1].close;
    // Calculate dollars per unit using the user‑configurable dollarsPerPoint
    // multiplier instead of the fixed DOLLARS_PER_UNIT constant.  If the
    // input is invalid it falls back to the constant for safety.
    // Dollars per unit no longer multiplies by lotSize; risk is solely scaled via dollarsPerPoint
    const DPU = Number(dollarsPerPoint) || DOLLARS_PER_UNIT;
    const unreal =
      (openTrade.side === "BUY"
        ? lastClose - openTrade.entryPrice
        : openTrade.entryPrice - lastClose) * DPU;
    setOpenTrade((prev) =>
      prev
        ? {
            ...prev,
            unrealized: Math.round(unreal * 100) / 100,
          }
        : prev
    );
  }, [rows, dollarsPerPoint]);

  // Center-row message
  const centerRowNode = useMemo(() => {
    if (openTrade) {
      const positive = openTrade.unrealized >= 0;
      const color = positive ? ARENA_GREEN : ARENA_RED;
      return (
        <span className="pnl-hero arena-strong" style={{ color }}>
          In Trade: {openTrade.side} • PnL {positive ? "+" : "-"}$
          {Math.abs(openTrade.unrealized).toFixed(2)}
        </span>
      );
    }
    return (
      <span
        className="arena-strong text-sm"
        style={{ color: dark ? "#e5e7eb" : "#111827" }}
      >
        No Current Trade Active
      </span>
    );
  }, [openTrade, dark]);

  // Axis & chart colors by theme
  const axisTickColor = dark ? "#d1d5db" : "#6b7280";
  const gridStroke = dark ? "#374151" : "#eeeeee";
  const priceStroke = dark ? "#ffffff" : "#000000";
  const dotColor = dark ? "#ffffff" : "#000000";

  const lastIdx = rows.length - 1;

  // Live vs Closed pill state (aligned to UTC session status)
  const marketClosed = !isTradingSessionUTC(new Date());
  const nextOpenDate = nextMarketOpen(new Date());

  useEffect(() => {
    if (!marketClosed || !closedHover) return;
    // Update countdown while hovering
    const update = () => {
      const msLeft = +nextOpenDate - Date.now();
      setCountdownText(formatDHMS(msLeft));
    };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, [marketClosed, closedHover, nextOpenDate]);
  // === PART 4/4 ===
  return (
    <div
      id="seasons-app"
      className={dark ? "dark min-h-screen" : "min-h-screen"}
    >
      {/* Header */}
      <header className="border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-5 py-6">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <h1 className="text-2xl arena-strong">Live Dashboard</h1>
              {/* Model and bar count pills.  Each pill has a coloured background and border
                  indicating whether the associated value is loaded (green) or missing (red).
                  In dark mode the colours use slightly higher opacity for contrast. */}
              <div
                className="flex items-center gap-2 ml-2"
                style={{ position: "relative" }}
              >
                {/* Model pill */}
                <span
                  className="px-2 py-0.5 rounded-md text-xs font-bold border"
                  onClick={handleModelChipClick}
                  style={{
                    background: modelLoaded
                      ? dark
                        ? `${ARENA_GREEN}33`
                        : `${ARENA_GREEN}20`
                      : dark
                      ? `${ARENA_RED}33`
                      : `${ARENA_RED}20`,
                    borderColor: modelLoaded
                      ? `${ARENA_GREEN}55`
                      : `${ARENA_RED}55`,
                    color: modelLoaded ? ARENA_GREEN : ARENA_RED,
                    cursor: "pointer",
                  }}
                >
                  Model: {modelDisplayName}
                </span>
                {modelDropdownOpen && (
                  <div
                    style={{
                      position: "absolute",
                      top: "100%",
                      right: 0,
                      marginTop: 4,
                      background: dark ? "#0f172a" : "#f1f5f9",
                      border: "1px solid #334155",
                      borderRadius: 4,
                      minWidth: "160px",
                      zIndex: 30,
                      maxHeight: "200px",
                      overflowY: "auto",
                      boxShadow: "0 4px 8px rgba(0,0,0,0.4)",
                    }}
                  >
                    {availableModels.map((m) => (
                      <div
                        key={m.key}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center",
                          padding: "6px 12px",
                          whiteSpace: "nowrap",
                          cursor: "pointer",
                          color: dark ? "#f1f5f9" : "#0f172a",
                        }}
                        className="dropdown-item"
                      >
                        <span
                          onClick={() => selectModelKey(m.key)}
                          style={{ flexGrow: 1 }}
                        >
                          {m.key}
                        </span>
                        <span
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteModelKey(m.key);
                          }}
                          style={{
                            marginLeft: 8,
                            color: dark ? "#ef4444" : "#b91c1c",
                            cursor: "pointer",
                            fontWeight: 700,
                          }}
                          title="Delete model"
                        >
                          ×
                        </span>
                      </div>
                    ))}
                    {availableModels.length === 0 && (
                      <div
                        style={{
                          padding: "6px 12px",
                          color: dark ? "#94a3b8" : "#4b5563",
                        }}
                      >
                        No models found
                      </div>
                    )}
                    {/* Upload model action within dropdown */}
                    <div
                      onClick={() => {
                        if (fileInputRef.current) fileInputRef.current.click();
                      }}
                      style={{
                        padding: "6px 12px",
                        cursor: "pointer",
                        borderTop: "1px solid #334155",
                        color: dark ? "#93c5fd" : "#1e40af",
                      }}
                    >
                      Upload Model...
                    </div>
                  </div>
                )}
                {/* Bars pill */}
                <span
                  className="px-2 py-0.5 rounded-md text-xs font-bold border"
                  style={{
                    background:
                      rows.length > 0
                        ? dark
                          ? `${ARENA_GREEN}33`
                          : `${ARENA_GREEN}20`
                        : dark
                        ? `${ARENA_RED}33`
                        : `${ARENA_RED}20`,
                    borderColor:
                      rows.length > 0 ? `${ARENA_GREEN}55` : `${ARENA_RED}55`,
                    color: rows.length > 0 ? ARENA_GREEN : ARENA_RED,
                  }}
                >
                  Bars: {rows.length}
                </span>
              </div>
              {false && (
                <div className="flex items-center gap-2">
                  <span
                    className="px-2 py-0.5 rounded-md text-xs font-bold border"
                    style={{
                      background: `${seasonColor(
                        rows[rows.length - 1].Season
                      )}20`,
                      borderColor: `${seasonColor(
                        rows[rows.length - 1].Season
                      )}55`,
                    }}
                  >
                    {SEASON_LABELS[rows[rows.length - 1].Season]}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded-md text-xs font-bold border"
                    style={{
                      background: `${dayColor(rows[rows.length - 1].Day)}20`,
                      borderColor: `${dayColor(rows[rows.length - 1].Day)}55`,
                    }}
                  >
                    {DAY_LABELS[rows[rows.length - 1].Day]}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded-md text-xs font-bold border"
                    style={{
                      background: `${weatherColor(
                        rows[
                          rows[rows.length - 1].Weather ? rows.length - 1 : 0
                        ].Weather
                      )}20`,
                      borderColor: `${weatherColor(
                        rows[rows.length - 1].Weather
                      )}55`,
                    }}
                  >
                    {WEATHER_LABELS[rows[rows.length - 1].Weather]}
                  </span>
                </div>
              )}
            </div>

            {/* Top-right: Clocks + Theme switch */}
            <div className="flex items-center gap-3">
              <LiveClocks dark={dark} />
              <motion.button
                onClick={() =>
                  setDark((d) => {
                    const next = !d;
                    try {
                      localStorage.setItem(
                        "seasons.theme",
                        next ? "dark" : "light"
                      );
                    } catch {}
                    return next;
                  })
                }
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="px-3 py-1 rounded-xl text-sm border"
              >
                {dark ? "Light Mode" : "Dark Mode"}
              </motion.button>
            </div>
          </div>

          {flashMsg && (
            <div className="mt-2 inline-flex items-center gap-2 text-xs px-2 py-1 rounded-lg bg-neutral-100 text-neutral-800 border border-neutral-200">
              {flashMsg}
            </div>
          )}
        </div>
      </header>

      {/* Only render a single toast via the portal to avoid duplicates */}
      <ToastPortal message={bottomToast} />

      <main className="max-w-7xl mx-auto px-5 py-6 grid grid-cols-12 gap-6">
        {/* LEFT: Chart */}
        <section className="col-span-12 lg:col-span-8">
          <div className="p-4 rounded-2xl bg-white border border-neutral-200 relative">
            {/* Row with Title | Center Status | Market Closed pill + price */}
            <div className="grid grid-cols-3 items-center mb-3">
              <div className="text-base font-extrabold">
                GOLD (XAUUSD) — 15m
              </div>
              <div className="justify-self-center">{centerRowNode}</div>
              <div className="justify-self-end flex items-center gap-3">
                {!marketClosed ? (
                  <span className="live-pill arena-pill text-[10px] px-2 py-0.5 bg-[var(--arena-green)] text-white">
                    LIVE
                  </span>
                ) : (
                  <span
                    className={`arena-pill text-[10px] px-2 py-0.5 ${
                      dark
                        ? "bg-neutral-800 text-neutral-200 border border-neutral-700"
                        : "bg-neutral-200 text-neutral-800 border border-neutral-300"
                    }`}
                    onMouseEnter={() => setClosedHover(true)}
                    onMouseLeave={() => setClosedHover(false)}
                    title=""
                    style={{ cursor: "help" }}
                  >
                    Market Closed
                  </span>
                )}
                {last && (
                  <div
                    className="text-xl arena-strong"
                    style={{ color: candleUp ? ARENA_GREEN : ARENA_RED }}
                    title={`Latest update — UTC: ${formatStamp(
                      last.timeMs,
                      "UTC"
                    )} • Local: ${formatStamp(last.timeMs, "LOCAL")}`}
                  >
                    ${fmtPrice2.format(last.close)}
                  </div>
                )}
              </div>

              {/* Hover tooltip for Market Closed pill */}
              {marketClosed && closedHover && (
                <div
                  className={`absolute right-4 top-10 z-20 text-xs px-2 py-1 rounded-md shadow ${
                    dark
                      ? "bg-neutral-800 text-neutral-100 border border-neutral-700"
                      : "bg-white text-neutral-800 border border-neutral-200"
                  }`}
                >
                  Reopens in {countdownText}
                </div>
              )}
            </div>

            <div className="h-80 relative">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={CHART_MARGINS}>
                  <defs>
                    <filter
                      id="hoverGlow"
                      x="-50%"
                      y="-50%"
                      width="200%"
                      height="200%"
                    >
                      <feGaussianBlur stdDeviation="1.6" result="b" />
                      <feMerge>
                        <feMergeNode in="b" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                    <filter
                      id="priceGlow"
                      x="-50%"
                      y="-50%"
                      width="200%"
                      height="200%"
                    >
                      <feGaussianBlur stdDeviation="4" result="g" />
                      <feMerge>
                        <feMergeNode in="g" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                  </defs>

                  <CartesianGrid stroke={gridStroke} />
                  <XAxis
                    dataKey="x"
                    type="number"
                    domain={[0, Math.max(0, chartData.length - 1)]}
                    hide
                  />
                  <YAxis
                    width={Y_AXIS_WIDTH}
                    domain={yDomain}
                    allowDataOverflow
                    tickMargin={6}
                    tick={{ fontSize: 10, fill: axisTickColor }}
                    tickFormatter={(v) => fmtPrice0.format(Number(v))}
                  />
                  <Tooltip
                    content={(p) => (
                      <CustomTooltip {...p} rows={rows} dark={dark} />
                    )}
                    wrapperStyle={{ outline: "none" }}
                  />

                  {/* Active-trade highlight from history (locked) */}
                  {activeTrade && (
                    <ReferenceArea
                      x1={activeTrade.entryIdx}
                      x2={activeTrade.exitIdx}
                      strokeOpacity={0}
                      fill="#fde68a"
                      fillOpacity={0.22}
                    />
                  )}

                  {/* Open (current) trade hover highlight from Active card */}
                  {openTrade && hoverOpenTrade && (
                    <ReferenceArea
                      x1={openTrade.entryIdx}
                      x2={rows.length - 1}
                      strokeOpacity={0}
                      fill="#fde68a"
                      fillOpacity={0.22}
                    />
                  )}

                  {/* Base price line — bold & theme-aware */}
                  <Line
                    type="monotone"
                    dataKey="price"
                    dot={false}
                    stroke={priceStroke}
                    strokeWidth={3.2}
                    isAnimationActive={false}
                  />

                  {/* Hover highlight for label bands */}
                  {highlightedData && (
                    <Line
                      type="monotone"
                      data={highlightedData}
                      dataKey="price"
                      dot={false}
                      stroke={bandStrokeColor || (dark ? "#fff" : "#000")}
                      strokeWidth={2.6}
                      strokeOpacity={0.85}
                      isAnimationActive={false}
                      style={{ filter: "url(#hoverGlow)" }}
                    />
                  )}

                  {/* Current price dot — theme-aware */}
                  {last && (
                    <>
                      <ReferenceDot
                        className="price-dot"
                        x={chartData.length - 1}
                        y={last.close}
                        r={6.5}
                        fill={dotColor}
                        isFront
                      />
                      <ReferenceDot
                        className="price-ring"
                        x={chartData.length - 1}
                        y={last.close}
                        r={9}
                        fillOpacity={0}
                        stroke={dotColor}
                        strokeOpacity={0.5}
                        isFront
                      />
                    </>
                  )}
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* COLOR BANDS — aligned with plot area */}
            {rows.length > 0 && (
              <div
                className="mt-3 space-y-2 relative z-10"
                ref={bandsWrapRef}
                onMouseMove={(e) => {
                  if (!bandTip.show) return;
                  const rect = bandsWrapRef.current!.getBoundingClientRect();
                  setBandTip((s) => ({
                    ...s,
                    x: e.clientX - rect.left + 12,
                    y: e.clientY - rect.top + 12,
                  }));
                }}
                style={{
                  paddingLeft: CHART_MARGINS.left + Y_AXIS_WIDTH,
                  paddingRight: CHART_MARGINS.right,
                }}
              >
                {(["Bull", "Bear", "Side"] as LabelType[]).map((type) => (
                  <div
                    key={type}
                    className="relative w-full h-6 rounded overflow-visible border border-neutral-200 flex"
                    onMouseLeave={() => {
                      setHoverBand(null);
                      setBandTip((s) => ({
                        ...s,
                        show: false,
                        owner: undefined,
                      }));
                    }}
                  >
                    {rows.map((r, i) => {
                      // Determine the opacity for each band type
                      let opacity = 0;
                      if (type === "Bull") opacity = bandData.bull[i] ?? 0;
                      else if (type === "Bear") opacity = bandData.bear[i] ?? 0;
                      else opacity = bandData.side[i] ?? 0;
                      // Determine colour for each band type.  Bullish bands
                      // use the arena green, bearish bands use red and sideways
                      // bands use a neutral grey.  Sideways bands transition
                      // from transparent (low confidence) to grey (high
                      // confidence) via the opacity value.
                      const color =
                        type === "Bull"
                          ? ARENA_GREEN
                          : type === "Bear"
                          ? ARENA_RED
                          : ARENA_GRAY;
                      // Determine active state (highlight on hover)
                      const active = hoverBand && hoverBand.type === type;
                      // Tooltip text includes model confidence and timestamps
                      const conf = Math.abs(bandData.norm?.[i] ?? 0);
                      const text = `${
                        type === "Bull"
                          ? "Bullish"
                          : type === "Bear"
                          ? "Bearish"
                          : "Sideways"
                      }\nConfidence: ${(conf * 100).toFixed(
                        1
                      )}%\nUTC: ${formatStamp(
                        r.timeMs,
                        "UTC"
                      )}\nLocal: ${formatStamp(r.timeMs, "LOCAL")}`;
                      return (
                        <div
                          key={`${type}-${i}`}
                          style={{
                            width: `${100 / rows.length}%`,
                            background: color,
                            opacity: hoverBand
                              ? active
                                ? opacity
                                : opacity * 0.65
                              : opacity,
                            cursor: "crosshair",
                          }}
                          onMouseEnter={(e) => {
                            setHoverBand({ type, label: type });
                            const rect =
                              bandsWrapRef.current!.getBoundingClientRect();
                            setBandTip({
                              show: true,
                              x: e.clientX - rect.left + 12,
                              y: e.clientY - rect.top + 12,
                              text,
                              owner: type,
                            });
                          }}
                          title=""
                        />
                      );
                    })}
                    {bandTip.show && bandTip.owner === type && (
                      <div
                        className="pointer-events-none absolute z-20 px-2 py-1 rounded-md text-xs bg-black text-white shadow"
                        style={{
                          left: bandTip.x,
                          top: bandTip.y,
                          whiteSpace: "pre-line",
                        }}
                      >
                        {bandTip.text}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* RIGHT: Recent History (Alpha Arena style) */}
        <aside className="col-span-12 lg:col-span-4">
          <div className="p-4 rounded-2xl bg-white border border-neutral-200 h-full flex flex-col">
            <div className="text-lg font-extrabold mb-2">RECENT HISTORY</div>

            {/* Active Trade card (hover highlights chart span) */}
            {openTrade && (
              <div
                className="mb-3 px-3 py-2 rounded-xl border-2 border-[var(--arena-blue)] bg-blue-50/40"
                onMouseEnter={() => setHoverOpenTrade(true)}
                onMouseLeave={() => setHoverOpenTrade(false)}
              >
                <div className="flex items-center justify-between">
                  <div className="arena-strong">ACTIVE TRADE</div>
                  <div
                    className="arena-strong"
                    style={{
                      color:
                        openTrade.unrealized >= 0 ? ARENA_GREEN : ARENA_RED,
                    }}
                  >
                    {openTrade.side} • {openTrade.unrealized >= 0 ? "+" : "-"}$
                    {Math.abs(openTrade.unrealized).toFixed(2)}
                  </div>
                </div>
                <div className="mt-1 grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-neutral-700">
                  <div>Entry: ${openTrade.entryPrice.toFixed(2)}</div>
                  <div>
                    Exit: <em>TBD</em>
                  </div>
                  <div>
                    Started:{" "}
                    {formatLocalShort(rows[openTrade.entryIdx]?.timeMs)}
                  </div>
                  <div>
                    Ends: <em>TBD</em>
                  </div>
                </div>
              </div>
            )}

            {trades.length === 0 && (
              <div className="text-sm text-neutral-500 mb-2">
                No trades from current settings.
              </div>
            )}

            <div className="overflow-auto max-h-[48vh] pr-1 space-y-2">
              {(() => {
                const sorted = trades
                  .map((t, idx) => ({ t, idx }))
                  .sort((a, b) => {
                    const aKey = Number.isFinite(a.t.exitIdx)
                      ? a.t.exitIdx
                      : a.t.entryIdx;
                    const bKey = Number.isFinite(b.t.exitIdx)
                      ? b.t.exitIdx
                      : b.t.entryIdx;
                    return bKey - aKey; // latest first
                  });

                return sorted.map(({ t, idx }) => {
                  const entry = rows[t.entryIdx];
                  const exit = rows[t.exitIdx];

                  return (
                    <div
                      key={`${t.entryIdx}-${t.exitIdx}-${t.side}`}
                      className={`px-3 py-2 rounded-xl border cursor-pointer history-card ${
                        t.pnl >= 0 ? "gain" : "loss"
                      }`}
                      onMouseEnter={() => setLockedTradeIdx(idx)}
                      onMouseLeave={() =>
                        setLockedTradeIdx((cur) => (cur === idx ? null : cur))
                      }
                      onClick={() =>
                        setLockedTradeIdx((cur) => (cur === idx ? null : idx))
                      }
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold">
                          {t.side} • {humanizeReason(t.reason as any)}
                        </div>
                        <div
                          className="arena-strong"
                          style={{
                            color: t.pnl >= 0 ? ARENA_GREEN : ARENA_RED,
                          }}
                        >
                          {t.pnl >= 0 ? "+" : "-"}${Math.abs(t.pnl).toFixed(2)}
                        </div>
                      </div>
                      <div className="mt-1 grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-neutral-700">
                        <div>Entry: ${t.entryPrice.toFixed(2)}</div>
                        <div>Exit: ${t.exitPrice.toFixed(2)}</div>
                        <div>Start: {formatLocalShort(entry?.timeMs)}</div>
                        <div>End: {formatLocalShort(exit?.timeMs)}</div>
                        <div className="col-span-2">
                          Duration: {t.exitIdx - t.entryIdx} bars
                        </div>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </aside>

        {/* CRITERIA & MODELS */}
        <section className="col-span-12">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSave();
            }}
            className="p-4 rounded-2xl bg-white border border-neutral-200"
          >
            {/* Buy / Sell sections */}
            {/* Entry Buy criteria removed */}

            {/* Exit Buy criteria removed */}

            {/* Entry Sell criteria removed */}

            {/* Exit Sell criteria removed */}

            {/* Models */}
            <div className="grid gap-4 md:grid-cols-3 mb-6">
              <div className="p-4 rounded-2xl bg-white border border-neutral-200 md:col-span-3">
                <h3 className="font-extrabold mb-2">Advanced Options</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  {/* Minimum Entry Margin */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Minimum Entry Margin
                    </span>
                    <input
                      type="number"
                      step={0.01}
                      value={minEntryMargin as any}
                      onChange={(e) =>
                        setMinEntryMargin(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Minimum Hold Margin */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Minimum Hold Margin
                    </span>
                    <input
                      type="number"
                      step={0.01}
                      value={minHoldMargin as any}
                      onChange={(e) =>
                        setMinHoldMargin(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Hysteresis (bars) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Hysteresis (bars)
                    </span>
                    <input
                      type="number"
                      step={1}
                      value={hysteresisBars as any}
                      onChange={(e) =>
                        setHysteresisBars(parseInt(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Target Range slider (dual knob) */}
                  <div
                    className="multi-range-slider flex flex-col gap-1 col-span-2 md:col-span-4 p-3 rounded-xl border"
                    style={{
                      background: dark ? "#111827" : "#f9fafb",
                      borderColor: dark ? "#374151" : "#d1d5db",
                    }}
                  >
                    <span className="text-xs text-neutral-500">
                      Target Range (bars)
                    </span>
                    <div className="flex items-center w-full mt-2 py-4">
                      <div
                        className="relative flex-1 h-2"
                        style={targetRangeTrackStyle}
                      >
                        {/* lower thumb */}
                        <input
                          type="range"
                          min={0}
                          max={SLIDER_MAX}
                          step={1}
                          value={targetRangeMinBars}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setTargetRangeMinBars(
                              Math.min(val, targetRangeMaxBars)
                            );
                          }}
                          className="absolute top-0 left-0 w-full h-2"
                        />
                        {/* upper thumb */}
                        <input
                          type="range"
                          min={0}
                          max={SLIDER_MAX}
                          step={1}
                          value={targetRangeMaxBars}
                          onChange={(e) => {
                            const val = parseInt(e.target.value);
                            setTargetRangeMaxBars(
                              Math.max(val, targetRangeMinBars)
                            );
                          }}
                          className="absolute top-0 left-0 w-full h-2"
                        />
                      </div>
                      <div className="ml-3 text-xs text-neutral-500 flex items-center gap-1 whitespace-nowrap">
                        <span>{targetRangeMinBars}</span>
                        <span>—</span>
                        <span>{targetRangeMaxBars} bars</span>
                      </div>
                    </div>
                  </div>
                  {/* Pull to Target (%) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Pull to Target (%)
                    </span>
                    <input
                      type="number"
                      step={0.01}
                      value={pullToTargetPct as any}
                      onChange={(e) =>
                        setPullToTargetPct(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Push to Target (%) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Push to Target (%)
                    </span>
                    <input
                      type="number"
                      step={0.01}
                      value={pushToTargetPct as any}
                      onChange={(e) =>
                        setPushToTargetPct(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Min Trade Length (bars) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Min Trade Length (bars)
                    </span>
                    <input
                      type="number"
                      step={1}
                      value={minTradeLengthBars as any}
                      onChange={(e) =>
                        setMinTradeLengthBars(parseInt(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Max Trade Length (bars) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Max Trade Length (bars)
                    </span>
                    <input
                      type="number"
                      step={1}
                      value={maxTradeLengthBars as any}
                      onChange={(e) =>
                        setMaxTradeLengthBars(parseInt(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Trail Distance (pts) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Trail Distance (pts)
                    </span>
                    <input
                      type="number"
                      step={0.01}
                      value={trailDistancePts as any}
                      onChange={(e) =>
                        setTrailDistancePts(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Bull Bias (%) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Bull Bias (%)
                    </span>
                    <input
                      type="number"
                      max={100}
                      step={0.1}
                      value={bullBiasPct as any}
                      onChange={(e) =>
                        setBullBiasPct(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Bear Bias (%) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Bear Bias (%)
                    </span>
                    <input
                      type="number"
                      max={100}
                      step={0.1}
                      value={bearBiasPct as any}
                      onChange={(e) =>
                        setBearBiasPct(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                  {/* Sideways Bias (%) */}
                  <label className="flex flex-col gap-1">
                    <span className="text-xs text-neutral-500">
                      Sideways Bias (%)
                    </span>
                    <input
                      type="number"
                      max={100}
                      step={0.1}
                      value={sidewaysBiasPct as any}
                      onChange={(e) =>
                        setSidewaysBiasPct(parseFloat(e.target.value))
                      }
                      className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                    />
                  </label>
                </div>
              </div>

              <div className="hidden p-4 rounded-2xl bg-white border border-neutral-200">
                <h3 className="font-extrabold mb-2">Time of Day model</h3>
                <div className="mb-2">
                  <select
                    value={timeModel}
                    onChange={(e) => setTimeModel(e.target.value)}
                    className="w-full bg-white border border-neutral-300 rounded-xl px-3 py-2 text-sm"
                  >
                    <option>Momentum</option>
                    <option>Heikin Ashi</option>
                    <option>Smart Money Concepts</option>
                  </select>
                </div>
                {timeModel === "Momentum" && (
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <label className="flex flex-col gap-1">
                      <span className="text-xs text-neutral-500">EMA len</span>
                      <input
                        type="number"
                        step={1}
                        value={emaLen}
                        onChange={(e) => setEmaLen(Number(e.target.value))}
                        className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                      />
                    </label>
                    <label className="flex flex-col gap-1">
                      <span className="text-xs text-neutral-500">ref</span>
                      <input
                        type="number"
                        step={1}
                        value={refLen}
                        onChange={(e) => setRefLen(Number(e.target.value))}
                        className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                      />
                    </label>
                    <label className="flex flex-col gap-1">
                      <span className="text-xs text-neutral-500">sqz len</span>
                      <input
                        type="number"
                        step={1}
                        value={sqzLen}
                        onChange={(e) => setSqzLen(Number(e.target.value))}
                        className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                      />
                    </label>
                  </div>
                )}
                {timeModel === "Smart Money Concepts" && (
                  <div className="grid grid-cols-3 gap-3 text-sm">
                    <label className="flex flex-col gap-1">
                      <span className="text-xs text-neutral-500">SMC len</span>
                      <input
                        type="number"
                        step={1}
                        value={timeSmcLen}
                        onChange={(e) => setTimeSmcLen(Number(e.target.value))}
                        className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                      />
                    </label>
                  </div>
                )}
              </div>

              <div className="hidden p-4 rounded-2xl bg-white border border-neutral-200">
                <h3 className="font-extrabold mb-2">Weather model</h3>
                <select
                  value={weatherModel}
                  onChange={(e) => setWeatherModel(e.target.value)}
                  className="w-full bg-white border border-neutral-300 rounded-xl px-3 py-2 text-sm"
                >
                  <option>Heikin Ashi</option>
                  <option>Momentum</option>
                </select>
              </div>
            </div>

            {/* Risk */}
            {/* Updated risk section: removed fallback horizon and condensed columns. Lot size removed */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
              {/* Dollars per point */}
              <label className="flex flex-col gap-1">
                <span className="text-xs text-neutral-500">
                  Dollars per point
                </span>
                <input
                  type="number"
                  step={0.01}
                  value={dollarsPerPoint as any}
                  onChange={(e) => setDollarsPerPoint(e.target.value)}
                  className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-xs text-neutral-500">
                  Stop Loss (USD)
                </span>
                <input
                  type="number"
                  step={0.01}
                  value={stopLossUSD as any}
                  onChange={(e) => setStopLossUSD(e.target.value)}
                  className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                  placeholder="(optional)"
                />
              </label>
              <label className="flex flex-col gap-1">
                <span className="text-xs text-neutral-500">
                  Take Profit (USD)
                </span>
                <input
                  type="number"
                  step={0.01}
                  value={takeProfitUSD as any}
                  onChange={(e) => setTakeProfitUSD(e.target.value)}
                  className="bg-white border border-neutral-300 rounded-xl px-3 py-2"
                  placeholder="(optional)"
                />
              </label>
              {/* Lot Size input removed */}
            </div>

            {/* === SETTINGS BUTTONS === */}
            <div className="mt-8">
              {/* Row: UPLOAD */}
              <div className="flex flex-col sm:flex-row gap-2 mb-2">
                <motion.button
                  whileHover={{ scale: 1.03, y: -1 }}
                  whileTap={{ scale: 0.97 }}
                  transition={hoverSpring}
                  onClick={() => {
                    if (fileInputRef.current) fileInputRef.current.click();
                  }}
                  className="w-full h-10 rounded-lg border-2 border-purple-600 text-purple-500 font-semibold tracking-wide
               hover:bg-purple-600 hover:!text-white transition-all duration-200
               hover:shadow-[0_0_14px_rgba(139,92,246,0.45)]"
                >
                  UPLOAD
                </motion.button>
                {/* Hidden file input used to select the model JSON */}
                <input
                  type="file"
                  accept=".json,application/json"
                  ref={fileInputRef}
                  onChange={handleModelFileUpload}
                  className="hidden"
                />
              </div>
              {/* Row: CLEAR */}
              <div className="flex flex-col sm:flex-row gap-2">
                <motion.button
                  whileHover={{ scale: 1.03, y: -1 }}
                  whileTap={{ scale: 0.97 }}
                  transition={hoverSpring}
                  onClick={() => {
                    localStorage.removeItem("seasons.config");
                    localStorage.removeItem("seasons.pnl");
                    localStorage.removeItem(LS_CACHED_BARS);
                    localStorage.removeItem(LS_LAST_FETCH);
                    window.location.reload();
                  }}
                  className="w-full h-10 rounded-lg border-2 border-rose-600 text-rose-500 font-semibold tracking-wide
               hover:bg-rose-600 hover:!text-white transition-all duration-200
               hover:shadow-[0_0_14px_rgba(225,29,72,0.45)]"
                >
                  CLEAR SETTINGS
                </motion.button>
              </div>

              {/* --- SETTINGS BUTTONS --- */}
              <div className="flex flex-col gap-3 mt-3">
                {/* SAVE SETTINGS — only saves to localStorage */}
                <motion.button
                  type="button"
                  onClick={() => {
                    try {
                      const cfg = {
                        timeModel,
                        weatherModel,
                        softLen,
                        sharpLen,
                        emaLen,
                        refLen,
                        sqzLen,
                        timeSmcLen,
                        buyEntry,
                        buyExit,
                        sellEntry,
                        sellExit,
                        stopLossUSD,
                        takeProfitUSD,
                        // lotSize removed
                        // horizonBars removed from config
                        dollarsPerPoint,
                        // Persist advanced options as part of settings
                        minEntryMargin,
                        minHoldMargin,
                        hysteresisBars,
                        targetRangeMinBars,
                        targetRangeMaxBars,
                        pullToTargetPct,
                        pushToTargetPct,
                        minTradeLengthBars,
                        maxTradeLengthBars,
                        // trailingStop not persisted; derived from trailDistancePts
                        trailDistancePts,
                        bullBiasPct,
                        bearBiasPct,
                        sidewaysBiasPct,
                      };
                      localStorage.setItem(
                        "seasons.config",
                        JSON.stringify(cfg)
                      );
                      localStorage.setItem(
                        "seasons.pnl",
                        JSON.stringify(pnlHistory)
                      );
                      alert("Settings saved!");
                    } catch {
                      alert("Error saving settings.");
                    }
                  }}
                  className="w-full h-11 rounded-lg border-2 border-emerald-600 text-emerald-500 font-semibold tracking-wide
   hover:bg-emerald-600 hover:!text-white transition-all duration-200
   hover:shadow-[0_0_14px_rgba(16,185,129,0.45)]"
                >
                  SAVE SETTINGS
                </motion.button>

                {/* RUN — executes full recompute/backtest */}
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={saving}
                  className="w-full h-11 rounded-lg border-2 border-emerald-600 text-emerald-500 font-semibold tracking-wide
   hover:bg-emerald-600 hover:!text-white transition-all duration-200
   hover:shadow-[0_0_14px_rgba(16,185,129,0.45)]"
                >
                  RUN
                </motion.button>
              </div>
            </div>

            <p className="text-xs text-neutral-500 mt-3">
              Caches filtered data locally, throttles API to 5 minutes, honors
              UTC trading session (Sunday opens 2h earlier), and updates
              history.
            </p>
          </form>
        </section>
      </main>

      {/* Footer removed per user request */}
      {/*<footer className="border-t border-neutral-200 mt-6">
        <div className="max-w-7xl mx-auto px-5 py-4 text-xs text-neutral-500">
          Data: Twelve Data (15m XAU/USD). Demo only — not investment advice.
        </div>
      </footer>*/}
    </div>
  );
}

// Simulator (unchanged logic except it now runs against the 1:1 indexed rows)
function simulateTradesAndTrades(
  rows: any[],
  opts: {
    buyEntry: Criterion[];
    buyExit: Criterion[];
    sellEntry: Criterion[];
    sellExit: Criterion[];
    stopLossUSD: number | null;
    takeProfitUSD: number | null;
    horizon: number;
    /**
     * User specified dollars per point multiplier. This value controls the USD PnL on each tick.
     * If undefined, the default constant DOLLARS_PER_UNIT is used.
     */
    dollarsPerPoint?: number;
  }
): { trades: Trade[]; openTrade: OpenTrade } {
  if (!rows?.length) return { trades: [], openTrade: null };

  const {
    buyEntry,
    buyExit,
    sellEntry,
    sellExit,
    stopLossUSD,
    takeProfitUSD,
    horizon,
    dollarsPerPoint,
  } = opts;

  const buyEntryPred = buildEntryPredicateFromList(rows, buyEntry);
  const buyExitPred = buildExitPredicateFromList(rows, buyExit);
  const sellEntryPred = buildEntryPredicateFromList(rows, sellEntry);
  const sellExitPred = buildExitPredicateFromList(rows, sellExit);

  if (!buyEntryPred.hasAny && !sellEntryPred.hasAny)
    return { trades: [], openTrade: null };

  // Compute dollars per unit (DPU) using the user provided dollarsPerPoint if available; otherwise fall back to the compile-time default constant.
  const DPU =
    Number.isFinite(dollarsPerPoint) && (dollarsPerPoint as number) > 0
      ? (dollarsPerPoint as number)
      : DOLLARS_PER_UNIT;

  // --- Backtest‑style risk caps ---
  // Cap negative PnL at the user‑defined stop loss and positive PnL at the take profit.
  // If no stop or take profit is set the cap is effectively disabled (Infinity).
  const maxLossUSD =
    stopLossUSD != null && stopLossUSD > 0 ? stopLossUSD : Infinity;
  const maxWinUSD =
    takeProfitUSD != null && takeProfitUSD > 0 ? takeProfitUSD : Infinity;

  const anchorsFailThisBar = (anchors: Criterion[], idx: number) => {
    if (!anchors?.length) return false;
    return anchors.some(
      (c) =>
        !criterionHolds(rows, idx, {
          ...c,
          progressionPct: undefined,
          progressionCmp: undefined,
          stddevEarlyExit: false,
          temporal: "Current",
        })
    );
  };

  const trades: Trade[] = [];
  // Track a candidate open trade if we reach the dataset end without exit
  let openCandidate: {
    side: "BUY" | "SELL";
    entryIdx: number;
    entryPrice: number;
  } | null = null;

  function tpSlTargetsPrice(
    side: "BUY" | "SELL",
    entryPrice: number,
    slUSD: number | null,
    tpUSD: number | null
  ) {
    let tpPrice: number | null = null;
    let slPrice: number | null = null;
    if (tpUSD != null && tpUSD > 0) {
      const move = tpUSD / DPU;
      tpPrice = side === "BUY" ? entryPrice + move : entryPrice - move;
    }
    if (slUSD != null && slUSD > 0) {
      const move = slUSD / DPU;
      slPrice = side === "BUY" ? entryPrice - move : entryPrice + move;
    }
    return { tpPrice, slPrice };
  }

  function tpSlHitOnBar(
    side: "BUY" | "SELL",
    bar: { high: number; low: number },
    entryPrice: number,
    tpPrice: number | null,
    slPrice: number | null
  ):
    | { hit: true; reason: "TP" | "SL"; exitPrice: number }
    | { hit: false; reason: ""; exitPrice: number } {
    const { high, low } = bar;

    if (tpPrice != null && slPrice != null) {
      if (side === "BUY") {
        if (low <= slPrice)
          return { hit: true, reason: "SL", exitPrice: slPrice };
        if (high >= tpPrice)
          return { hit: true, reason: "TP", exitPrice: tpPrice };
      } else {
        if (high >= slPrice)
          return { hit: true, reason: "SL", exitPrice: slPrice };
        if (low <= tpPrice)
          return { hit: true, reason: "TP", exitPrice: tpPrice };
      }
      return { hit: false, reason: "", exitPrice: NaN };
    }

    if (tpPrice != null) {
      if (side === "BUY" && high >= tpPrice)
        return { hit: true, reason: "TP", exitPrice: tpPrice };
      if (side === "SELL" && low <= tpPrice)
        return { hit: true, reason: "TP", exitPrice: tpPrice };
    }

    if (slPrice != null) {
      if (side === "BUY" && low <= slPrice)
        return { hit: true, reason: "SL", exitPrice: slPrice };
      if (side === "SELL" && high >= slPrice)
        return { hit: true, reason: "SL", exitPrice: slPrice };
    }

    return { hit: false, reason: "", exitPrice: NaN };
  }

  const runSide = (
    entry: ReturnType<typeof buildEntryPredicateFromList>,
    exit: ReturnType<typeof buildExitPredicateFromList>,
    side: "BUY" | "SELL"
  ) => {
    let i = 0;
    while (i < rows.length - 1) {
      if (!entry.holds(i)) {
        i++;
        continue;
      }
      const entryIdx = i; // keep time/index the same
      // Use the current bar close price as the entry price, mirroring the backtest behaviour
      const entryPrice = rows[entryIdx].close;
      const { tpPrice, slPrice } = tpSlTargetsPrice(
        side,
        entryPrice,
        stopLossUSD,
        takeProfitUSD
      );

      let exitIdx = -1;
      let exitReason: "TP" | "SL" | "EXIT" | "ANCHOR" | "HORIZON" = "HORIZON";
      let overrideExitPrice: number | undefined;

      let j = entryIdx + 1;
      for (; j < rows.length; j++) {
        const hit = tpSlHitOnBar(
          side,
          { high: rows[j].high, low: rows[j].low },
          entryPrice,
          tpPrice,
          slPrice
        );
        if (hit.hit) {
          exitIdx = j;
          exitReason = hit.reason;
          overrideExitPrice = hit.exitPrice;
          break;
        }
        if (exit.hasAny && exit.holds(j)) {
          exitIdx = j;
          exitReason = "EXIT";
          break;
        }
        if (entry.anchors.length && anchorsFailThisBar(entry.anchors, j)) {
          exitIdx = j;
          exitReason = "ANCHOR";
          break;
        }
        if (j - entryIdx >= horizon) {
          exitIdx = j;
          exitReason = "HORIZON";
          break;
        }
      }

      // If we reached the end with no exit, keep it OPEN (do not force-close on last bar)
      if (exitIdx < 0 && j >= rows.length) {
        if (!openCandidate || entryIdx > openCandidate.entryIdx) {
          openCandidate = {
            side,
            entryIdx,
            // record the entry price using the bar close as above
            entryPrice: rows[entryIdx].close,
          };
        }
        i = j;
        continue;
      }

      if (exitIdx < 0) exitIdx = Math.min(rows.length - 1, entryIdx + horizon);
      let rawExitPrice = overrideExitPrice ?? rows[exitIdx].close;
      const dir = side === "BUY" ? 1 : -1;
      // Compute raw (unclipped) PnL in USD
      let pnlUSD = (rawExitPrice - entryPrice) * dir * DPU;
      // Apply backtest‑style caps: limit losses to maxLossUSD and gains to maxWinUSD
      if (pnlUSD < -maxLossUSD) {
        pnlUSD = -maxLossUSD;
        // Adjust the exit price to reflect the capped loss
        rawExitPrice = entryPrice + (pnlUSD / DPU) * dir;
      }
      if (pnlUSD > maxWinUSD) {
        pnlUSD = maxWinUSD;
        // Adjust the exit price to reflect the capped profit
        rawExitPrice = entryPrice + (pnlUSD / DPU) * dir;
      }
      // Round PnL to 2 decimal places
      pnlUSD = Math.round(pnlUSD * 100) / 100;

      trades.push({
        side,
        entryIdx,
        exitIdx,
        entryPrice,
        exitPrice: rawExitPrice,
        reason: exitReason,
        pnl: pnlUSD,
      });

      i = exitIdx + 1;
    }
  };

  if (buyEntryPred.hasAny) runSide(buyEntryPred, buyExitPred, "BUY");
  if (sellEntryPred.hasAny) runSide(sellEntryPred, sellExitPred, "SELL");

  // Determine openTrade
  let openTrade: OpenTrade = null;
  const lastBarIdx = rows.length - 1;
  if (openCandidate) {
    const unrealized =
      (openCandidate.side === "BUY"
        ? rows[lastBarIdx].close - openCandidate.entryPrice
        : openCandidate.entryPrice - rows[lastBarIdx].close) * DPU;
    openTrade = {
      side: openCandidate.side,
      entryIdx: openCandidate.entryIdx,
      entryPrice: openCandidate.entryPrice,
      unrealized: Math.round(unrealized * 100) / 100,
    };
  } else {
    const be = buildEntryPredicateFromList(rows, buyEntry);
    const se = buildEntryPredicateFromList(rows, sellEntry);
    const i = lastBarIdx;
    if (be.hasAny && be.holds(i)) {
      const entryIdx = i;
      // Use close price for entry in fallback open trade calculation
      const entryPrice = rows[entryIdx].close;
      const unrealized = (rows[lastBarIdx].close - entryPrice) * DPU;
      openTrade = { side: "BUY", entryIdx, entryPrice, unrealized };
    } else if (se.hasAny && se.holds(i)) {
      const entryIdx = i;
      // Use close price for entry in fallback open trade calculation
      const entryPrice = rows[entryIdx].close;
      const unrealized = (entryPrice - rows[lastBarIdx].close) * DPU;
      openTrade = { side: "SELL", entryIdx, entryPrice, unrealized };
    }
  }

  return { trades, openTrade };
}

/**
 * Simulate trades driven by a machine learning model (no momentum fallback).
 *
 * @param rows     Labeled OHLC rows.
 * @param opts     Configuration options including model predictions and risk settings.
 *
 * The simulation opens a long trade when the normalized prediction exceeds the
 * bullBiasPct threshold and a short trade when it falls below the negative
 * bearBiasPct threshold. Positions are closed when the signal crosses back
 * through zero or the opposite threshold, when a take‑profit or stop‑loss is
 * hit, when a trailing stop is triggered, or after maxTradeLength bars.
 */
// -----------------------------------------------------------------------------
//
//  simulatePredictedTradesFallback
//
//  The original live simulator was driven by a signed confidence margin array.
//  It determines entry and exit points based on threshold crossings, stop/loss
//  caps, trailing stops, and fixed min/max holding periods.  This function is
//  retained as a fallback for scenarios where no ML model is available.  It
//  expects a predictions array where positive values favour bullish trades,
//  negative values favour bearish trades, and values near zero indicate a
//  sideways market.  The user‑supplied thresholds (bullBiasPct, bearBiasPct)
//  are interpreted as minimum confidence levels required to open a trade.
//
//  When no predictions are supplied or the array is empty the function
//  produces no trades.  At the end of the run it may report an open trade
//  representing a position carried into the future.  It returns the list of
//  closed trades along with any open position.
function simulatePredictedTradesFallback(
  rows: any[],
  opts: {
    predictions: number[] | null;
    stopLossUSD: number | null;
    takeProfitUSD: number | null;
    minTradeLength: number;
    maxTradeLength: number;
    trailingStop: boolean;
    trailDistancePts: number;
    bullBiasPct: number;
    bearBiasPct: number;
    sidewaysBiasPct: number;
    dollarsPerPoint?: number;
  }
): { trades: Trade[]; openTrade: OpenTrade } {
  if (!rows?.length) return { trades: [], openTrade: null };

  const {
    predictions,
    stopLossUSD,
    takeProfitUSD,
    minTradeLength,
    maxTradeLength,
    trailingStop,
    trailDistancePts,
    bullBiasPct,
    bearBiasPct,
    sidewaysBiasPct,
    dollarsPerPoint,
  } = opts;

  // Compute DPU: user provided dollarsPerPoint value; if undefined falls back to constant.
  const DPU =
    Number.isFinite(dollarsPerPoint) && (dollarsPerPoint as number) > 0
      ? (dollarsPerPoint as number)
      : DOLLARS_PER_UNIT;

  // --- Backtest‑style risk caps ---
  // Use Infinity when stopLossUSD or takeProfitUSD are null/zero so that capping is disabled.
  const maxLossUSD =
    stopLossUSD != null && stopLossUSD > 0 ? stopLossUSD : Infinity;
  const maxWinUSD =
    takeProfitUSD != null && takeProfitUSD > 0 ? takeProfitUSD : Infinity;

  // Require model predictions; if none provided return no trades.  Align the model prediction series to rows length.
  if (!predictions || predictions.length === 0) {
    return { trades: [], openTrade: null };
  }
  let preds: number[] = [];
  if (predictions.length >= rows.length) {
    preds = predictions.slice(predictions.length - rows.length);
  } else {
    const diff = rows.length - predictions.length;
    const firstVal = predictions[0] ?? 0;
    preds = new Array(diff).fill(firstVal).concat(predictions);
  }

  // The prediction array is interpreted directly as a signed confidence
  // margin.  Values range from -1 to 1 where positive values favour
  // bullish positions and negative values favour bearish positions.
  // Do not normalise by the maximum absolute value; thresholds should
  // be expressed relative to the underlying margin scale (0–1).
  const normPreds = preds;

  // Thresholds (convert percentages to [0,1] range). Values of 0 disable that bias.
  const bullThresh = (bullBiasPct ?? 0) / 100;
  const bearThresh = (bearBiasPct ?? 0) / 100;

  // risk functions replicate TP/SL behaviour from the original simulator
  function tpSlTargetsPrice(
    side: "BUY" | "SELL",
    entryPrice: number,
    slUSD: number | null,
    tpUSD: number | null
  ) {
    let tpPrice: number | null = null;
    let slPrice: number | null = null;
    if (tpUSD != null && tpUSD > 0) {
      const move = tpUSD / DPU;
      tpPrice = side === "BUY" ? entryPrice + move : entryPrice - move;
    }
    if (slUSD != null && slUSD > 0) {
      const move = slUSD / DPU;
      slPrice = side === "BUY" ? entryPrice - move : entryPrice + move;
    }
    return { tpPrice, slPrice };
  }

  function tpSlHitOnBar(
    side: "BUY" | "SELL",
    bar: { high: number; low: number },
    entryPrice: number,
    tpPrice: number | null,
    slPrice: number | null
  ):
    | { hit: true; reason: "TP" | "SL"; exitPrice: number }
    | { hit: false; reason: ""; exitPrice: number } {
    const { high, low } = bar;
    if (tpPrice != null && slPrice != null) {
      if (side === "BUY") {
        if (low <= slPrice)
          return { hit: true, reason: "SL", exitPrice: slPrice };
        if (high >= tpPrice)
          return { hit: true, reason: "TP", exitPrice: tpPrice };
      } else {
        if (high >= slPrice)
          return { hit: true, reason: "SL", exitPrice: slPrice };
        if (low <= tpPrice)
          return { hit: true, reason: "TP", exitPrice: tpPrice };
      }
      return { hit: false, reason: "", exitPrice: NaN };
    }
    if (tpPrice != null) {
      if (side === "BUY" && bar.high >= tpPrice)
        return { hit: true, reason: "TP", exitPrice: tpPrice };
      if (side === "SELL" && bar.low <= tpPrice)
        return { hit: true, reason: "TP", exitPrice: tpPrice };
    }
    if (slPrice != null) {
      if (side === "BUY" && bar.low <= slPrice)
        return { hit: true, reason: "SL", exitPrice: slPrice };
      if (side === "SELL" && bar.high >= slPrice)
        return { hit: true, reason: "SL", exitPrice: slPrice };
    }
    return { hit: false, reason: "", exitPrice: NaN };
  }

  const trades: Trade[] = [];
  let openTrade: OpenTrade = null;
  // Track current open trade information, including highest/lowest for trailing stops
  let current: {
    side: "BUY" | "SELL";
    entryIdx: number;
    entryPrice: number;
    highest: number;
    lowest: number;
  } | null = null;

  for (let i = 0; i < rows.length - 1; i++) {
    const p = normPreds[i];
    // Use the current bar's close as the entry price to better mirror
    // backtest behaviour (entries are priced off the bar close rather than
    // the next bar open).  If this is the final bar, fall back to its close.
    const currentClosePrice = rows[i].close;
    // If there is an open trade, evaluate exit conditions
    if (current) {
      const side = current.side;
      const entryIdx = current.entryIdx;
      const entryPrice = current.entryPrice;
      // update trailing extremes
      current.highest = Math.max(current.highest, rows[i].high);
      current.lowest = Math.min(current.lowest, rows[i].low);
      let exitThisBar = false;
      let exitReason: "TP" | "SL" | "SIGNAL" | "LENGTH" | "TRAIL" = "SIGNAL";
      let exitPrice: number | null = null;

      // Check TP/SL
      const { tpPrice, slPrice } = tpSlTargetsPrice(
        side,
        entryPrice,
        stopLossUSD,
        takeProfitUSD
      );
      const hit = tpSlHitOnBar(
        side,
        { high: rows[i].high, low: rows[i].low },
        entryPrice,
        tpPrice,
        slPrice
      );
      if (hit.hit) {
        exitThisBar = true;
        exitReason = hit.reason;
        exitPrice = hit.exitPrice;
      }
      // Check trailing stop
      if (!exitThisBar && trailingStop && trailDistancePts > 0) {
        if (side === "BUY") {
          const trail = current.highest - trailDistancePts;
          if (rows[i].low <= trail) {
            exitThisBar = true;
            exitReason = "TRAIL";
            exitPrice = trail;
          }
        } else {
          const trail = current.lowest + trailDistancePts;
          if (rows[i].high >= trail) {
            exitThisBar = true;
            exitReason = "TRAIL";
            exitPrice = trail;
          }
        }
      }
      // Check max trade length
      if (
        !exitThisBar &&
        maxTradeLength > 0 &&
        i - entryIdx >= maxTradeLength
      ) {
        exitThisBar = true;
        exitReason = "LENGTH";
      }
      // Check signal reversal after minimum holding period
      if (!exitThisBar && i - entryIdx >= minTradeLength) {
        if (side === "BUY") {
          // exit if bullish confidence no longer meets threshold or signal flips to bearish
          if (p < bullThresh && !(bearThresh > 0 && p <= -bearThresh)) {
            exitThisBar = true;
            exitReason = "SIGNAL";
          }
        } else {
          if (p > -bearThresh && !(bullThresh > 0 && p >= bullThresh)) {
            exitThisBar = true;
            exitReason = "SIGNAL";
          }
        }
      }
      // Perform exit
      if (exitThisBar) {
        const exitIdx = i;
        let rawExitPrice = exitPrice ?? rows[i].close;
        const dir = side === "BUY" ? 1 : -1;
        // Compute the raw (unclipped) PnL in USD
        let pnlUSD = (rawExitPrice - entryPrice) * dir * DPU;
        // Cap negative PnL to the stop loss and positive PnL to the take profit
        if (pnlUSD < -maxLossUSD) {
          pnlUSD = -maxLossUSD;
          // Adjust the exit price so that PnL matches the capped loss
          rawExitPrice = entryPrice + (pnlUSD / DPU) * dir;
        }
        if (pnlUSD > maxWinUSD) {
          pnlUSD = maxWinUSD;
          // Adjust the exit price so that PnL matches the capped profit
          rawExitPrice = entryPrice + (pnlUSD / DPU) * dir;
        }
        // Round PnL to 2 decimal places
        pnlUSD = Math.round(pnlUSD * 100) / 100;
        trades.push({
          side,
          entryIdx,
          exitIdx,
          entryPrice,
          exitPrice: rawExitPrice,
          reason: exitReason,
          pnl: pnlUSD,
        });
        current = null;
        // after closing, the next iteration should consider entry at same bar
        // but we will not skip; continue to check entry conditions below
      }
    }
    // If no trade is open, evaluate entry conditions using current prediction
    if (!current) {
      if (p >= bullThresh && bullThresh > 0) {
        // open a long trade at the current close price
        current = {
          side: "BUY",
          entryIdx: i,
          entryPrice: currentClosePrice,
          highest: currentClosePrice,
          lowest: currentClosePrice,
        };
        continue;
      }
      if (p <= -bearThresh && bearThresh > 0) {
        // open a short trade at the current close price
        current = {
          side: "SELL",
          entryIdx: i,
          entryPrice: currentClosePrice,
          highest: currentClosePrice,
          lowest: currentClosePrice,
        };
        continue;
      }
    }
  }
  // Determine any open trade at the end of the series
  let open: OpenTrade = null;
  if (current) {
    const lastIdx = rows.length - 1;
    const unrealized =
      (current.side === "BUY"
        ? rows[lastIdx].close - current.entryPrice
        : current.entryPrice - rows[lastIdx].close) * DPU;
    open = {
      side: current.side,
      entryIdx: current.entryIdx,
      entryPrice: current.entryPrice,
      unrealized: Math.round(unrealized * 100) / 100,
    };
  }
  return { trades, openTrade: open };
}

// -----------------------------------------------------------------------------
//
//  simulatePredictedTrades
//
//  A more sophisticated simulator that mirrors the backtest engine.  It
//  constructs a margin and class label at each bar using an OvR perceptron
//  model (if available) and honours the same entry/exit logic used in
//  backtesting: minimum entry/hold margins, hysteresis to smooth exits,
//  probabilistic target lengths, trailing stops, guaranteed stop caps, and
//  configurable target pull percentages.  When no model is available it
//  falls back to the original live simulator described above.
//
//  Parameters supplied in opts include user‑adjustable thresholds and risk
//  settings such as take profit / stop loss amounts (in USD), the number of
//  bars to hold before a soft exit is allowed, and the distribution of target
//  lengths.  See the backtest implementation for a detailed explanation of
//  each option.
function simulatePredictedTrades(
  rows: any[],
  opts: {
    predictions: number[] | null;
    stopLossUSD: number | null;
    takeProfitUSD: number | null;
    minTradeLength: number;
    maxTradeLength: number;
    trailingStop: boolean;
    trailDistancePts: number;
    bullBiasPct: number;
    bearBiasPct: number;
    sidewaysBiasPct: number;
    dollarsPerPoint?: number;
    minEntryMargin?: number;
    minHoldMargin?: number;
    hysteresisBars?: number;
    targetRangeMinBars?: number;
    targetRangeMaxBars?: number;
    pullToTargetPct?: number;
    pushToTargetPct?: number;
  }
): { trades: Trade[]; openTrade: OpenTrade } {
  if (!rows?.length) return { trades: [], openTrade: null };

  const {
    predictions,
    stopLossUSD,
    takeProfitUSD,
    minTradeLength,
    maxTradeLength,
    trailingStop,
    trailDistancePts,
    bullBiasPct,
    bearBiasPct,
    sidewaysBiasPct,
    dollarsPerPoint,
    minEntryMargin,
    minHoldMargin,
    hysteresisBars,
    targetRangeMinBars,
    targetRangeMaxBars,
    pullToTargetPct,
    pushToTargetPct,
  } = opts;

  // Initialise a deterministic random number generator.  This RNG ensures
  // that sampling (target lengths, soft exits) is repeatable across runs.
  const rand = makeSeededRand(DEFAULT_RNG_SEED);

  // Attempt to load the most recently saved OvR perceptron model from storage.
  const model = loadIntuitionModelFromStorage();
  const readyModel = !!(model && (model as any).heads);

  // If no model is available fallback to the legacy simulator.  Pass
  // parameters through unmodified so that risk caps and thresholds are
  // honoured.  This ensures the UI continues to function when no model has
  // been trained or loaded.
  if (!readyModel) {
    return simulatePredictedTradesFallback(rows, opts);
  }

  // Derived constants from options
  const hyst = Math.max(1, hysteresisBars ?? 1);
  const enterM = minEntryMargin ?? 0;
  const holdM = minHoldMargin ?? 0;
  const tMin = Math.max(1, targetRangeMinBars ?? 1);
  const tMax = Math.max(tMin, targetRangeMaxBars ?? tMin);
  const localPullPct = pullToTargetPct ?? 0;
  const localPushPct = pushToTargetPct ?? 0;
  const minTradeBars = Math.max(0, minTradeLength ?? 0);
  const maxTradeBars = Math.max(0, maxTradeLength ?? 0);
  const useTrailing = trailingStop && trailDistancePts > 0;
  const trailPts = trailDistancePts;

  // Convert stop and take profit amounts (USD) into price offsets (points).  A
  // non‑positive or null value disables the cap.  The DPU (dollars per point)
  // determines how many dollars are earned per one point of price movement.
  const U =
    Number.isFinite(dollarsPerPoint) && (dollarsPerPoint as number) > 0
      ? (dollarsPerPoint as number)
      : DOLLARS_PER_UNIT;
  const stopPts = stopLossUSD != null && stopLossUSD > 0 ? stopLossUSD / U : 0;
  const tpPts =
    takeProfitUSD != null && takeProfitUSD > 0 ? takeProfitUSD / U : 0;

  // Biases (priors) for class probability blending.  Convert percentage
  // weights into [0, 100] range.  When omitted the backtest defaults (50,50,50)
  // will be used by normalizedPriors/blendStrength.
  const bBull = bullBiasPct ?? 50;
  const bBear = bearBiasPct ?? 50;
  const bSide = sidewaysBiasPct ?? 50;

  // Precompute priors and blending factor just as in the backtest.  These
  // influence the strength of the model vs. the user‑defined biases.
  const priors = normalizedPriors(bBull, bBear, bSide);
  const lambda = blendStrength(bBull, bBear, bSide);

  // Helper to compute label and margin at a given index
  const predictWithMargins = (idx: number) => {
    const f = makeF(rows, idx);
    const s = scoreHeadsFlexible(f, (model as any).heads);
    const p = softmax3(s);
    const pb = {
      BULL: (1 - lambda) * p.BULL + lambda * priors.BULL,
      BEAR: (1 - lambda) * p.BEAR + lambda * priors.BEAR,
      SIDE: (1 - lambda) * p.SIDE + lambda * priors.SIDE,
    };
    const arr = [pb.BULL, pb.BEAR, pb.SIDE].sort((a, b) => b - a);
    const margin = arr[0] - arr[1] || 0;
    return { label: argmax3p(pb), margin };
  };

  // Sample a random target length between tMin and tMax (inclusive).  When
  // tMax <= tMin the returned value will always be tMin.
  const sampleTargetLen = () =>
    Math.max(1, Math.floor(tMin + rand() * Math.max(0, tMax - tMin)));

  // Predicates for entry and holding based on margin thresholds
  const canEnter = (m: number) => m >= enterM;
  const canHold = (m: number) => m >= holdM;

  // Cap PnL to the stop loss level.  If stopPts <= 0 no capping is applied.
  function capToGuaranteedStop(pnl: number, side: "LONG" | "SHORT") {
    if (stopPts <= 0) return { pnl, pxOut: null as number | null };
    const maxLossUsd = stopPts * U;
    if (pnl >= -maxLossUsd) return { pnl, pxOut: null as number | null };
    const pxOut = side === "LONG" ? pos!.p - stopPts : pos!.p + stopPts;
    return { pnl: -maxLossUsd, pxOut };
  }

  // Storage for completed trades
  const trades: Trade[] = [];
  // Representation of an open position
  let pos: null | {
    side: "LONG" | "SHORT";
    i: number;
    p: number;
    targetLen: number;
    disagreeStreak: number;
    trailBase?: number;
  } = null;

  // Iterate over bars; start at index 1 so that feature computation has at
  // least one prior bar available.  The last index will be closed in the
  // leftover logic below.
  for (let i = 1; i < rows.length; i++) {
    // Compute class label and margin for bar i.  If model predictions were
    // provided explicitly in opts.predictions, override the computed margin
    // with the supplied value.  This permits hybrid workflows where users
    // supply a custom margin signal but still benefit from the backtest exit
    // logic.  When the supplied array is shorter than the rows length it is
    // aligned to the end of the series (padding the front with the first
    // value).  Values in the predictions array are interpreted as signed
    // margins; positive means bullish, negative bearish, zero sideways.  A
    // provided prediction overrides the model‑derived margin but does not
    // alter the label: the sign of the prediction selects the label and the
    // absolute value is used as the margin.
    // Determine the class label and margin at bar i.  When a model is loaded
    // (readyModel is true) we always derive the margin and label from
    // predictWithMargins, ignoring any supplied predictions array.  This
    // ensures the live simulation mirrors the backtest exactly.  When no
    // model is available, we preserve the legacy behaviour of accepting
    // externally supplied predictions; if none are provided, the signal
    // defaults to sideways with zero margin.
    let lbl: "BULL" | "BEAR" | "SIDE";
    let margin: number;
    if (readyModel) {
      const r = predictWithMargins(i);
      lbl = r.label;
      margin = r.margin;
    } else if (predictions && predictions.length > 0) {
      // Align the user predictions to the data length
      let preds: number[];
      if (predictions.length >= rows.length) {
        preds = predictions.slice(predictions.length - rows.length);
      } else {
        const diff = rows.length - predictions.length;
        const firstVal = predictions[0] ?? 0;
        preds = new Array(diff).fill(firstVal).concat(predictions);
      }
      const p = preds[i];
      margin = Math.abs(p);
      if (p > 0) lbl = "BULL";
      else if (p < 0) lbl = "BEAR";
      else lbl = "SIDE";
    } else {
      lbl = "SIDE";
      margin = 0;
    }
    const row = rows[i];
    const px = row.close;

    if (pos) {
      // Trailing stop logic (optional)
      if (useTrailing) {
        if (pos.side === "LONG") {
          pos.trailBase =
            pos.trailBase == null ? px : Math.max(pos.trailBase, px);
          const trail = (pos.trailBase || px) - trailPts;
          if (
            rows[i].open <= trail ||
            (rows[i].low <= trail && trail <= rows[i].high)
          ) {
            let outPrice = rows[i].open <= trail ? rows[i].open : trail;
            let pnl = (outPrice - pos.p) * +1 * U;
            // Apply upside cap if configured
            const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              outPrice = pos.p + maxWinUsd / U;
            }
            trades.push({
              side: pos.side === "LONG" ? "BUY" : "SELL",
              entryIdx: pos.i,
              exitIdx: i,
              entryPrice: pos.p,
              exitPrice: outPrice,
              pnl: Math.round(pnl * 100) / 100,
              reason: "TP",
            });
            pos = null;
            continue;
          }
        } else {
          pos.trailBase =
            pos.trailBase == null ? px : Math.min(pos.trailBase, px);
          const trail = (pos.trailBase || px) + trailPts;
          if (
            rows[i].open >= trail ||
            (rows[i].low <= trail && trail <= rows[i].high)
          ) {
            let outPrice = rows[i].open >= trail ? rows[i].open : trail;
            let pnl = (outPrice - pos.p) * -1 * U;
            const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
            if (pnl > 0 && pnl > maxWinUsd) {
              pnl = maxWinUsd;
              outPrice = pos.p - maxWinUsd / U;
            }
            trades.push({
              side: pos.side === "LONG" ? "BUY" : "SELL",
              entryIdx: pos.i,
              exitIdx: i,
              entryPrice: pos.p,
              exitPrice: outPrice,
              pnl: Math.round(pnl * 100) / 100,
              reason: "TP",
            });
            pos = null;
            continue;
          }
        }
      }

      // Stop loss / take profit logic (guaranteed stop cap).  Always
      // enforced when stopPts or tpPts are positive.  We perform OPEN gap
      // checks followed by intrabar checks to mirror the backtest ordering.
      if (i > pos.i && (stopPts > 0 || tpPts > 0)) {
        const sl = pos.side === "LONG" ? pos.p - stopPts : pos.p + stopPts;
        const tp = pos.side === "LONG" ? pos.p + tpPts : pos.p - tpPts;
        // 1) OPEN gap checks
        const slAtOpen =
          stopPts > 0 &&
          ((pos.side === "LONG" && rows[i].open <= sl) ||
            (pos.side === "SHORT" && rows[i].open >= sl));
        const tpAtOpen =
          tpPts > 0 &&
          ((pos.side === "LONG" && rows[i].open >= tp) ||
            (pos.side === "SHORT" && rows[i].open <= tp));
        if (slAtOpen || tpAtOpen) {
          let pxOut = rows[i].open;
          let reason: "SL" | "TP" =
            slAtOpen && (!tpAtOpen || true) ? "SL" : "TP";
          let pnl = (pxOut - pos.p) * (pos.side === "LONG" ? +1 : -1) * U;
          // Cap negative moves to the stop if exiting on SL
          if (reason === "SL") {
            const capped = capToGuaranteedStop(pnl, pos.side);
            pnl = capped.pnl;
            if (capped.pxOut !== null) pxOut = capped.pxOut;
          }
          // Apply upside cap for winning trades
          const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            pxOut = pos.p + (pos.side === "LONG" ? +1 : -1) * (maxWinUsd / U);
          }
          trades.push({
            side: pos.side === "LONG" ? "BUY" : "SELL",
            entryIdx: pos.i,
            exitIdx: i,
            entryPrice: pos.p,
            exitPrice: pxOut,
            pnl: Math.round(pnl * 100) / 100,
            reason,
          });
          pos = null;
          continue;
        }
        // 2) INTRABAR checks
        const slHit = stopPts > 0 && rows[i].low <= sl && sl <= rows[i].high;
        const tpHit = tpPts > 0 && rows[i].low <= tp && tp <= rows[i].high;
        if (slHit || tpHit) {
          let pxOut = slHit && tpHit ? (true ? sl : tp) : slHit ? sl : tp;
          let reason: "SL" | "TP" =
            slHit && tpHit ? (true ? "SL" : "TP") : slHit ? "SL" : "TP";
          let pnl = (pxOut - pos.p) * (pos.side === "LONG" ? +1 : -1) * U;
          // Cap negative moves if exiting on SL
          if (reason === "SL") {
            const capped = capToGuaranteedStop(pnl, pos.side);
            pnl = capped.pnl;
            if (capped.pxOut !== null) pxOut = capped.pxOut;
          }
          // Apply upside cap for winning trades
          const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            pxOut = pos.p + (pos.side === "LONG" ? +1 : -1) * (maxWinUsd / U);
          }
          trades.push({
            side: pos.side === "LONG" ? "BUY" : "SELL",
            entryIdx: pos.i,
            exitIdx: i,
            entryPrice: pos.p,
            exitPrice: pxOut,
            pnl: Math.round(pnl * 100) / 100,
            reason,
          });
          pos = null;
          continue;
        }
      }

      // ===== Enforced Maximum Duration (auto close) =====
      const held = i - pos.i;
      if (maxTradeBars > 0 && held >= maxTradeBars) {
        const dir = pos.side === "LONG" ? +1 : -1;
        let exitPrice = rows[i].close;
        let pnl = (rows[i].close - pos.p) * dir * U;
        // Apply upside cap for positive PnL
        const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
        if (pnl > 0 && pnl > maxWinUsd) {
          pnl = maxWinUsd;
          exitPrice = pos.p + dir * (maxWinUsd / U);
        }
        trades.push({
          side: pos.side === "LONG" ? "BUY" : "SELL",
          entryIdx: pos.i,
          exitIdx: i,
          entryPrice: pos.p,
          exitPrice,
          pnl: Math.round(pnl * 100) / 100,
          reason: "MaxBars",
        });
        pos = null;
        continue;
      }

      // ===== Enforced Minimum Duration: prevent “soft exits” before minTradeBars =====
      const canSoftExit = held >= minTradeBars;

      // Exit on SIDE (only if soft exits allowed)
      if (canSoftExit && lbl === "SIDE") {
        const dir = pos.side === "LONG" ? +1 : -1;
        let exitPrice = px;
        let pnl = (px - pos.p) * dir * U;
        const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
        if (pnl > 0 && pnl > maxWinUsd) {
          pnl = maxWinUsd;
          exitPrice = pos.p + dir * (maxWinUsd / U);
        }
        trades.push({
          side: pos.side === "LONG" ? "BUY" : "SELL",
          entryIdx: pos.i,
          exitIdx: i,
          entryPrice: pos.p,
          exitPrice,
          pnl: Math.round(pnl * 100) / 100,
          reason: "TurnedSideways",
        });
        pos = null;
        continue;
      }

      // Hold margin / hysteresis (only if soft exits allowed)
      if (canSoftExit && !canHold(margin)) {
        pos.disagreeStreak += 1;
        if (pos.disagreeStreak >= hyst) {
          const dir = pos.side === "LONG" ? +1 : -1;
          let exitPrice = px;
          let pnl = (px - pos.p) * dir * U;
          const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            exitPrice = pos.p + dir * (maxWinUsd / U);
          }
          trades.push({
            side: pos.side === "LONG" ? "BUY" : "SELL",
            entryIdx: pos.i,
            exitIdx: i,
            entryPrice: pos.p,
            exitPrice,
            pnl: Math.round(pnl * 100) / 100,
            reason: "LostConfidence",
          });
          pos = null;
          continue;
        }
      } else if (canHold(margin)) {
        if (pos) pos.disagreeStreak = 0;
      }

      // Exit at Target (pull behaviour), only if soft exits allowed
      if (canSoftExit && held >= pos.targetLen) {
        if (
          localPullPct >= 100 ||
          (localPullPct > 0 && rand() < localPullPct / 100)
        ) {
          const dir = pos.side === "LONG" ? +1 : -1;
          let exitPrice = px;
          let pnl = (px - pos.p) * dir * U;
          const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
          if (pnl > 0 && pnl > maxWinUsd) {
            pnl = maxWinUsd;
            exitPrice = pos.p + dir * (maxWinUsd / U);
          }
          trades.push({
            side: pos.side === "LONG" ? "BUY" : "SELL",
            entryIdx: pos.i,
            exitIdx: i,
            entryPrice: pos.p,
            exitPrice,
            pnl: Math.round(pnl * 100) / 100,
            reason: "TargetLen",
          });
          pos = null;
          continue;
        }
      }
    } else {
      // Entry: open a new position when margin threshold is met and label is directional
      if (canEnter(margin)) {
        if (lbl === "BULL") {
          pos = {
            side: "LONG",
            i,
            p: px,
            targetLen: sampleTargetLen(),
            disagreeStreak: 0,
          };
          if (useTrailing) pos.trailBase = px;
        } else if (lbl === "BEAR") {
          pos = {
            side: "SHORT",
            i,
            p: px,
            targetLen: sampleTargetLen(),
            disagreeStreak: 0,
          };
          if (useTrailing) pos.trailBase = px;
        }
      }
    }
  }
  // Close leftover position at the end of the series
  if (pos) {
    const i = rows.length - 1;
    const px = rows[i].close;
    const dir = pos.side === "LONG" ? +1 : -1;
    let exitPrice = px;
    let pnl = (px - pos.p) * dir * U;
    const maxWinUsd = tpPts > 0 ? tpPts * U : Infinity;
    if (pnl > 0 && pnl > maxWinUsd) {
      pnl = maxWinUsd;
      exitPrice = pos.p + dir * (maxWinUsd / U);
    }
    trades.push({
      side: pos.side === "LONG" ? "BUY" : "SELL",
      entryIdx: pos.i,
      exitIdx: i,
      entryPrice: pos.p,
      exitPrice,
      pnl: Math.round(pnl * 100) / 100,
      reason: "End",
    });
  }

  // Determine any open trade at the end (real-time).  When the last trade
  // remains open we report it separately with its unrealised PnL.  In this
  // synchronous simulation we always close the position at the end of the
  // sample, so the openTrade will be null.
  let openTrade: OpenTrade = null;
  return { trades, openTrade };
}
