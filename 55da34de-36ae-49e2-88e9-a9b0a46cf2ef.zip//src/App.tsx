import React, { useState } from "react";
import BacktestingML from "./components/backtestingML";
import LiveML from "./components/liveML";
import TrainingML from "./components/trainingML";
import { AnimatePresence, motion } from "framer-motion";

type Page = "training" | "backtest" | "live";

// Simple logo URL (no theme switching)
const LOGO_URL =
  "https://www.dropbox.com/scl/fi/i0o40cqjno3jne2pvcmyz/darkModeLogo.png?rlkey=khf3r3ki2wslz8526srd2wza1&st=3wjn06mo&dl=1";

// Animation
const pageVariants = {
  initial: { opacity: 0, y: 24, scale: 0.985, filter: "blur(6px)" },
  animate: { opacity: 1, y: 0, scale: 1, filter: "blur(0px)" },
  exit: { opacity: 0, y: -24, scale: 0.985, filter: "blur(6px)" },
};
const pageTransition = {
  duration: 0.85,
  ease: [0.22, 1, 0.36, 1],
};

export default function App() {
  const [page, setPage] = useState<Page>("backtest");
  const [hasSelectedPage, setHasSelectedPage] = useState(false);

  const handleInitialSelect = (nextPage: Page) => {
    setPage(nextPage);
    setHasSelectedPage(true);
  };

  // ===== FIRST LOAD FULLSCREEN CHOOSER =====
  if (!hasSelectedPage) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-10 -mt-16">
          {/* Just the buttons, no logo/text */}
          <div className="flex flex-col sm:flex-row gap-8">
            <button
              onClick={() => handleInitialSelect("training")}
              className="px-10 py-5 rounded-2xl text-xl font-semibold bg-neutral-900/80 border border-blue-500/70 hover:bg-neutral-900 hover:border-blue-400 transition transform hover:scale-105 shadow-[0_0_30px_rgba(37,99,235,0.55)] hover:shadow-[0_0_55px_rgba(59,130,246,0.9)]"
            >
              Training
            </button>
            <button
              onClick={() => handleInitialSelect("backtest")}
              className="px-10 py-5 rounded-2xl text-xl font-semibold bg-neutral-900/80 border border-blue-500/70 hover:bg-neutral-900 hover:border-blue-400 transition transform hover:scale-105 shadow-[0_0_30px_rgba(37,99,235,0.55)] hover:shadow-[0_0_55px_rgba(59,130,246,0.9)]"
            >
              Backtest
            </button>
            <button
              onClick={() => handleInitialSelect("live")}
              className="px-10 py-5 rounded-2xl text-xl font-semibold bg-neutral-900/80 border border-blue-500/70 hover:bg-neutral-900 hover:border-blue-400 transition transform hover:scale-105 shadow-[0_0_30px_rgba(37,99,235,0.55)] hover:shadow-[0_0_55px_rgba(59,130,246,0.9)]"
            >
              Live
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ===== NORMAL LAYOUT AFTER SELECTION =====
  return (
    <div className="min-h-screen">
      {/* Top Bar (only styles the bar, not the pages) */}
      <div className="w-full flex justify-center p-3 border-b relative z-10 bg-black/80 backdrop-blur border-neutral-800">
        {/* LEFT: Logo + Name */}
        <a
          href="#"
          className="absolute left-6 top-1/2 -translate-y-1/2 inline-flex items-center gap-3 select-none"
          aria-label="Seasons Home"
        >
          <img
            src={LOGO_URL}
            alt="Seasons"
            className="h-12 w-12 object-contain"
          />
          <span className="text-2xl font-extrabold tracking-wide">
            Machine Learning
          </span>
        </a>

        {/* CENTER: Tabs */}
        <div className="flex items-center gap-6">
          <TabButton
            active={page === "training"}
            label="Training"
            onClick={() => setPage("training")}
            activeColorClass="bg-blue-600 text-white"
          />
          <TabButton
            active={page === "backtest"}
            label="Backtest"
            onClick={() => setPage("backtest")}
            activeColorClass="bg-blue-600 text-white"
          />
          <TabButton
            active={page === "live"}
            label="Live"
            onClick={() => setPage("live")}
            activeColorClass="bg-blue-600 text-white"
          />
        </div>
      </div>

      {/* Content – no enforced background or text color here */}
      <div className="min-h-[calc(100vh-56px)]">
        <AnimatePresence mode="wait">
          {page === "training" && (
            <motion.div
              key="training"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              transition={pageTransition}
            >
              <TrainingML />
            </motion.div>
          )}

          {page === "backtest" && (
            <motion.div
              key="backtest"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              transition={pageTransition}
            >
              <BacktestingML />
            </motion.div>
          )}

          {page === "live" && (
            <motion.div
              key="live"
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              transition={pageTransition}
            >
              <LiveML />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function TabButton({
  active,
  label,
  onClick,
  activeColorClass,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
  activeColorClass: string;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        "relative px-4 py-2 rounded-lg font-semibold transition",
        active
          ? activeColorClass
          : "bg-neutral-200 hover:bg-neutral-300 text-neutral-900 dark:bg-neutral-800 dark:hover:bg-neutral-700 dark:text-neutral-100",
      ].join(" ")}
    >
      {label}
      <motion.span
        layoutId="underline"
        style={{ borderRadius: 9999 }}
        className="absolute left-1/2 -translate-x-1/2 bottom-0 h-[2px] w-1/2"
        animate={{
          backgroundColor: active ? "rgba(0,0,0,0.35)" : "rgba(0,0,0,0)",
        }}
        transition={{ duration: 0.6 }}
      />
    </button>
  );
}
